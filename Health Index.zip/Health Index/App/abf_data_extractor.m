function [data_raw] =abf_data_extractor(fileName,fre,data_pts_read,starting_time,skip_pts,bytes_per_single_read,data_precision,endian,TDC)
    %FDP:  Fixed Data Precision
    
    fileID = fopen(fileName,'r');
    fseek(fileID,skip_pts,'bof');
    fseek(fileID,(floor(starting_time*fre*TDC)*bytes_per_single_read),'cof');%advances based on the start time
    
    %data_precision=strcat('*',data_precision);
    data_raw=fread(fileID,[data_pts_read,1],data_precision,endian);

    fclose(fileID);

end