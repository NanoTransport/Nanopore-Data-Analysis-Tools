function [skip_pts,actual_length,precision,dataSz,data_scaling,si,TDC,CU]=abf_ultra_simple_CU_Only(file_name,data_channel,instrument_str)

%A good resource about abf files can be found at : https://swharden.com/pyabf/abf2-file-format/
fid = fopen(file_name,'r');
read_file_signature=fread(fid,4);
if read_file_signature(end)==50 %ABF2 (See ASCII Table: https://www.asciitable.com/)
    abf_type=2;
else
    abf_type=1; %For a later version...
end

%Few definitions:  Line 240
%headPar=define_header(fFileSignature);
% define all sections that there are
Sections=define_Sections;
% define a few of these (currently, only the TagInfo section is used for
% all versions of ABF, but that may change in the future)
ProtocolInfo=define_ProtocolInfo;
ADCInfo=define_ADCInfo;
TagInfo=define_TagInfo;

% temporary initializing var
   tmp=repmat(-1,1,16);

   if abf_type==1
        headPar={
             'fFileSignature',0,'*char',[-1 -1 -1 -1];
             'fFileVersionNumber',4,'float32',-1;
             'nOperationMode',8,'int16',-1;
             'lActualAcqLength',10,'int32',-1;
             'nNumPointsIgnored',14,'int16',-1;
             'lActualEpisodes',16,'int32',-1;
             'lFileStartTime',24,'int32',-1;
             'lDataSectionPtr',40,'int32',-1;
             'lTagSectionPtr',44,'int32',-1;
             'lNumTagEntries',48,'int32',-1;
             'lSynchArrayPtr',92,'int32',-1;
             'lSynchArraySize',96,'int32',-1;
             'nDataFormat',100,'int16',-1;
             'nADCNumChannels', 120, 'int16', -1;
             'fADCSampleInterval',122,'float', -1;
             'fSynchTimeUnit',130,'float',-1;
             'lNumSamplesPerEpisode',138,'int32',-1;
             'lPreTriggerSamples',142,'int32',-1;
             'lEpisodesPerRun',146,'int32',-1;
             'fADCRange', 244, 'float', -1;
             'lADCResolution', 252, 'int32', -1;
             'nFileStartMillisecs', 366, 'int16', -1;
             'nADCPtoLChannelMap', 378, 'int16', tmp;
             'nADCSamplingSeq', 410, 'int16',  tmp;
             'sADCChannelName',442, 'uchar', repmat(tmp,1,10);
             'sADCUnits',602, 'uchar', repmat(tmp,1,8);
             'fADCProgrammableGain', 730, 'float', tmp;
             'fInstrumentScaleFactor', 922, 'float', tmp;
             'fInstrumentOffset', 986, 'float', tmp;
             'fSignalGain', 1050, 'float', tmp;
             'fSignalOffset', 1114, 'float', tmp;
             'nTelegraphEnable',4512,'int16',tmp;
             'fTelegraphAdditGain',4576,'float',tmp
             };
   else
         headPar={
             'fFileSignature',0,'*char',[-1 -1 -1 -1];
             'fFileVersionNumber',4,'bit8=>int',[-1 -1 -1 -1];
             'uFileInfoSize',8,'uint32',-1;
             'lActualEpisodes',12,'uint32',-1;
             'uFileStartDate',16','uint32',-1;
             'uFileStartTimeMS',20,'uint32',-1;
             'uStopwatchTime',24,'uint32',-1;
             'nFileType',28,'int16',-1;
             'nDataFormat',30,'int16',-1;
             'nSimultaneousScan',32,'int16',-1;
             'nCRCEnable',34,'int16',-1;
             'uFileCRC',36,'uint32',-1;
             'FileGUID',40,'uint32',-1;
             'uCreatorVersion',56,'uint32',-1;
             'uCreatorNameIndex',60,'uint32',-1;
             'uModifierVersion',64,'uint32',-1;
             'uModifierNameIndex',68,'uint32',-1;
             'uProtocolPathIndex',72,'uint32',-1;
             };
   end
% convert headPar to struct
BLOCKSIZE=512;
% output variables
h=[];

s=cell2struct(headPar,{'name','offs','numType','value'},2);
numOfParams=size(s,1);

% convert names in structure to variables and read value from header: % line 258
for g=1:numOfParams
  if fseek(fid, s(g).offs,'bof')~=0,
    fclose(fid);
    error(['something went wrong locating ' s(g).name]);
  end
  sz=length(s(g).value);
  % use dynamic field names
  [h.(s(g).name),n]=fread(fid,sz,s(g).numType);
  if n~=sz,
    fclose(fid);
    error(['something went wrong reading value(s) for ' s(g).name]);
  end
end

%Line 275
h.fFileVersionNumber=h.fFileVersionNumber(4)+h.fFileVersionNumber(3)*.1...
    +h.fFileVersionNumber(2)*.001+h.fFileVersionNumber(1)*.0001;

% determine offset at which data start (Line 453)
switch h.nDataFormat
  case 0
    dataSz=2;  % bytes/point
    precision='int16';
  case 1
    dataSz=4;  % bytes/point
    precision='float32';
  otherwise
    fclose(fid);
    error('invalid number format');
end

%Line 289
Sects=cell2struct(Sections,{'name'},2);
numOfSections=length(Sections);
offset=76;
% this creates all sections (ADCSection, ProtocolSection, etc.)
  for i=1:numOfSections
      eval([Sects(i).name '=ReadSectionInfo(fid,offset);'])
      offset=offset+4+4+8;
  end

%*********%TO DETERMINE CURENT UNITS (PART%1)********************************%

          %Lines 308 information on the names of recorded channels and the units)
          %CHECK LINE 182 FOR PART 2
          fseek(fid,StringsSection.uBlockIndex*BLOCKSIZE,'bof');
          BigString=fread(fid,StringsSection.uBytes);%'char removed to increase the analysis speed'
          progString={'clampex','clampfit','axoscope','patchxpress','10mhz','edr3','edr4','emcr',instrument_str};%'10mhz' and 'edr3' added. 'emcr' added on 1/11/2025 to acccount for the new elements software for 40MHz amplifier
          goodstart=[];
          for i=1:numel(progString)
            goodstart=cat(1,goodstart,strfind(lower(char(BigString)'),progString{i}));
          end
          
          if isempty(goodstart)==0 %incase the header returns an error in 'progString'
              BigString=BigString(goodstart(1):end)';
              stringends=find(BigString==0);
              stringends=[0 stringends];
              %i=1:length(stringends)-1
              for i=1:length(stringends)-1
                Strings{i}=char(BigString(stringends(i)+1:stringends(i+1)-1));
              end
          end
          h.recChNames=[];
          h.recChUnits=[];
          
%*************************Finding the Scaling Value*****************************%
    
        %scaling (if file is integer type, then this needed. If float, its fine):
        
          %Line 352
          ProtocolSec=ReadSection(fid,ProtocolSection.uBlockIndex*BLOCKSIZE,ProtocolInfo);
          h.fADCRange=ProtocolSec.fADCRange;
          h.lADCResolution=ProtocolSec.lADCResolution;

          %Line 333 (this is a shortcut:  can bite you if not done properlly)
          i=1;
          ADCsec(i)=ReadSectionMOD(fid,ADCSection.uBlockIndex*BLOCKSIZE+ADCSection.uBytes*(i-1),ADCInfo);
          ADCsec(i).fInstrumentScaleFactor;
          ch=data_channel;
          h.nTelegraphEnable(ch)=ADCsec(1).nTelegraphEnable;
          h.fTelegraphAdditGain(ch)=ADCsec(1).fTelegraphAdditGain;
          h.fInstrumentScaleFactor(ch)=ADCsec(i).fInstrumentScaleFactor;
          h.fSignalGain(ch)=ADCsec(i).fSignalGain;
          h.fADCProgrammableGain(ch)=ADCsec(i).fADCProgrammableGain;
          h.fInstrumentOffset(ch)=ADCsec(i).fInstrumentOffset;
          h.fSignalOffset(ch)=ADCsec(i).fSignalOffset;

          %TO DETERMINE CURENT UNITS (PART 2)
          if isempty(goodstart)==0
              h.recChNames=strvcat(h.recChNames, Strings{ADCsec(i).lADCChannelNameIndex});
              CU1=h.recChNames;
              unitsIndex=ADCsec(i).lADCUnitsIndex;
              if unitsIndex>0
                  h.recChUnits=strvcat(h.recChUnits, Strings{ADCsec(i).lADCUnitsIndex});
              else
                  h.recChUnits=strvcat(h.recChUnits,'');
              end
              CU2=h.recChUnits;
              CU={CU1 CU2};
          else
              CU={'xx' 'xx'};
          end
          
          %Line 445
          % gain of telegraphed instruments, if any
          if h.fFileVersionNumber>=1.65
            addGain=h.nTelegraphEnable.*h.fTelegraphAdditGain;
            addGain(addGain==0)=1;
          else
            addGain=ones(size(h.fTelegraphAdditGain));
          end
          
    if strcmp(precision,'int16')==1
          SF1=(h.fInstrumentScaleFactor(ch)*h.fSignalGain(ch)*h.fADCProgrammableGain(ch)*addGain(ch));
          SF2=h.fADCRange;
          SF3=h.lADCResolution+h.fInstrumentOffset(ch)-h.fSignalOffset(ch);
          data_scaling=SF2/(SF1*SF3);
    else
        SF1=1;
        SF2=1;
        SF3=1;
        data_scaling=(SF2/(SF1*SF3));
    end
%*************************************************************************************%
         
%Sampling Interval:  different from the orignial abf file
h.nADCNumChannels=ADCSection.llNumEntries;
TDC=h.nADCNumChannels;%Total Data Channels
ProtocolSecPrel=ReadSectionPrel(fid,ProtocolSection.uBlockIndex*BLOCKSIZE,ProtocolInfo);
h.fADCSampleInterval=ProtocolSecPrel.fADCSequenceInterval/h.nADCNumChannels;
si=h.fADCSampleInterval*h.nADCNumChannels;

%units of the current signal

%start point for gap free data:  line 676
start=0.0;
startPt=floor(1e6*start*(1/h.fADCSampleInterval));
startPt=floor(startPt/h.nADCNumChannels)*h.nADCNumChannels;

% --- read in the Sections:  Line 298
  Sections=define_Sections;
  Sects=cell2struct(Sections,{'name'},2);
  numOfSections=length(Sections);
  offset=76;
  % this creates all sections (ADCSection, ProtocolSection, etc.)
  for i=1:numOfSections
    eval([Sects(i).name '=ReadSectionInfo(fid,offset);']);
    offset=offset+4+4+8;
  end
  %headoffset :Line 465
  h.lDataSectionPtr=DataSection.uBlockIndex;%Line 358
  h.nNumPointsIgnored=0;%Line 359
  headOffset=h.lDataSectionPtr*BLOCKSIZE+h.nNumPointsIgnored*dataSz; %Line 465
  skip_pts=startPt*dataSz+headOffset;
  %headOffset=offset*(BLOCKSIZE/dataSz);%each block has 'BLOCKSIZE' bytes

%file length and sampling frequency (line 694)
h.lActualAcqLength=DataSection.llNumEntries;%line 357
actual_length=h.lActualAcqLength;

fclose(fid);

%Function section
function Sections=define_Sections
Sections={'ProtocolSection';
 'ADCSection';
 'DACSection';
 'EpochSection';
 'ADCPerDACSection';
 'EpochPerDACSection';
 'UserListSection';
 'StatsRegionSection';
 'MathSection';
 'StringsSection';
 'DataSection';
 'TagSection';
 'ScopeSection';
 'DeltaSection';
 'VoiceTagSection';
 'SynchArraySection';
 'AnnotationSection';
 'StatsSection';
 };

function ProtocolInfo=define_ProtocolInfo
ProtocolInfo={
 'nOperationMode','int16',1;
 'fADCSequenceInterval','float',1;
 'bEnableFileCompression','bit1',1;
 'sUnused1','char',3;
 'uFileCompressionRatio','uint32',1;
 'fSynchTimeUnit','float',1;
 'fSecondsPerRun','float',1;
 'lNumSamplesPerEpisode','int32',1;
 'lPreTriggerSamples','int32',1;
 'lEpisodesPerRun','int32',1;
 'lRunsPerTrial','int32',1;
 'lNumberOfTrials','int32',1;
 'nAveragingMode','int16',1;
 'nUndoRunCount','int16',1;
 'nFirstEpisodeInRun','int16',1;
 'fTriggerThreshold','float',1;
 'nTriggerSource','int16',1;
 'nTriggerAction','int16',1;
 'nTriggerPolarity','int16',1;
 'fScopeOutputInterval','float',1;
 'fEpisodeStartToStart','float',1;
 'fRunStartToStart','float',1;
 'lAverageCount','int32',1;
 'fTrialStartToStart','float',1;
 'nAutoTriggerStrategy','int16',1;
 'fFirstRunDelayS','float',1;
 'nChannelStatsStrategy','int16',1;
 'lSamplesPerTrace','int32',1;
 'lStartDisplayNum','int32',1;
 'lFinishDisplayNum','int32',1;
 'nShowPNRawData','int16',1;
 'fStatisticsPeriod','float',1;
 'lStatisticsMeasurements','int32',1;
 'nStatisticsSaveStrategy','int16',1;
 'fADCRange','float',1;
 'fDACRange','float',1;
 'lADCResolution','int32',1;
 'lDACResolution','int32',1;
 'nExperimentType','int16',1;
 'nManualInfoStrategy','int16',1;
 'nCommentsEnable','int16',1;
 'lFileCommentIndex','int32',1;
 'nAutoAnalyseEnable','int16',1;
 'nSignalType','int16',1;
 'nDigitalEnable','int16',1;
 'nActiveDACChannel','int16',1;
 'nDigitalHolding','int16',1;
 'nDigitalInterEpisode','int16',1;
 'nDigitalDACChannel','int16',1;
 'nDigitalTrainActiveLogic','int16',1;
 'nStatsEnable','int16',1;
 'nStatisticsClearStrategy','int16',1;
 'nLevelHysteresis','int16',1;
 'lTimeHysteresis','int32',1;
 'nAllowExternalTags','int16',1;
 'nAverageAlgorithm','int16',1;
 'fAverageWeighting','float',1;
 'nUndoPromptStrategy','int16',1;
 'nTrialTriggerSource','int16',1;
 'nStatisticsDisplayStrategy','int16',1;
 'nExternalTagType','int16',1;
 'nScopeTriggerOut','int16',1;
 'nLTPType','int16',1;
 'nAlternateDACOutputState','int16',1;
 'nAlternateDigitalOutputState','int16',1;
 'fCellID','float',3;
 'nDigitizerADCs','int16',1;
 'nDigitizerDACs','int16',1;
 'nDigitizerTotalDigitalOuts','int16',1;
 'nDigitizerSynchDigitalOuts','int16',1;
 'nDigitizerType','int16',1;
 };

function ADCInfo=define_ADCInfo
ADCInfo={
 'nADCNum','int16',1;
 'nTelegraphEnable','int16',1;
 'nTelegraphInstrument','int16',1;
 'fTelegraphAdditGain','float',1;
 'fTelegraphFilter','float',1;
 'fTelegraphMembraneCap','float',1;
 'nTelegraphMode','int16',1;
 'fTelegraphAccessResistance','float',1;
 'nADCPtoLChannelMap','int16',1;
 'nADCSamplingSeq','int16',1;
 'fADCProgrammableGain','float',1;
 'fADCDisplayAmplification','float',1;
 'fADCDisplayOffset','float',1;
 'fInstrumentScaleFactor','float',1;
 'fInstrumentOffset','float',1;
 'fSignalGain','float',1;
 'fSignalOffset','float',1;
 'fSignalLowpassFilter','float',1;
 'fSignalHighpassFilter','float',1;
 'nLowpassFilterType','char',1;
 'nHighpassFilterType','char',1;
 'fPostProcessLowpassFilter','float',1;
 'nPostProcessLowpassFilterType','char',1;
 'bEnabledDuringPN','bit1',1;
 'nStatsChannelPolarity','int16',1;
 'lADCChannelNameIndex','int32',1;
 'lADCUnitsIndex','int32',1;
 };

function TagInfo=define_TagInfo
TagInfo={
   'lTagTime','int32',1;
   'sComment','char',56;
   'nTagType','int16',1;
   'nVoiceTagNumber_or_AnnotationIndex','int16',1;
};

function Section=ReadSection(fid,offset,Format)
s=cell2struct(Format,{'name','numType','number'},2);
fseek(fid,offset,'bof');
fseek(fid,110,'cof');%Added on 8-14-2023 to advance to fADCRange:  if not this slows down the entire process 
for i=1:length(s)
    if i>=35 %Added on 8-14-2023 to read fADCRange  and beyond
        eval(['[Section.' s(i).name ',n]=fread(fid,' num2str(s(i).number) ',''' s(i).numType ''');']);
    end
end

function Section=ReadSectionPrel(fid,offset,Format)%added on 8-14-2023:  this was initially 'ReadSection'
s=cell2struct(Format,{'name','numType','number'},2);
fseek(fid,offset,'bof');
for i=1:2 %purpose:  reading the sampling interval
    eval(['[Section.' s(i).name ',n]=fread(fid,' num2str(s(i).number) ',''' s(i).numType ''');']);
end

function Section=ReadSectionMOD(fid,offset,Format)%added on 8-14-2023:  this was initially 'ReadSection'
s=cell2struct(Format,{'name','numType','number'},2);
fseek(fid,offset,'bof');
for i=1:length(s)
    eval(['[Section.' s(i).name ',n]=fread(fid,' num2str(s(i).number) ',''' s(i).numType ''');']);
end


function SectionInfo=ReadSectionInfo(fid,offset)
fseek(fid,offset,'bof');
SectionInfo.uBlockIndex=fread(fid,1,'uint32');
fseek(fid,offset+4,'bof');
SectionInfo.uBytes=fread(fid,1,'uint32');
fseek(fid,offset+8,'bof');
SectionInfo.llNumEntries=fread(fid,1,'int64');
