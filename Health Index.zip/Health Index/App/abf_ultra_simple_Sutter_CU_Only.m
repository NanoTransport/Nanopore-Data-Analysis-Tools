function [skip_pts,actual_length,precision,dataSz,data_scaling,si,TDC,CU] = abf_ultra_simple_Sutter_CU_Only(file_name)
    % Confirm signature
    fid = fopen(file_name, 'rb', 'l');
    fseek(fid, 0, 'bof');
    sig = fread(fid, 4, '*char')';
    fprintf('Signature: "%s"\n', sig);  % Should be "ABF " for ABF1
    
    % --- ABF1 Header reads (fixed byte positions) ---
    fseek(fid, 4,   'bof'); fFileVersionNumber     = fread(fid, 1, 'float32');
    fseek(fid, 8,   'bof'); nOperationMode         = fread(fid, 1, 'int16');
    fseek(fid, 10,  'bof'); lActualAcqLength       = fread(fid, 1, 'int32');
    fseek(fid, 14,  'bof'); nNumPointsIgnored      = fread(fid, 1, 'int16');
    fseek(fid, 16,  'bof'); lActualEpisodes        = fread(fid, 1, 'int32');
    fseek(fid, 40,  'bof'); lDataSectionPtr        = fread(fid, 1, 'int32');
    fseek(fid, 100, 'bof'); nDataFormat            = fread(fid, 1, 'int16');
    fseek(fid, 120, 'bof'); nADCNumChannels        = fread(fid, 1, 'int16');
    fseek(fid, 122, 'bof'); fADCSampleInterval     = fread(fid, 1, 'float32');
    fseek(fid, 244, 'bof'); fADCRange              = fread(fid, 1, 'float32');
    fseek(fid, 252, 'bof'); lADCResolution         = fread(fid, 1, 'int32');
    
    % Channel names (16 channels x 10 chars each, starting at byte 442)
    fseek(fid, 442, 'bof');
    sADCChannelName = cell(1, nADCNumChannels);
    for i = 1:16
        name = fread(fid, 10, '*char')';
        if i <= nADCNumChannels
            sADCChannelName{i} = strtrim(name);
        end
    end
    
    % Channel units (16 channels x 8 chars each, starting at byte 602)
    fseek(fid, 602, 'bof');
    sADCUnits = cell(1, nADCNumChannels);
    for i = 1:16
        unit = fread(fid, 8, '*char')';
        if i <= nADCNumChannels
            sADCUnits{i} = strtrim(unit);
        end
    end
    
    % Gain values for scaling (byte 730, 16 floats)
    fseek(fid, 730, 'bof');
    fADCProgrammableGain = fread(fid, 16, 'float32');
    
    % Instrument scale/offset (bytes 922, 986)
    fseek(fid, 922,  'bof'); fInstrumentScaleFactor = fread(fid, 16, 'float32');
    fseek(fid, 986,  'bof'); fInstrumentOffset      = fread(fid, 16, 'float32');
    fseek(fid, 1050, 'bof'); fSignalGain            = fread(fid, 16, 'float32');
    fseek(fid, 1114, 'bof'); fSignalOffset          = fread(fid, 16, 'float32');
    
    % Telegraph gain (byte 4576)
    fseek(fid, 4512, 'bof'); nTelegraphEnable       = fread(fid, 16, 'int16');
    fseek(fid, 4576, 'bof'); fTelegraphAdditGain    = fread(fid, 16, 'float32');
    
    fclose(fid);
    
    % --- Compute requested parameters ---
    BLOCKSIZE = 512;
    
    skip_pts      = nNumPointsIgnored;
    actual_length = lActualAcqLength;
    TDC           = nADCNumChannels;         % Total Data Channels
    si            = fADCSampleInterval;      % sampling interval in microseconds
    dataSz        = 2;                       % ABF1 int16 = 2 bytes per point (if nDataFormat==0)
    if nDataFormat == 1
        dataSz    = 4;                       % float32 = 4 bytes
        precision = 'single';
    else
        precision = 'int16';
    end
    
    % Current unit for channel 1
    CU = sADCUnits{1};
    
    % Scale factors (ABF1 formula)
    data_scaling = zeros(1, TDC);
    for i = 1:TDC
        sf = lADCResolution / 1e6;           % simple ABF1 scaling
        data_scaling(i) = sf;
    end
end
