function alpha = fit_psd(data, fre,pds_type)

    if pds_type==1 %pwelch appraoch
        Nx=floor(length(data));
        window=hamming(Nx); %for longer traces, consider shorter segments to get a smoother PSD estimate by using Nx/4 or Nx/8.
        noverlap=floor(length(window)/2); %50% overlap
        nfft= Nx; % If a speed up is needed, conside using nfft=2^nextpow2(Nx); % next power-of-two for speed
        %nfft = fre;     % <-- 1 Hz frequency spacing
        
        [PSD, f] = pwelch(data, window, noverlap, nfft, fre);

        frequency_type=f;
        PSD_type = PSD;

    else
        N = length(data);
        Y = fft(data);
        
        % One-sided PSD
        PSD_fft = (1/(fre*N)) * abs(Y).^2;
        PSD_fft = PSD_fft(1:floor(N/2)+1);% For a single-sided PSD (typical for real signals), you only need the first N/2+1 points
        PSD_fft(2:end-1) = 2*PSD_fft(2:end-1); %for a single-sided Power Spectral Density (PSD), you multiply all the positive frequency components by two, except for the DC (0 Hz) and Nyquist frequencies
        
        % Frequency vector
        f_fft = (0:floor(N/2))*(fre/N);
        
        frequency_type=f_fft;
        PSD_type = PSD_fft;
    end

    % Target the 1-100 Hz range
    idx = (frequency_type >= 1 & frequency_type <= 100);
    logF = log10(frequency_type(idx));
    logP = log10(PSD_type(idx));
    
    % Linear fit: log10(PSD) = -alpha * log10(f) + constant
    % We want alpha (the exponent)
    p = polyfit(logF, logP, 1);
    alpha = -p(1); % Return the positive exponent alpha
end