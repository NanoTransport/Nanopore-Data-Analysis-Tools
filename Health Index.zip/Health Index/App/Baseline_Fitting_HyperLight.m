function [BCI,mean_data]=Baseline_Fitting_HyperLight(time_data,current_data,step_size,BOP)
%EO: Extended Options
%BOP: Baseline Options
%BOP =2:  A linear fit to the baseline
%BOP=3: Smoothdata function with Gaussian Option
%BOP=4:  Sequal combination of BOP3 and BOP4
%Data manipulation and establishment of threshol based data
mean_data=mean(current_data);

MT=0.7;%threshold for mean of baseline

if BOP==2 %baseline isa linear fit to the filtered_I
    mean_I_prel=mean(current_data);
    filtered_BC_data=current_data(current_data>mean_I_prel);
    if length(filtered_BC_data)>MT*length(current_data)%happens in the case of very long events, MT% is a safe number for longer events
        iterations=0;
        while length(filtered_BC_data)>MT*length(current_data) && iterations<10
              mean_I_prel=mean(filtered_BC_data);
              filtered_BC_data=current_data(current_data>mean_I_prel);
              iterations=iterations+1;
        end
        time_length_temp=(1:size(filtered_BC_data,1))';
        p=polyfit(time_length_temp,filtered_BC_data,1);
    else
        time_length_temp=(1:size(filtered_BC_data,1))';
        p=polyfit(time_length_temp,filtered_BC_data,1);
    end
    
    m=p(1);
    c=p(2);
    BG=(time_data*m)+c;%background signal
    BCI=(current_data-BG);%Background Corrected Current Signal
end

if BOP==3
    gauss_step_size=step_size*100;
    BFit = smoothdata(current_data,'gaussian',gauss_step_size);%Background
    BCI=(current_data-BFit);%Background Corrected Current Signal
end

if BOP==4
    BCI=msbackadj(time_data,current_data,'StepSize',step_size,'RegressionMethod','spline');%background substracted signal
end

end