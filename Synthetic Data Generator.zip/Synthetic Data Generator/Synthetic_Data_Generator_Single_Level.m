%% Refined synthetic event trace with controllable SNR
clear all
clc

%----------------------------------------------------------------------
%Main trace attributes
%----------------------------------------------------------------------
window_mean = 21; % nA
fre = 250*1000; % sampling rate in Hz
total_events_needed = 40;
baseline_instability_level = 1;

base_current = abs(window_mean);
current_sign=sign(window_mean);

%----------------------------------------------------------------------
%Secondary Pulse and trace attributes
%----------------------------------------------------------------------
en=1;                   %1=conductive, -1=resistive
padpts=10;              %points for sigmoid transitions
noise_std = 0.2;        %standard deviation of baseline noise
event_noise_std=0.2;    %standard deviation of event noise
SNR=3;                  % signal-to-noise ratio (pulse depth / noise)
trace_length_sec = 1;   %length of the trace
min_inter_event_distance=10; %in milliseconds

%----------------------------------------------------------------------
%Pulse Bounderies
%----------------------------------------------------------------------
dt_min = 10;   % microseconds
dt_max = 1000; % microseconds
dI_min = 100;  % pA
dI_max = noise_std*1000*3.3*SNR; % pA

%----------------------------------------------------------------------
%pulse boundary random initiation
%----------------------------------------------------------------------
dt_min_pts = round(fre*dt_min/1e6);
dt_max_pts = round(fre*dt_max/1e6);

dI_list = randi([dI_min dI_max],1,total_events_needed)/1000; % nA
dt_length_pts = randi([dt_min_pts dt_max_pts],1,total_events_needed);

%----------------------------------------------------------------------
%trace construction
%----------------------------------------------------------------------
trace_length_pts = round(trace_length_sec*fre);
baseline_pts = trace_length_pts-dt_length_pts(end);

%----------------------------------------------------------------------
%Adding noise to the trace
%----------------------------------------------------------------------
trace_noise = randn(1, trace_length_pts)*noise_std;
opentrace = base_current + trace_noise;

%----------------------------------------------------------------------  
% ADD BASELINE INSTABILITIES
%----------------------------------------------------------------------  
drift = smoothdata(cumsum(0.001*baseline_instability_level * randn(1, trace_length_pts)),5,'loess');

% Apply baseline instability
opentrace = opentrace + drift;

%----------------------------------------------------------------------  
% Event Start Points (Enforce min spacing x ms)
%----------------------------------------------------------------------  
min_distance_pts = round(fre*min_inter_event_distance/1000);   % in ms minimum separation
event_occurance_pts = zeros(1, total_events_needed);

% First event can appear anywhere
event_occurance_pts(1) = randi([1 baseline_pts]);

for k = 2:total_events_needed
    placed = false;
    attempt = 0;

    while ~placed && attempt < 5000
        attempt = attempt + 1;
        candidate = randi([1 baseline_pts]);
        
        % Must be >=1 ms away from all previous events
        if all(abs(candidate - event_occurance_pts(1:k-1)) >= min_distance_pts)
            event_occurance_pts(k) = candidate;
            placed = true;
        end
    end

    % If random placement fails (very dense trace), force spacing
    if ~placed
        event_occurance_pts(k) = event_occurance_pts(k-1) + min_distance_pts;
    end
end

event_occurance_pts = sort(event_occurance_pts);

%----------------------------------------------------------------------
% Generate events with smooth transitions
%----------------------------------------------------------------------

for i = 1:total_events_needed
    event_mag = dI_list(i);
    event_pts = dt_length_pts(i);

    %Smooth rise/fall edges using sigmoid
    rise =1./(1+exp(-linspace(-6,6,padpts)));
    fall =1-rise;

    %event data points
    event_shape =[en*event_mag*rise, en*event_mag*ones(1,event_pts), en*event_mag*fall];

    %Adding noise to the event
    event_noise =randn(1,length(event_shape))*event_noise_std;
    noise_added_event = base_current + event_shape + event_noise;

    %Insert event into the baseline
    idx_start = event_occurance_pts(i);
    idx_end = min(idx_start+length(noise_added_event)-1, trace_length_pts);
    opentrace(idx_start:idx_end) = noise_added_event(1:(idx_end-idx_start+1));
end

%----------------------------------------------------------------------
%Final adjustments and plotting
%----------------------------------------------------------------------

%sign_adjusted_current
trace_data=current_sign*opentrace;

% Time axis
time_axis = (0:trace_length_pts-1)'/fre;

% Plot
font_size=18;
minX=min(time_axis);
maxX=max(time_axis);
minY=min(trace_data);
maxY=max(trace_data);

color0=[0.0 0.0 0.5];
color1=[0.6350 0.0780 0.1840];
color2=[0.06350 0.780 0.1840];
color3=[0.5 0.1 0.02];
color4=[0.1 0.1 0.9];
color5=[0.9 0.1 0.9];
color6=[0.5 0.05 0.9];
color7=[0.1 0.3 0.1];
color8=[0.05 0.2 0.6];
color9=[0.0 0.0 0.0]+0.2;

p1=plot(time_axis, trace_data,'color',color8);
hold off

grid on
grid minor

xlim([minX maxX]);
ylim([minY maxY]);
xlabel('Time (s)','FontSize',font_size);
ylabel('Current (nA)','FontSize',font_size);
title(['Synthetic Trace with SNR = ', num2str(SNR)]);

