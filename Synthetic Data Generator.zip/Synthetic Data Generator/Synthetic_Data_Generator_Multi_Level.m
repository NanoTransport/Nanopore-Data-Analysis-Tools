%% Refined Synthetic Event Trace with Controllable SNR and Connected Multi-Level Events

%----------------------------------------------------------------------  
% Main Trace Attributes
%----------------------------------------------------------------------  
window_mean = 21;          % nA
fre = 250e3;               % sampling rate in Hz
total_events_needed = 40;
baseline_instability_level = 1;

base_current = abs(window_mean);
current_sign = sign(window_mean);

%----------------------------------------------------------------------  
% Secondary Pulse and Trace Attributes
%----------------------------------------------------------------------  
en = -1;                     % 1=conductive, -1=resistive
target_max_sublevels = 3;    % max sub-levels
padpts = 10;                 % points for sigmoid transitions
noise_std = 0.2;             % baseline noise SD
event_noise_std = 0.2;       % event noise SD
min_SNR = 1.5;
max_SNR = 5;                 % signal-to-noise ratio (Have SNR >2)
trace_length_sec = 1;       
min_inter_event_distance=10; %in millliseconds

%----------------------------------------------------------------------  
% Pulse Boundaries
%----------------------------------------------------------------------  
dt_min = 10;   % microseconds
dt_max = 1000; % microseconds
dI_min = noise_std*1000*3.3*min_SNR;  % pA
dI_max = noise_std*1000*3.3*max_SNR;  % pA

%----------------------------------------------------------------------  
% Randomize Durations and Amplitudes
%----------------------------------------------------------------------  
dt_min_pts = round(fre * dt_min / 1e6);
dt_max_pts = round(fre * dt_max / 1e6);
dI_list = randi([dI_min dI_max], 1, total_events_needed) / 1000; % nA
dt_length_pts = randi([dt_min_pts dt_max_pts], 1, total_events_needed);

%----------------------------------------------------------------------  
% Trace Construction
%----------------------------------------------------------------------  
trace_length_pts = round(trace_length_sec * fre);
baseline_pts = trace_length_pts - dt_length_pts(end);

%----------------------------------------------------------------------  
% Baseline Noise
%----------------------------------------------------------------------  
trace_noise = randn(1, trace_length_pts) * noise_std;
opentrace = base_current + trace_noise;

%----------------------------------------------------------------------  
% ADD BASELINE INSTABILITIES
%----------------------------------------------------------------------  
drift = smoothdata(cumsum(0.001*baseline_instability_level * randn(1, trace_length_pts)),5,'loess');

% Apply baseline instability
opentrace = opentrace + drift;

%----------------------------------------------------------------------  
% Event Start Points (Enforce min spacing x ms)
%----------------------------------------------------------------------  
min_distance_pts = round(fre*min_inter_event_distance/1000);   % in ms minimum separation
event_occurance_pts = zeros(1, total_events_needed);

% First event can appear anywhere
event_occurance_pts(1) = randi([1 baseline_pts]);

for k = 2:total_events_needed
    placed = false;
    attempt = 0;

    while ~placed && attempt < 5000
        attempt = attempt + 1;
        candidate = randi([1 baseline_pts]);
        
        % Must be >=1 ms away from all previous events
        if all(abs(candidate - event_occurance_pts(1:k-1)) >= min_distance_pts)
            event_occurance_pts(k) = candidate;
            placed = true;
        end
    end

    % If random placement fails (very dense trace), force spacing
    if ~placed
        event_occurance_pts(k) = event_occurance_pts(k-1) + min_distance_pts;
    end
end

event_occurance_pts = sort(event_occurance_pts);

%----------------------------------------------------------------------  
% Generate Multi-Level Connected Events
%----------------------------------------------------------------------  
for i = 1:total_events_needed
    
    n_levels = randi([1,target_max_sublevels]);
    
    total_event_pts = dt_length_pts(i);
    temp = rand(1,n_levels);
    sublevel_pts = round(total_event_pts * temp / sum(temp));

    % Random amplitudes for sublevels
    dI_min_nA = dI_min / 1000;
    level_fraction = (randi([1 10],1,n_levels)) / 10; %goes from 0.5 to 1.0
    level_fraction = level_fraction / max(level_fraction);
    sub_level_mags = dI_min_nA + ((dI_list(i) - dI_min_nA) .* level_fraction);

    event_shape = [];
    prev_sublevel_mag = 0;
    
    for j = 1:n_levels
        present_sub_level = sub_level_mags(j);

        if j == 1
            transition_type = 1;
        else
            transition_type = sign(present_sub_level - prev_sublevel_mag);
        end
        
        if transition_type == 1
            transition_sigmoid = 1 ./ (1 + exp(-linspace(-6, 6, padpts)));
        else
            transition_sigmoid = 1 ./ (1 + exp( linspace(-6, 6, padpts)));
        end
        
        transition_part = prev_sublevel_mag + (present_sub_level - prev_sublevel_mag) .* transition_sigmoid;

        flat_part = ones(1, sublevel_pts(j)) * present_sub_level;

        segment = [transition_part, flat_part];
        
        event_shape = [event_shape, segment];
        
        prev_sublevel_mag = present_sub_level;
    end
    
    fall_sigmoid = 1 ./ (1 + exp(linspace(6, -6, padpts)));
    back_to_base = prev_sublevel_mag * (1 - fall_sigmoid);
    event_shape = [event_shape, back_to_base];
    
    event_noise = randn(1, length(event_shape)) * event_noise_std;
    noise_added_event = base_current + en * event_shape + event_noise;

    idx_start = event_occurance_pts(i);
    idx_end = min(idx_start + length(noise_added_event) - 1, trace_length_pts);
    opentrace(idx_start:idx_end) = noise_added_event(1:(idx_end - idx_start + 1));
end

%----------------------------------------------------------------------  
% Final Adjustments
%----------------------------------------------------------------------  
trace_data = current_sign * opentrace;

time_axis = (0:trace_length_pts-1)'/fre;

% Plot
minX = min(time_axis);
maxX = max(time_axis);
minY = min(trace_data);
maxY = max(trace_data);

color8 = [0.05 0.2 0.6];

plot(time_axis, trace_data, 'color', color8);
hold off

grid on
grid minor

xlim([minX maxX]);
ylim([minY maxY]);
xlabel('Time (s)');
ylabel('Current (nA)');
title(['Synthetic Trace with SNR = ', num2str(max_SNR)]);
