function decimals = CountDecimals(num)

%does not work with number like 5.00. The trailing decimals should be non
%zero
    strnum=num2str(num);
    decimalIdx = strfind(strnum, '.');

    if isempty(decimalIdx)
        decimals = 0;
    else
        decimals = length(strnum) - decimalIdx;
    end

end