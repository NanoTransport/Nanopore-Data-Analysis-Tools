function XP = Dropdownmenu(dropmenuValue)

    if strcmp(dropmenuValue,'Skewness (flag 0)')==1
        XP=4;
    elseif strcmp(dropmenuValue,'Skewness (flag 1)')==1
        XP=5;
    elseif strcmp(dropmenuValue,'Skewness (Left)')==1
        XP=6;
    elseif strcmp(dropmenuValue,'Skewness (Right)')==1
        XP=7;
    elseif strcmp(dropmenuValue,'Kurtosis (flag 0)')==1
        XP=8;
    elseif strcmp(dropmenuValue,'Kurtosis (flag 1)')==1
        XP=9;
    elseif strcmp(dropmenuValue,'Kurtosis (Left)')==1
        XP=10;
    elseif strcmp(dropmenuValue,'Kurtosis (Right)')==1
        XP=11;
    elseif strcmp(dropmenuValue,'Moment')==1
        XP=12;
    elseif strcmp(dropmenuValue,'Event Area (fC)')==1
        XP=13;
    elseif strcmp(dropmenuValue,'Event Area (End Points Anchored, fc)')==1
        XP=14;
    elseif strcmp(dropmenuValue,'ΔI (nA)')==1
        XP=15;
    elseif strcmp(dropmenuValue,'ΔI (End Points Anchored, nA)')==1
        XP=16;
    elseif strcmp(dropmenuValue,'Δt (ms)')==1
        XP=17;
    elseif strcmp(dropmenuValue,'Δt (End Points Anchored, ms)')==1
        XP=18;
    elseif strcmp(dropmenuValue,'log (Δt)')==1
        XP=19;
    elseif strcmp(dropmenuValue,'Event Std (nA)')==1
        XP=20;
    elseif strcmp(dropmenuValue,'Event Mean (nA)')==1
        XP=21;
    elseif strcmp(dropmenuValue,'Event Variance (nA)')==1
        XP=22;
    elseif strcmp(dropmenuValue,'Rectangularity (ΔI*Δt)')==1
        XP=23;
    elseif strcmp(dropmenuValue,'Rectangularity (ΔI anchored*Δt)')==1
        XP=24;
    elseif strcmp(dropmenuValue,'Aspect ratio (nA/ms)')==1
        XP=25;
    elseif strcmp(dropmenuValue,'Total Peaks')==1
        XP=26;
    elseif strcmp(dropmenuValue,'Max Slope (nA/µs, Left)')==1
        XP=27;
    elseif strcmp(dropmenuValue,'Max Slope (nA/µs, Right)')==1
        XP=28;
    elseif strcmp(dropmenuValue,'Event RMS (nA)')==1
        XP=29;
    elseif strcmp(dropmenuValue,'Q1')==1
        XP=30;
    elseif strcmp(dropmenuValue,'Q3')==1
        XP=31;
    elseif strcmp(dropmenuValue,'IQR')==1
        XP=32;
    elseif strcmp(dropmenuValue,'ΔMedian')==1
        XP=33;
    elseif strcmp(dropmenuValue,'WhiskerRange')==1
        XP=34;
    elseif strcmp(dropmenuValue,'WhiskerLow')==1
        XP=35;
    elseif strcmp(dropmenuValue,'WhiskerHigh')==1
        XP=36;
    elseif strcmp(dropmenuValue,'Plateau Stability')==1
        XP=37;
    elseif strcmp(dropmenuValue,'Plateau Kurtosis')==1
        XP=38;
    elseif strcmp(dropmenuValue,'Plateau Edge Ratio')==1
        XP=39;
    elseif strcmp(dropmenuValue,'Center of Mass')==1
        XP=40;
    elseif strcmp(dropmenuValue,'Lopsidedness')==1
        XP=41;
    elseif strcmp(dropmenuValue,'Time ReversalA symmetry')==1
        XP=42;
    elseif strcmp(dropmenuValue,'LAG1-ACF')==1
        XP=43;
    elseif strcmp(dropmenuValue,'Correlation Time (ms)')==1
        XP=44;
    elseif strcmp(dropmenuValue,'HF Wavelet Energy')==1
        XP=45;
    elseif strcmp(dropmenuValue,'LF Wavelet Energy')==1
        XP=46;
    elseif strcmp(dropmenuValue,'Spectral Centroid (Hz)')==1
        XP=47;
    elseif strcmp(dropmenuValue,'Peak Frequency (Hz)')==1
        XP=48;
    elseif strcmp(dropmenuValue,'Spectral Flatness')==1
        XP=49;
    elseif strcmp(dropmenuValue,'High to Low Frequency Ratio')==1
        XP=50;
    elseif strcmp(dropmenuValue,'Spectral Entropy')==1
        XP=51;
    elseif strcmp(dropmenuValue,'Shannon Entropy')==1
        XP=52;
    elseif strcmp(dropmenuValue,'Hjorth Mobility (1/ms)')==1
        XP=53;
    elseif strcmp(dropmenuValue,'Skewness of Derivative')==1
        XP=54;
    elseif strcmp(dropmenuValue,'Root Mean Square of Successive Differences (nA)')==1
        XP=55;
    elseif strcmp(dropmenuValue,'Median Absolute Deviation (nA)')==1
        XP=56;
    elseif strcmp(dropmenuValue,'Full Width at Half Maximum dt (ms)')==1
        XP=57;
    elseif strcmp(dropmenuValue,'ΔI/I0')==1
        XP=58;
    end

end