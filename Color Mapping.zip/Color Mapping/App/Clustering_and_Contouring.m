function [x_values_loop,y_values_loop,xlin,ylin,cont_density_final,stored_polygons,total_contours_calculated,contour_matrix,Xgrid,Ygrid,actual_clusters,clusterIdx,absolute_valid_event_indexes_loop]=Clustering_and_Contouring(pad_fraction,x_values,y_values,KDE_Pts,total_contours,cluster_method,target_clusters,absolute_valid_event_indexes,number_of_neighbours)

%-----------------------------------------------------------------------------------%
% Clustering
%-----------------------------------------------------------------------------------%
X = [x_values, y_values];

if cluster_method==1 %GMM
    
    % 1. Fit a Gaussian Mixture Model with 2 components
    %GMModel = fitgmdist(X, target_clusters, 'CovarianceType','full','RegularizationValue', 1e-5); : this is unstable

    GMModel = fitgmdist(X, target_clusters, ...
    'CovarianceType','full', ...
    'RegularizationValue',1e-5, ...
    'Start','plus', ...                % k-means++ like initialization
    'Replicates',10, ...               % run multiple fits, pick best
    'Options', statset('MaxIter',2000, 'TolFun',1e-8));

    % 2. Get the posterior probabilities (soft clustering)
    P = posterior(GMModel, X);  % Nx2 matrix, P(i,j) = probability point i belongs to cluster j

    % 3. Enforce consistent labeling by centroid position
    [~, order] = sort(GMModel.mu(:,1));   % sort by x-coordinate of mean
    P = P(:, order);                      % reorder posterior matrix
    
    % 4. Assign points to the cluster with maximum probability (hard assignment if needed)
    [~, clusterIdx] = max(P, [], 2);
    actual_clusters=max(clusterIdx);

elseif cluster_method==2 %KMeans

    %NOTES
    %K-means is inherently unstable because
    % it depends on random initialization, and boundary points (those "on the fence” between clusters) can flip between clusters from run to run.
    % Thatns why one may see "one or two points switching" even with Replicates
    
    % Fix random seed for reproducibility
    rng(1);  
                
   % 1. Run K-means clustering:
   [~, C] = kmeans(X, target_clusters, ...
                    'Replicates',10, ...         % multiple runs
                    'MaxIter',2000, ...          % max iterations
                    'Display','off', ...         
                    'Start','plus');             % k-means++ init
                
   % 2. Enforce consistent labeling (by x-position of centroids):
   [~, order] = sort(C(:,1));   % sort centroids left-to-right
   C = C(order,:);              % reorder centroids
                
   % Reassign points based on distance to final centroids
   D = pdist2(X, C);
   [~, clusterIdx] = min(D, [], 2);
                
   % 3. Save actual number of clusters found:
   actual_clusters = max(clusterIdx);

elseif cluster_method==3 %DBSCAN

    eps_val=std(y_values);%Epsilon neighborhood of a point,
    minpts_val=min([floor(length(y_values)*0.01);number_of_neighbours]);

    clusterIdx = dbscan(X, eps_val, minpts_val);
    actual_clusters = max(clusterIdx);

elseif cluster_method==4 %FCM

    % Requires Fuzzy Logic Toolbox

    %FCN
    options = fcmOptions(Exponent=2.0,...%This option controls the amount of fuzzy overlap between clusters
        NumClusters=target_clusters,...
    MaxNumIteration=200,...
    MinImprovement=0.001,...
    Verbose=false);

    [center, U] = fcm(X, options);
    U = U';  % U is kxN, transpose to Nxk for consistency

    % Sort centers by x-position (column 1)
    [~, order] = sort(center(:,1));
    U = U(:, order);

    %Hard assignment from soft membership matrix
    [~, clusterIdx] = max(U, [], 2);

    %Actual number of clusters
    actual_clusters = max(clusterIdx);

elseif cluster_method==5 %HIERARCHICAL CLUSTERING (HC)

    %hierarchical clustering tree
    Z = linkage(X, 'ward');

    %Extract cluster assignments
    clusterIdx = cluster(Z, 'maxclust', target_clusters);

    %Compute cluster centroids for consistent labeling
    C = zeros(target_clusters, size(X,2));
    for k = 1:target_clusters
        C(k,:) = mean(X(clusterIdx == k, :), 1);
    end

    %Reorder labels by centroid x-position for consistency
    [~, order] = sort(C(:,1));
    newIdx = zeros(size(clusterIdx));
    for k = 1:target_clusters
        newIdx(clusterIdx == order(k)) = k;
    end

    clusterIdx = newIdx;
    actual_clusters = max(clusterIdx);

elseif cluster_method==6 %Spectral Clustering (SC)

    % spectral clustering
    numNeighbors=min([floor(length(y_values)*0.01);number_of_neighbours]);% for kNN affinity
    clusterIdx = spectralcluster(X, target_clusters, ...
                                 'Distance','euclidean', ...
                                 'NumNeighbors',numNeighbors);

    %Compute cluster centroids
    C = zeros(target_clusters, size(X,2));
    for k = 1:target_clusters
        C(k,:) = mean(X(clusterIdx == k, :), 1);
    end

    %merging tiny clusters
    minClusterSize = numNeighbors;
    C = zeros(target_clusters, size(X,2));
    for k = 1:target_clusters
        pts = find(clusterIdx == k);
        if numel(pts) < minClusterSize
            % Merge with nearest cluster
            d = pdist2(X(pts,:), C);
            [~, nearestCluster] = min(mean(d,1));
            clusterIdx(pts) = nearestCluster;
        end
    end

    %Recompute centroids and label consistently
    C = zeros(target_clusters, size(X,2));
    for k = 1:target_clusters
        C(k,:) = mean(X(clusterIdx == k, :), 1);
    end

    %Consistent labeling by x-position of centroid
    [~, order] = sort(C(:,1));
    newIdx = zeros(size(clusterIdx));
    for k = 1:target_clusters
        newIdx(clusterIdx == order(k)) = k;
    end

    clusterIdx = newIdx;
    actual_clusters = max(clusterIdx);

else
    actual_clusters=1;
    clusterIdx=ones(length(x_values),1);
end

%-----------------------------------------------------------------------------------%
% KDE Grid
%-----------------------------------------------------------------------------------%

for i=1:actual_clusters

    x_values_loop{i} =X(clusterIdx==i,1);
    y_values_loop{i} =X(clusterIdx==i,2);
    absolute_valid_event_indexes_loop{i}=absolute_valid_event_indexes(clusterIdx==i);

    x_range = range(x_values_loop{i});
    y_range = range(y_values_loop{i});
    
    xlin{i} = linspace(min(x_values_loop{i})-pad_fraction*x_range, max(x_values_loop{i})+pad_fraction*x_range, KDE_Pts);
    ylin{i} = linspace(min(y_values_loop{i})-pad_fraction*y_range, max(y_values_loop{i})+pad_fraction*y_range, KDE_Pts);
    [Xgrid{i}, Ygrid{i}] = meshgrid(xlin{i}, ylin{i});
    
    %Bandwidth for kernel density estimation (KDE) (Scott's rule)
    bandwidth = [std(x_values_loop{i}), std(y_values_loop{i})] * length(x_values_loop{i})^(-1/6);
    xy = [x_values_loop{i}(:), y_values_loop{i}(:)];
    [cont_density, ~] = ksdensity(xy, [Xgrid{i}(:), Ygrid{i}(:)], 'Bandwidth', bandwidth);
    cont_density_final{i} = reshape(cont_density, size(Xgrid{i}));
    
    %-----------------------------------------------------------------------------------%
    % Extract contours
    %-----------------------------------------------------------------------------------%
    contour_matrix{i}=contourc(xlin{i}, ylin{i}, cont_density_final{i}, total_contours);

    %-----------------------------------------------------------------------------------%
    % Parse contour matrix C
    %-----------------------------------------------------------------------------------%
    idx = 1;
    polygons = {}; % store contours
    while idx < size(contour_matrix{i},2)
        level = contour_matrix{i}(1,idx);
        KDE_Pts = contour_matrix{i}(2,idx);
        polygon = contour_matrix{i}(:, idx+1 : idx+KDE_Pts); % [x; y] coords
        polygons{end+1} = struct('level',level,'x',polygon(1,:), 'y',polygon(2,:));
        idx = idx + KDE_Pts + 1;
    end
    
    %-----------------------------------------------------------------------------------%
    %Storing Polygons
    %-----------------------------------------------------------------------------------%
    stored_polygons{i}=polygons;
    total_contours_calculated{i}=numel(stored_polygons{i});
end

end