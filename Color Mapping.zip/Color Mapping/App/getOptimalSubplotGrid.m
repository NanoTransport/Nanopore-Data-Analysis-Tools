function [nRows, nCols] = getOptimalSubplotGrid(numPlots)
    % Find the optimal grid layout for subplots
    % Aims for near-square arrangement (similar rows and columns)
    
    if numPlots <= 0
        nRows = 0;
        nCols = 0;
        return;
    end
    
    % Calculate the square root
    sqrtNum = sqrt(numPlots);
    
    % Start with square root rounded up
    nCols = ceil(sqrtNum);
    nRows = ceil(numPlots / nCols);
    
    % Try to make it more balanced by checking nearby combinations
    bestDiff = abs(nRows - nCols);
    bestRows = nRows;
    bestCols = nCols;
    
    % Check a few alternatives
    for cols = floor(sqrtNum):ceil(sqrtNum)+2
        rows = ceil(numPlots / cols);
        diff = abs(rows - cols);
        
        % Prefer arrangements that are closer to square
        if diff < bestDiff || (diff == bestDiff && rows * cols < bestRows * bestCols)
            bestDiff = diff;
            bestRows = rows;
            bestCols = cols;
        end
    end
    
    nRows = bestRows;
    nCols = bestCols;
end