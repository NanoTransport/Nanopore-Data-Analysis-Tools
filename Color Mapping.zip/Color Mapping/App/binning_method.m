function [n_bins] = binning_method(binRule,X)
% Select a method to compute the bins (Not applicable to all methods)

            % Select a method to compute the bins
                  N=numel(X); %total observations
                  if strcmp(binRule,'Square Root')==1 %square root method
                        n_bins=ceil(sqrt(N));
                  elseif strcmp(binRule,'Struges')==1 % Sturges' rule
                        n_bins=ceil(1+log2(N));
                  elseif strcmp(binRule,'Rice')==1 %Rice rule
                        n_bins=ceil(2*N^(1/3));
                  elseif strcmp(binRule,'Scott')==1 %Scott's rule
                        b_width=3.49*std(X)/N^(1/3);
                        n_bins=ceil(range(X)/b_width);
                  else % Freedman-Diaconis rule
                        IQR = iqr(real(X)); 
                        b_width=2*IQR/N^(1/3);
                        n_bins=ceil(range(real(X))/b_width);
                  end
        
             if n_bins<=0
                n_bins=1; 
             end

end