function [lof_scores, is_outlier] = detectLOF(data, k)
    % Local Outlier Factor implementation
    n = size(data, 1);
    
    % Compute k-distance and k-neighbors for each point
    distances = pdist2(data, data);
    [sorted_dist, idx] = sort(distances, 2);
    
    k_neighbors = idx(:, 2:k+1); % Exclude self (index 1)
    k_distances = sorted_dist(:, k+1);
    
    % Compute reachability distance
    reach_dist = zeros(n, k);
    for i = 1:n
        for j = 1:k
            neighbor_idx = k_neighbors(i, j);
            reach_dist(i, j) = max(distances(i, neighbor_idx), k_distances(neighbor_idx));
        end
    end
    
    % Compute local reachability density
    lrd = zeros(n, 1);
    for i = 1:n
        lrd(i) = k / sum(reach_dist(i, :));
    end
    
    % Compute LOF scores
    lof_scores = zeros(n, 1);
    for i = 1:n
        neighbor_lrds = lrd(k_neighbors(i, :));
        lof_scores(i) = mean(neighbor_lrds) / lrd(i);
    end
    
    % Points with LOF > 1.5 are considered outliers
    is_outlier = lof_scores > 1.5;
end