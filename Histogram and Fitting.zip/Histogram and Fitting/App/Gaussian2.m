function [A1,mu,mode_of_the_fit,sigma,x_grid_vals,y_fit]=Gaussian2(Y,bin_count,Mag,mu,sigma,norm_method)

% Compute bin centers
[y_vals, bin_edges] = histcounts(Y, bin_count, 'Normalization',norm_method);
x_centers = (bin_edges(1:end-1) + bin_edges(2:end)) / 2;

%Fitting
x_len=length(bin_edges);
x_vals=zeros(x_len-1,1);

for i=1:x_len-1
    x_vals(i)=bin_edges(i)+(bin_edges(i+1)-bin_edges(i))/2;
end

if strcmp(norm_method,'pdf')==1
    myfittype=fittype('(1/(sigma*sqrt(2*pi)))*exp(-(((x-mu).^2)/(2*sigma^2)))','dependent',{'y'},'independent',{'x'},'coefficients',{'mu','sigma'});
    myfit = fit(x_vals,y_vals',myfittype,'StartPoint',[mu,sigma],'MaxIter', 1500,'TolFun', 1e-5);

    coefficientValues = coeffvalues(myfit);
    A1=1;
    mu=coefficientValues(1);
    sigma=coefficientValues(2);
else
    myfittype=fittype('A*exp(-(((x-mu).^2)/(2*sigma^2)))','dependent',{'y'},'independent',{'x'},'coefficients',{'A','mu','sigma'});
    myfit = fit(x_vals,y_vals',myfittype,'StartPoint',[Mag,mu,sigma],'MaxIter', 1500,'TolFun', 1e-5);

    coefficientValues = coeffvalues(myfit);
    A1=coefficientValues(1);
    mu=coefficientValues(2);
    sigma=coefficientValues(3);
end


% Generate smooth curve from fit
x_grid_vals = linspace(min(x_centers), max(x_centers), 500);
y_fit = myfit(x_grid_vals);

%finding the mode
[~,Index]=max(y_fit);
mode_of_the_fit = x_grid_vals(Index);
end