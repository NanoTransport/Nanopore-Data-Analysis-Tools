function continuous_time=cont_time(time_in)

time = time_in';

% Find where time decreases (indicates a new segment)
breaks = find(diff(time) < 0);

% Initialize continuous time
continuous_time = time;

% Add offsets for each segment
if ~isempty(breaks)
    for i = 1:length(breaks)
        % Calculate offset as the last value before break
        if i == 1
            offset = time(breaks(i));
        else
            offset = continuous_time(breaks(i));
        end
        
        % Apply offset to all subsequent values
        if i < length(breaks)
            continuous_time(breaks(i)+1:breaks(i+1)) = ...
                time(breaks(i)+1:breaks(i+1)) + offset;
        else
            continuous_time(breaks(i)+1:end) = ...
                time(breaks(i)+1:end) + offset;
        end
    end
end

end