function [Levens_pValue, p_Independent, p_Welch, p_MannWhitney, p_oneWayAnova, p_KruskalW, p_WelchAnova] = stat_tests_RunAll(X, group_block, total_files, alphaVal, Xmin, Xmax)
   
    % Initialize all outputs as NaN to handle mutually exclusive conditions safely
    Levens_pValue = NaN; p_Independent = NaN; p_Welch = NaN; p_MannWhitney = NaN;
    p_oneWayAnova = NaN; p_KruskalW = NaN;  p_WelchAnova = NaN;

    % ----------------------------------------------------------------------
    % 1. Universal Graphical Bounds Filtering
    % ----------------------------------------------------------------------
    % Apply UI axis limit clipping globally so statistics match the active plots
    if (Xmin==Xmax)==0 || Xmin>Xmax || Xmin==Xmax
        valid_mask = ~isnan(X) & ~isnan(group_block);
        X = X(valid_mask);
    else
        valid_mask = (X >= Xmin & X <= Xmax) & ~isnan(X) & ~isnan(group_block);
        X = X(valid_mask);
    end
    
    group_block = group_block(valid_mask);

    if isempty(X) || length(unique(group_block)) < 2
        return; % Guard condition if filtering empties the vectors
    end

    % ----------------------------------------------------------------------
    % 2. Homogeneity of Variance (Levene's Test)
    % ----------------------------------------------------------------------
    try
        [p_lev, ~] = vartestn(X, group_block, 'TestType', 'LeveneAbsolute', 'Display', 'off');
        Levens_pValue = p_lev;
    catch
        Levens_pValue = NaN;
    end

    % ----------------------------------------------------------------------
    % 3. Adaptive Location Testing Architecture
    % ----------------------------------------------------------------------
    if total_files == 2
        % Isolate individual pore populations cleanly using the filtered group IDs
        grp1 = X(group_block == 1);
        grp2 = X(group_block == 2);

        if isempty(grp1) || isempty(grp2), return; end

        % Execute Two-Sample Comparison Metrics
        try [~, p_Independent] = ttest2(grp1, grp2, 'Alpha', alphaVal); catch; end
        try [~, p_Welch] = ttest2(grp1, grp2, 'Alpha', alphaVal, 'Vartype', 'unequal'); catch; end
        try p_MannWhitney = ranksum(grp1, grp2, 'alpha', alphaVal); catch; end
        
    else
        % Execute Multi-Sample Comparison Metrics (N > 2)
        try p_oneWayAnova = anova1(X, group_block, 'off'); catch; end
        try p_KruskalW = kruskalwallis(X, group_block, 'off'); catch; end
        try [p_WelchAnova, ~,~,~] = welch_anova(X, group_block); catch; end 
    end
end