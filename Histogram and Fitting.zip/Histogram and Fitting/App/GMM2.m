function [mu,sigma,weights,x_grid_vals,y_fit,y_at_mu]=GMM2(Y,bin_count,populations,norm_method)

% Compute bin centers
if strcmp(norm_method,'pdf')==1
    [~, bin_edges] = histcounts(Y, bin_count, 'Normalization',norm_method);
else
    [Y_Data, bin_edges] = histcounts(Y, bin_count, 'Normalization',norm_method);
    Y=Y_Data';
end
x_centers = (bin_edges(1:end-1) + bin_edges(2:end)) / 2;

%Fitting
%fitgmdist uses the Expectation–Maximization (EM) algorithm to fit a Gaussian Mixture Model.
%By default, EM starts with random initial values for the component means (μ), covariances (Σ), and weights unless you explicitly set them.
%Instead of random starts, initialize with k-means or manual parameters:  'Start', 'plus'
%Let MATLAB try several random initializations and keep the best (lowest negative log-likelihood): 'Replicates', 5
rng(1,'twister');  % fix random seed
gmm = fitgmdist(Y, populations,'Options', statset('MaxIter',1500,'TolFun',1e-5),'Start', 'plus','Replicates', 5);
            
% Extract μ and σ from GMM
mu = gmm.mu;                   % means (populations x 1)
sigma = sqrt(squeeze(gmm.Sigma)); % std dev (populations x 1)
weights = (gmm.ComponentProportion)'; % mixture weights
            
% Generate smooth curve from fit
x_grid_vals = linspace(min(x_centers), max(x_centers), 500);
y_fit = pdf(gmm, x_grid_vals');

%peak values
y_at_mu = pdf(gmm, mu);

end