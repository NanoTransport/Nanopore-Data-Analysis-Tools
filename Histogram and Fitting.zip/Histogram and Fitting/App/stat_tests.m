function [Levens_pValue,testPVal] = stat_tests(X,total_files,total_samples,testType,alphaVal,Xmin,Xmax)

% Re-calculate change points based on the actual processed X vector
% This ensures indexing stays robust even if data was filtered
num_per_file = floor(length(X) / total_files);
group_block = repelem(1:total_files, num_per_file)';
% Adjust for any remainder to match length of X
if length(group_block) < length(X)
    group_block = [group_block; repmat(total_files, length(X)-length(group_block), 1)];
end

%----------------------------------------------------------------------
%Levene's Test:  homogeneity of variance
%----------------------------------------------------------------------
if total_samples>=2
    [p_value, ~] = vartestn(X, group_block, 'TestType', 'LeveneAbsolute', 'Display', 'off');
    Levens_pValue = p_value;
else
    Levens_pValue = NaN;
end

%------------------------------------------------------------------------------------------------
% 5. Statistical Execution
%------------------------------------------------------------------------------------------------

%testType = app.TestTypeDropDown.Value;
%alphaVal = app.SignificanceLevelEditField.Value;

switch testType
    case {'Independent-samples t-test', 'Welch’s t-test', 'Mann–Whitney U test'}
        if total_files ~= 2
            error('This test requires exactly 2 files/samples.');
        end

        % Prepare groups
        grp1 = X(group_block == 1);
        grp2 = X(group_block == 2);

        % Filter by Plot Limits
        if (Xmin==Xmax)==0 || Xmin>Xmax || Xmin==Xmax
            %do nothing
        else
            grp1 = grp1(grp1 >= Xmin & grp1 <= Xmax);
            grp2 = grp2(grp2 >= Xmin & grp2 <= Xmax);
        end
        if isempty(grp1) || isempty(grp2), error('No data points found within plot limits.'); end

        if strcmp(testType, 'Independent-samples t-test')
            [~, p] = ttest2(grp1, grp2, 'Alpha', alphaVal);
        elseif strcmp(testType, 'Welch’s t-test')
            [~, p] = ttest2(grp1, grp2, 'Alpha', alphaVal, 'Vartype', 'unequal');
        else
            p = ranksum(grp1, grp2, 'alpha', alphaVal);%Mann-Whitney U Test equivalent
        end
        testPVal = p;

    case {'One-way ANOVA', 'Kruskal–Wallis test','Welch’s ANOVA'}
        if total_files < 2, error('Test requires at least 2 groups.'); end

        if strcmp(testType, 'One-way ANOVA')
            p = anova1(X, group_block, 'off');
        elseif strcmp(testType, 'Kruskal–Wallis test')
            p = kruskalwallis(X, group_block, 'off');
        elseif strcmp(testType, 'Welch’s ANOVA')
            [p, ~, ~, ~] = welch_anova(X, group_block);
        end
        testPVal = p;
end

end