%----------------------------------------------------------------------
%Clear Fields and Load the Excel File
%----------------------------------------------------------------------
clear all
clc
file_in=readmatrix('2022_04_17_Extracted_Events_500mV.csv');

%----------------------------------------------------------------------
%Specify the X Column of the Excel File to be Histogrammed
%----------------------------------------------------------------------
X=file_in(:,6)*1000;

%----------------------------------------------------------------------
%Specify limits and other attributes of the histogram
%----------------------------------------------------------------------

%Filtering X based on the max and min values
X_min=0;
X_max=prctile(X,95);%95th percentile
X=X(X<X_max & X>X_min);

% Select a method to compute the bins
N=numel(X); %total observations
Method=5;
if Method==1 %square root method
    n_bins=ceil(sqrt(N));
elseif Method ==2 % Sturges' rule
    n_bins=ceil(1+log2(N));
elseif Method==3 %Rice rule
    n_bins=ceil(2*N^(1/3));
elseif Method==4 %Scott's rule
    b_width=3.49*std(X)/N^(1/3);
    n_bins=ceil(range(X)/b_width);
else % Freedman-Diaconis rule
    IQR = iqr(X); 
    b_width=2*IQR/N^(1/3);
    n_bins=ceil(range(X)/b_width);
end

%Constructing the histogram
h=histogram(X,n_bins);

%extracting bin values (x and y where x is the mid point of a bin)
y_vals=(h.Values)';
y_len=length(y_vals);
bin_edges = h.BinEdges;
bin_width=h.BinWidth;

x_vals=zeros(y_len,1);

for i=1:y_len
    x_vals(i)=bin_edges(i)+(bin_width/2);
end
%%
populations=2;

[y_vals,bin_edges]=histcounts(X,n_bins,'Normalization','pdf');

x_len=length(bin_edges);
x_vals=zeros(x_len-1,1);

for i=1:x_len-1
    x_vals(i)=bin_edges(i)+(bin_edges(i+1)-bin_edges(i))/2;
end

%fitgmdist uses the Expectation–Maximization (EM) algorithm to fit a Gaussian Mixture Model.
%By default, EM starts with random initial values for the component means (μ), covariances (Σ), and weights unless you explicitly set them.
%Instead of random starts, initialize with k-means or manual parameters:  'Start', 'plus'
%Let MATLAB try several random initializations and keep the best (lowest negative log-likelihood): 'Replicates', 5
rng(1,'twister');  % fix random seed
gmm = fitgmdist(X,populations,'Options', statset('MaxIter',1500,'TolFun',1e-5),'Start', 'plus','Replicates', 5);

max_X=max(x_vals);
min_X=min(x_vals);
I_step=abs(max_X-min_X)/100;
x_grid=min_X:I_step:max_X;
data=pdf(gmm,x_grid');

col_array=[0.5 0.3 0.9330];

figure,
d=histogram(X,n_bins);
d.Normalization='pdf'
set(d,'FaceColor',col_array,'EdgeColor',col_array);
hold on,
f=plot(x_grid,data,'black')
set(f,'LineWidth',2.5)
hold off

annotation('textbox',[.6 .5 .2 .25],'String',['Warning:  The Histogram is Normalized with pdf the Option']);
