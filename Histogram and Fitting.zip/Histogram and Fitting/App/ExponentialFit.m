%----------------------------------------------------------------------
%Clear Fields and Load the Excel File
%----------------------------------------------------------------------
clear all
clc
file_in=readmatrix('2022_04_17_Extracted_Events_500mV.csv');

%----------------------------------------------------------------------
%Specify the X Column of the Excel File to be Histogrammed
%----------------------------------------------------------------------
X=file_in(:,6);

%----------------------------------------------------------------------
%Specify limits and other attributes of the histogram
%----------------------------------------------------------------------

X_min=0;
X_max=prctile(X,95);%95th percentile

% Select a method to compute the bins
N=numel(X); %total observations
Method=5;
if Method==1 %square root method
    n_bins=ceil(sqrt(N));
elseif Method ==2 % Sturges' rule
    n_bins=ceil(1+log2(N));
elseif Method==3 %Rice rule
    n_bins=ceil(2*N^(1/3));
elseif Method==4 %Scott's rule
    b_width=3.49*std(X)/N^(1/3);
    n_bins=ceil(range(X)/b_width);
else % Freedman-Diaconis rule
    IQR = iqr(X); 
    b_width=2*IQR/N^(1/3);
    n_bins=ceil(range(X)/b_width);
end

%Filtering X based on the max and min values
X=X(X<X_max & X>X_min);

%Constructing the histogram
h=histogram(X,n_bins);

%extracting bin values (x and y where x is the mid point of a bin)
y_vals=(h.Values)';
y_len=length(y_vals);
bin_edges = h.BinEdges;
bin_width=h.BinWidth;

x_vals=zeros(y_len,1);

for i=1:y_len
    x_vals(i)=bin_edges(i)+(bin_width/2);
end
%%
%Fitting (seed values) 
Mag=100;
time_coeff=0.5;

%Create options for fitting
options = fitoptions('Method', 'NonlinearLeastSquares'); %Create the options object
options.MaxIter = 1000;  % Maximum number of iterations (default is 400)
options.MaxFunEvals = 1500; % Maximum number of function evaluations (default is 600)
options.TolX = 1e-7; % Tolerance on the change in the fitted coefficients (X); Lower value means stricter convergence (default is 1e-6)
options.TolFun = 1e-7;% Tolerance on the change in the Residual Sum of Squares (function value); Lower value means stricter convergence (default is 1e-6)


myfittype=fittype('A1*exp(-t/t0)','dependent',{'y'},'independent',{'t'},'coefficients',{'A1','t0'});
myfit = fit(x_vals,y_vals',myfittype,'StartPoint',[Mag,time_coeff],'Robust', 'on','Options', options);

col_array=[0.5 0.3 0.9330];

figure,
d=histogram(X,n_bins);
set(d,'FaceColor',col_array,'EdgeColor',col_array);
hold on,
f=plot(myfit,x_vals,y_vals,'.black');
set(f,'LineWidth',2.5)
hold off

grid on
grid minor

coefficientValues = coeffvalues(myfit);
A1=coefficientValues(1);
t0=coefficientValues(2);
str1 = sprintf('\n A1= %0.3f\n',A1);
str2 = sprintf(' t0= %0.3f',t0);
annotation('textbox',[.6 .5 .2 .2],'String',['Fit Parameters: ', str1, str2]);
