function [A1,t0,x_grid_vals,y_fit]=ExponentialFit2(Y,bin_count,Mag,time_coeff,cutoff_logic,x_cutoff,norm_method)

% Compute bin centers
[y_vals, bin_edges] = histcounts(Y, bin_count, 'Normalization',norm_method);
x_centers_pristine = (bin_edges(1:end-1) + bin_edges(2:end)) / 2;

if cutoff_logic==1 && isempty(x_cutoff)==0
    [~, Index] = max(y_vals);
    % bin_edges has (n+1) elements, y_vals has n elements
    filter_logic = x_centers_pristine > x_centers_pristine(Index);
    y_vals = y_vals(filter_logic);
    x_centers_filtered = x_centers_pristine(filter_logic);
    x_vals = x_centers_filtered;
else
    x_vals = x_centers_pristine;
end

myfittype=fittype('A1*exp(-t/t0)','dependent',{'y'},'independent',{'t'},'coefficients',{'A1','t0'});
myfit = fit(x_vals',y_vals',myfittype,'StartPoint',[Mag,time_coeff],'MaxIter', 1500,'TolFun', 1e-5);

coefficientValues = coeffvalues(myfit);
A1=coefficientValues(1);
t0=coefficientValues(2);

% Generate smooth curve from fit
x_grid_vals = linspace(min(x_centers_pristine), max(x_centers_pristine), 500);
y_fit = myfit(x_grid_vals);

end