function [A1_fit,lambda_fit,mu_fit,mode_of_the_fit,sigma_fit,x_grid_vals,y_fit]=Gaussian_Exponential_Tail2(Y,bin_count,Mag,lambda,mu,sigma,norm_method)

% Compute bin centers
[y_vals, bin_edges] = histcounts(Y, bin_count, 'Normalization',norm_method);
x_centers = (bin_edges(1:end-1) + bin_edges(2:end)) / 2;

%Fitting
x_len=length(bin_edges);
x_vals=zeros(x_len-1,1);

for i=1:x_len-1
    x_vals(i)=bin_edges(i)+(bin_edges(i+1)-bin_edges(i))/2;
end

%Remove NaN, Inf, or zero/negative values
valid_idx = isfinite(x_vals) & isfinite(y_vals') & y_vals' > 0;
x_vals = x_vals(valid_idx);
y_vals = y_vals(valid_idx);



if strcmp(norm_method,'pdf')==1
    %Prevent negative or zero values that cause NaN
    opts = fitoptions('Method', 'NonlinearLeastSquares', ...
        'StartPoint', [lambda, mu, sigma], ...
        'Lower', [max([lambda,lambda-0.001]), mu-range(x_vals), sigma*0.001], ...      
        'Upper', [lambda+0.1, mu+range(x_vals), sigma*10], ...        
        'MaxIter', 1500, ...
        'TolFun', 1e-5);  % Show progress to debug
    
    %fittype
    myfittype = fittype('(L/2).*(exp(L/2.*((2*a)+(L*(b^2))-(2.*x)))).*(erfc((a+(L*(b^2))-x)./(sqrt(2)*b)))', ...
        'dependent', {'y'}, ...
        'independent', {'x'}, ...
        'coefficients', {'L', 'a', 'b'});
    
    myfit = fit(x_vals,y_vals',myfittype,opts);
    
    coefficientValues = coeffvalues(myfit);
    A1_fit=1;
    lambda_fit=coefficientValues(1);
    mu_fit=coefficientValues(2);
    sigma_fit=coefficientValues(3);
else
    %Prevent negative or zero values that cause NaN
    opts = fitoptions('Method', 'NonlinearLeastSquares', ...
        'StartPoint', [Mag, lambda, mu, sigma], ...
        'Lower', [min(y_vals)-0.001, max([lambda,lambda-0.001]), mu-range(x_vals), sigma*0.001], ...      
        'Upper', [max(y_vals)*10, lambda+0.1, mu+range(x_vals), sigma*10], ...        
        'MaxIter', 1500, ...
        'TolFun', 1e-5);  % Show progress to debug
    
    %fittype
    myfittype = fittype('A.*(exp(L/2.*((2*a)+(L*(b^2))-(2.*x)))).*(erfc((a+(L*(b^2))-x)./(sqrt(2)*b)))', ...
        'dependent', {'y'}, ...
        'independent', {'x'}, ...
        'coefficients', {'A', 'L', 'a', 'b'});
    
    myfit = fit(x_vals,y_vals',myfittype,opts);
    
    coefficientValues = coeffvalues(myfit);
    A1_fit=coefficientValues(1);
    lambda_fit=coefficientValues(2);
    mu_fit=coefficientValues(3);
    sigma_fit=coefficientValues(4);
end

% Generate smooth curve from fit
x_grid_vals = linspace(min(x_centers), max(x_centers), 500);
y_fit = myfit(x_grid_vals);

%finding the mode
[~,Index]=max(y_fit);
mode_of_the_fit = x_grid_vals(Index);

end