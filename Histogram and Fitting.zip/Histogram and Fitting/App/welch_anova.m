function [p_value, F_stat, df1, df2] = welch_anova(data, group)
    % Welch's ANOVA - robust to unequal variances
    % Similar to Welch's t-test but for multiple groups
    
    groups = unique(group);
    k = length(groups);  % Number of groups
    
    % Calculate weights, means, and variances for each group
    n = zeros(k, 1);
    means = zeros(k, 1);
    vars = zeros(k, 1);
    weights = zeros(k, 1);
    
    for i = 1:k
        idx = group == groups(i);
        n(i) = sum(idx);
        means(i) = mean(data(idx));
        vars(i) = var(data(idx));
        weights(i) = n(i) / vars(i);  % Weight = n/variance
    end
    
    % Weighted grand mean
    grand_mean = sum(weights .* means) / sum(weights);
    
    % Numerator (between-group variability)
    numerator = sum(weights .* (means - grand_mean).^2) / (k - 1);
    
    % Denominator correction factor
    lambda = 3 * sum((1 - weights/sum(weights)).^2 ./ (n - 1)) / (k^2 - 1);
    
    % Welch's F-statistic
    F_stat = numerator / (1 + 2*(k-2)/(k^2-1) * lambda);
    
    % Degrees of freedom
    df1 = k - 1;
    df2 = 1 / (lambda + eps);  % Add eps to avoid division by zero
    
    % P-value
    p_value = 1 - fcdf(F_stat, df1, df2);
end