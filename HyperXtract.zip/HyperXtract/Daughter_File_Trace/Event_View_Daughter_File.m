%*********************************************************************************************
%File Loading
%
%       Important Files Needed
%       i. The Event Location Excel File (Has the tag _Event_LOCS for files  from HX)
%       ii. Daughter file (in .bin format)

%       Important Detaisl
%       i. Change the MATLAB to be same as the path of the Event Location and Daughter files
%       ii. Set the Sampling Rate (in Hz)
%*********************************************************************************************

%Event Location File
file_locs=readmatrix('Event_data_NewTest_EVENT_LOCS_11_40_34.csv');
start_pts=file_locs(:,1);
event_lengths=file_locs(:,2);

%Binary file
daughter_file_name='Event_data_NewTest_11_40_34.bin';

%Sampling Rate
fre=250*1000;%sampling rate in Hz
t_advance=0;

%Events to View
events_to_view_list=[1;2;3;4;5;6;7;8;9;50];

%Plot Colors
color1=[0.6350 0.0780 0.1840]+0.1;
color2=[0.350 0.80 0.0840];
color3=[0.5 0.1 0.02];
color4=[0.1 0.1 0.9];
color5=[0.9 0.1 0.9];
color6=[0.5 0.05 0.9];
color7=[0.1 0.3 0.1];
color8=[0.05 0.2 0.6];
color9=[0.0 0.0 0.0]+0.2;

%Loading and plotting the events
for i=1:length(events_to_view_list)

%Reading event data from the daughter file using the locations in the Event Location File
fileID_data = fopen(daughter_file_name,'r');
event_to_view=events_to_view_list(i);
BTPR=4;%bytes per reading
skip_pts=start_pts(event_to_view);
fseek(fileID_data,skip_pts*BTPR,'bof');
event_data_pts=event_lengths(event_to_view);
event_data=fread(fileID_data,event_data_pts,'float32');
fclose(fileID_data);

time_length=(((1:length(event_data))/fre)*1000)+t_advance;%time in ms
t_advance=time_length(end);

b=mod(event_to_view,2);
if b==1
    plot(time_length',event_data,'color',color4,'LineWidth',1.1)
else
    plot(time_length',event_data,'color',color1,'LineWidth',1.1)
end
hold on
end
hold off

%Grid attributes
ax=gca;
grid on
grid minor
ax.GridColor = [0.1, 0.7, 0.2]; % Dark Green.
ax.MinorGridColor = [0.1, 0.7, 0.2]; % Dark Green.

%Axes Font Size
font_size=14;
ax.XAxis.FontSize = font_size;
ax.YAxis.FontSize = font_size;

%Plot Limits
xlim([0 time_length(end)]);
%ylim([10 32]);

%Axes Lables
ylabel('I (nA)','FontSize',font_size)
xlabel('Time (ms)','FontSize',font_size)
