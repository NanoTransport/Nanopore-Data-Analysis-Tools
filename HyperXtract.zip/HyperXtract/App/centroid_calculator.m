function[Cx,Cy,total_centroid_events,Cx_mean,Cy_mean,WCSS,avgDist,radius,diameter,polyArea,density]=centroid_calculator(polygons,fetch_contour,x_values,y_values)

    %Contour line
    if isempty(polygons)==1
    
        Cx=0;
        Cy=0;
        total_centroid_events=0;
        Cx_mean = 0;
        Cy_mean = 0;
        WCSS=0;
        avgDist=0;
        radius=0;
        diameter=0;
        polyArea=0;
        density=0;

    else
    poly = polygons{fetch_contour};
    x = poly.x(:);   % column vectors
    y = poly.y(:);
    
    % close polygon if not already closed
    if x(1) ~= x(end) || y(1) ~= y(end)
        x = [x; x(1)];
        y = [y; y(1)];
    end
    
    %--------------------------------------------------------
    %    1. Polygon centroid (analytic shoelace formula)
    %--------------------------------------------------------
    cross = x(1:end-1).*y(2:end) - x(2:end).*y(1:end-1);
    A = 0.5 * sum(cross);
    
    % centroid coordinates
    Cx = (1/(6*A)) * sum( (x(1:end-1) + x(2:end)) .* cross );
    Cy = (1/(6*A)) * sum( (y(1:end-1) + y(2:end)) .* cross );
    
    %--------------------------------------------------------
    %    2. Fetch points inside this polygon
    %--------------------------------------------------------
    in = inpolygon(x_values, y_values, poly.x, poly.y);
    
        if sum(in)>0 %following calculations are only possible if we have points inside a polygo
        
                x_fetched = x_values(in);
                y_fetched = y_values(in);
                total_centroid_events=length(x_fetched);
              
                %--------------------------------------------------------
                %    3. Cluster centroid (mean of data points)
                %--------------------------------------------------------
                Cx_mean = mean(x_fetched);
                Cy_mean = mean(y_fetched);
              
                %--------------------------------------------------------
                %    4. Within-Cluster Sum of Squares (WCSS)
                %--------------------------------------------------------
                %This measures compactness — the sum of squared distances from each point to the cluster centroid:
                distances_sq = (x_fetched - Cx_mean).^2 + (y_fetched - Cy_mean).^2;
                WCSS = sum(distances_sq);
              
                %--------------------------------------------------------
                %    5. Average Distance
                %--------------------------------------------------------
                %Average Distance to Centroid
                
                avgDist = sqrt(mean(distances_sq));
                
                %--------------------------------------------------------
                %    6. Radius and Diameter
                %--------------------------------------------------------
                %Radius: maximum distance from centroid to any point.
                %Diameter: maximum pairwise distance inside cluster.
                
                radius = sqrt(max(distances_sq));
                    if numel(x_fetched) > 1
                        D = pdist([x_fetched(:), y_fetched(:)]);
                        diameter = max(D);
                    else
                        diameter = 0;
                    end
                
                %--------------------------------------------------------
                %    7. Area and Density
                %-------------------------------------------------------- 
                %polygon area
                %density:  number events/area
                polyArea = polyarea(poly.x, poly.y);
                density = numel(x_fetched) / polyArea;
                
        else
            total_centroid_events=0;
            Cx_mean = 0;
            Cy_mean = 0;
            WCSS=0;
            avgDist=0;
            radius=0;
            diameter=0;
            polyArea=0;
            density=0;
        end
    end
end