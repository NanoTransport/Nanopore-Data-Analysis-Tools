function mean_interaction = Dropdownmenu_profilebuilder(data,dropmenuValue)

                if strcmp(dropmenuValue,'Mean')==1
                    interactions = data(:,4:end-1);%everything except the last column which contains the total number of centroid events
                    % Compute mean interaction across all remaining columns
                    mean_interaction = mean(interactions, 2, 'omitnan');
    
                elseif strcmp(dropmenuValue,'Max X (polygon)')==1
                    mean_interaction = data(:,4);
    
                elseif strcmp(dropmenuValue,'Max Y (polygon)')==1
                    mean_interaction = data(:,5);
    
                elseif strcmp(dropmenuValue,'Centroid X')==1
                    mean_interaction = data(:,6);
    
                elseif strcmp(dropmenuValue,'Centroid Y')==1
                    mean_interaction = data(:,7);
    
                elseif strcmp(dropmenuValue,'Centroid X Mean')==1
                    mean_interaction = data(:,8);
                
                 elseif strcmp(dropmenuValue,'Centroid Y Mean')==1
                    mean_interaction = data(:,9);
    
                elseif strcmp(dropmenuValue,'Aspect Ratio (Polygon)')==1
                    mean_interaction = data(:,10);

                elseif strcmp(dropmenuValue,'Aspect Ratio (Mean)')==1
                    mean_interaction = data(:,11);
    
                elseif strcmp(dropmenuValue,'WCSS')==1
                    mean_interaction = data(:,12);
    
                elseif strcmp(dropmenuValue,'Average Distance')==1
                    mean_interaction = data(:,13);
    
                elseif strcmp(dropmenuValue,'Radius')==1
                    mean_interaction = data(:,14);
    
                elseif strcmp(dropmenuValue,'Diameter')==1
                    mean_interaction = data(:,15);
    
                elseif strcmp(dropmenuValue,'Ploygon Area')==1
                    mean_interaction = data(:,16);
    
                elseif strcmp(dropmenuValue,'Density')==1
                    mean_interaction = data(:,17);
                end

end