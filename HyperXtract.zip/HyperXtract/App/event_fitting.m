function [mean_level_I_t,level_I_t,total_base_line_mean,total_base_line_std,base_left_mean,base_right_mean,ipt] = event_fitting(y,t,ipt,EPR,MEP)

number_of_levels=length(ipt)-1;
mean_level_I_t=[];

base_left=y(1:ipt(1));
base_left_mean=mean(base_left);
bae_right=y(ipt(end):end);
base_right_mean=mean(bae_right);
mean_level_I_t=[mean_level_I_t;t(1) base_left_mean;t(ipt(1)) base_left_mean];

level_I_t=[];
total_base_line_mean=mean([base_left;bae_right]);
total_base_line_std=std([base_left;bae_right]);

i=1;
while i<=number_of_levels
    
  if  ipt(i+1)-ipt(i)>MEP %must have atleast 2 points in the level
      
    current_level=y(ipt(i):ipt(i+1)-1);

    %evaluating the nature of the sub-level (need to have a minimum of 3 levels for this to work)
    if number_of_levels>=3 && i>1 && i<number_of_levels-1 %only events with 4 or more levels get evaluated in this first if loop due to i<number_of_levels-1 condition
        previosu_level=y(ipt(i-1):ipt(i)-1);
        previous_level_mean=mean(previosu_level);
        
        next_level=y(ipt(i+1):ipt(i+2)-1);
        next_level_mean=mean(next_level);
        
        current_level_mean_prel=mean(current_level);
        if previous_level_mean<current_level_mean_prel && next_level_mean<current_level_mean_prel
            level_nature=1;%a peak
        elseif previous_level_mean>current_level_mean_prel && next_level_mean>current_level_mean_prel
            level_nature=-1;%a valley
        else
            level_nature=0;%a connecting level
        end
    else
    %For events with only two or more levels
        if number_of_levels==3 && i==1
            next_level=y(ipt(i+1):ipt(i+2)-1);
            next_level_mean=mean(next_level);
            current_level_mean_prel=mean(current_level);
            
            if next_level_mean<current_level_mean_prel
                level_nature=0;%treat as a connecting level (although looks like a peak)
            else
                level_nature=-1;%a valley
            end
        elseif number_of_levels==3 && i==2
            previosu_level=y(ipt(i-1):ipt(i)-1);
            previous_level_mean=mean(previosu_level);

            next_level=y(ipt(i+1):ipt(i+2)-1);
            next_level_mean=mean(next_level);

            current_level_mean_prel=mean(current_level);
            if previous_level_mean<current_level_mean_prel && next_level_mean<current_level_mean_prel
                level_nature=1;%a peak
            elseif previous_level_mean>current_level_mean_prel && next_level_mean>current_level_mean_prel
                level_nature=-1;%a valley
            else
                level_nature=0;%a connecting level
            end
        elseif number_of_levels==3 && i==3
            previosu_level=y(ipt(i-1):ipt(i)-1);
            previous_level_mean=mean(previosu_level);
            current_level_mean_prel=mean(current_level);
            
            if previous_level_mean<current_level_mean_prel
                level_nature=0;%treat as a connecting level (although looks like a peak)
            else
                level_nature=-1;%a valley
            end
        elseif number_of_levels==2 && i==1
            next_level=y(ipt(i+1):ipt(i+2)-1);
            next_level_mean=mean(next_level);
            current_level_mean_prel=mean(current_level);
            
            if next_level_mean<current_level_mean_prel
                level_nature=0;%treat as a connecting level (although looks like a peak)
            else
                level_nature=-1;%a valley
            end
         elseif number_of_levels==2 && i==2
            previosu_level=y(ipt(i-1):ipt(i)-1);
            previous_level_mean=mean(previosu_level);
            current_level_mean_prel=mean(current_level);
            
            if previous_level_mean<current_level_mean_prel
                level_nature=0;%treat as a connecting level (although looks like a peak)
            else
                level_nature=-1;%a valley
            end   
        else
            level_nature=0;%single level:  treated as a connecting level
            current_level_mean_prel=mean(current_level);
        end
        
    end
    
    %adjusting the peak value based on the nature of the level (i.e., peak,valley or connecting)
    if level_nature==1 % a peak
        if length(current_level)>=3
            pks=findpeaks(current_level);
            if length(pks)<=2 %short event
                current_level_mean=max(current_level);
            else
                current_level_mean=mean(current_level(current_level>current_level_mean_prel));
            end
        else
            current_level_mean=max(current_level);
        end
        
    elseif level_nature==-1 % a valley
        if length(current_level)>=3
            vals=findpeaks(-current_level);
            if length(vals)<=2 %short event
                current_level_mean=min(current_level);
            else
                current_level_mean=mean(current_level(current_level<current_level_mean_prel));
            end
        else
            current_level_mean=min(current_level);
        end
    else %connecting level or 2 or less sub levels in the event
        if length(current_level)>=3
            vals=findpeaks(-current_level);
            if number_of_levels==1 %single level events can be either long ones or short spiky ones
                if isempty(vals)==0 && length(vals)>=2 %typically a long single level event
                    current_level_mean=mean(current_level);
                else %short spiky single level event
                    current_level_mean=min(current_level);
                end
            else %non-single levels events (could be connecting or 2 level events)
                if isempty(vals)==0 && length(vals)>=1
                    current_level_mean=mean(current_level);
                else %short event
                    current_level_mean=min(current_level);
                end
            end
        else %very short event (i.e., like a spike)
            current_level_mean=min(current_level);
        end
    end
    
    if EPR==1 && (i==1 || i==number_of_levels) && number_of_levels>1 %Edge Point Refining (not on single level events)
    %i=2 is the begining of the firt event (i=1 is the left baseline)
    %i=number_of_levels-1 is the begining of the last level
    
        %checking crossing points to determine the validity of the event
        if length(current_level)>=2
            crossing_pts=abs(diff(current_level>current_level_mean));%1 would be a crossing point
            total_crossing_pts=sum(crossing_pts);
        else
            total_crossing_pts=0;
        end
    else
        total_crossing_pts=2;
    end
    
    if total_crossing_pts>=2
        %populating the array for level plotting
        mean_level_I_t=[mean_level_I_t;t(ipt(i)) current_level_mean;t(ipt(i+1)) current_level_mean];
    
        %level details (dI, dt and I_level)
        dt=t(ipt(i+1))-t(ipt(i));
        dI=total_base_line_mean-current_level_mean;
        level_I_t(i,:)=[dI dt current_level_mean];
        i=i+1;
    else
        ipt(i+1)=[];
        number_of_levels=number_of_levels-1;
    end
  else
        ipt(i+1)=[];
        number_of_levels=number_of_levels-1;
  end  
end

if number_of_levels==0 %all information about the signal is lost--> resoting to single level analysis
    expected_change_points=2;
    ipt_bounds=findchangepts(y,'Statistic','mean','MaxNumChanges',2);
    if length(ipt_bounds)<expected_change_points
        i=1;
        while length(ipt_bounds)<expected_change_points
            ipt_bounds=findchangepts(y,'Statistic','mean','MaxNumChanges',2+i);
            i=i+1;
        end  
    end
    ipt=[ipt_bounds(1)-1;ipt_bounds(end)];
    current_level=y(ipt(1):ipt(2));
    if length(current_level)>=3
            vals=findpeaks(-current_level);
            if isempty(vals)==0 && length(vals)>=2 %typically a long single level event
                current_level_mean=mean(current_level);
            else %short spiky single level event
                current_level_mean=min(current_level);
            end
    else
        current_level_mean=min(current_level);
    end
    %populating the fit values
    mean_level_I_t=[];
    mean_level_I_t=[mean_level_I_t;t(1) base_left_mean;t(ipt(1)-1) base_left_mean];
    mean_level_I_t=[mean_level_I_t;t(ipt(1)) current_level_mean;t(ipt(2)) current_level_mean];
    
    %level details (dI, dt and I_level)
    level_I_t=zeros(1,3);
    dt=t(ipt(1))-t(ipt(2));
    dI=total_base_line_mean-current_level_mean;
    level_I_t(1,:)=[dI dt current_level_mean];
end

mean_level_I_t=[mean_level_I_t;t(ipt(end)) base_right_mean;t(end) base_right_mean];

end