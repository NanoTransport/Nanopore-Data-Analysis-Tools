function gmm=GMM(dI,bin_count,populations)

[~,bin_edges]=histcounts(dI,bin_count,'Normalization','pdf');

x_len=length(bin_edges);
x_vals=zeros(x_len-1,1);

for i=1:x_len-1
    x_vals(i)=bin_edges(i)+(bin_edges(i+1)-bin_edges(i))/2;
end

%fitgmdist uses the Expectation–Maximization (EM) algorithm to fit a Gaussian Mixture Model.
%By default, EM starts with random initial values for the component means (μ), covariances (Σ), and weights unless you explicitly set them.
%Instead of random starts, initialize with k-means or manual parameters:  'Start', 'plus'
%Let MATLAB try several random initializations and keep the best (lowest negative log-likelihood): 'Replicates', 5
rng(1,'twister');  % fix random seed
gmm = fitgmdist(dI,populations,'Options', statset('MaxIter',1500,'TolFun',1e-5),'Start', 'plus','Replicates', 5);

max_X=max(x_vals);
min_X=min(x_vals);
I_step=abs(max_X-min_X)/100;
x_grid=min_X:I_step:max_X;
data=pdf(gmm,x_grid');

col_array=[0.5 0.3 0.9330];

figure,
d=histogram(dI,bin_count);
d.Normalization='pdf'
set(d,'FaceColor',col_array,'EdgeColor',col_array);
hold on,
f=plot(x_grid,data,'black')
set(f,'LineWidth',2.5)
hold off
grid on

annotation('textbox',[.6 .5 .2 .25],'String',['Warning:  The Histogram is Normalized with pdf the Option']);
end