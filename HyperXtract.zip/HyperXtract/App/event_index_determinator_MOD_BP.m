function [event_count_in,simple_metrics_array,event_data_bounds,biphasic_logic,st_pt_FP,end_pt_FP,end_pt_SP,final_change_pt,smooth_data_BFL]=event_index_determinator_MOD_BP(d_filter,fre,win_data_length,one_loop_time_sec,starting_time,PAD_L,PAD_R,event_count_in,event_indexes,back_step,window_mean,max_events_per_win,main_loop_i,window_std,simple_metrics_array,event_data_bounds,scan_ahead_ms,scan_back_ms,step_size,GSF,major_PDC,minor_PDC,first_pulse_nature,second_pulse_nature,BP_type,EA,dI_adjustment)

%SPEED MODE DOES NOT WORK WITH THIS FUNCTION
%speed_mode and SMRP inputs are removed

i=main_loop_i;
if isempty(event_indexes)==0
    
            j=1;
            baseline_threshold=back_step*window_mean;
            %BEEI=index_temp(d_filter>=back_step*window_mean);%Baseline Entrance and Exit Indexes: REMOVED 09/05/2024 (NB)

            if dI_adjustment~=0 %added on 10/25/2025 to get a true value of the baseline mean for conductive pulses
                window_mean_to_save=abs(mean(d_filter-dI_adjustment));
            else
                window_mean_to_save=window_mean;
            end

            while isempty(event_indexes)==0 && j<max_events_per_win
                  event_count_in=event_count_in+1;
                  
                  %Event Start and End Point Deduction:  vectorized approach modified on 09/05/2024 (NB)
                  entrace_index=event_indexes(1);
                  ii=0;
                  while d_filter(entrace_index-ii)<=baseline_threshold && entrace_index-ii>1
                           ii=ii+1;
                  end
                  event_start_index_WS=entrace_index-ii;%WS=Without Scanning
                
                  ii=0;
                  while d_filter(entrace_index+ii)<=baseline_threshold && entrace_index+ii<win_data_length
                          ii=ii+1;
                  end
                  event_exit_index_WS=entrace_index+ii;%WS=Without Scanning

                  %Scanning ahead
                  scan_ahead_pts=floor((scan_ahead_ms/1000)*fre);
                  if scan_ahead_pts+event_exit_index_WS>win_data_length
                        scan_ahead_pts=win_data_length-event_exit_index_WS;
                  end
                  event_exit_index=event_exit_index_WS+scan_ahead_pts;

                  %Scanning back
                  scan_back_pts=floor((scan_back_ms/1000)*fre);
                  if event_start_index_WS-scan_back_pts<1
                        scan_back_pts=event_start_index_WS-1;
                  end
                  event_start_index=event_start_index_WS-scan_back_pts;

                  %event padding
                  pad_right=min([PAD_R win_data_length-event_exit_index]);
                  pad_left=min([PAD_L event_start_index-1]);
                  dt_pts=event_exit_index_WS-event_start_index_WS;%event length in points
                  %End of Start and End Point deduction added on 09/05/2024

                  %------------------------------------------------------------------------------------------------
                  %Biphasic events and extracting their metrics:  added on 10/15/2025
                  %------------------------------------------------------------------------------------------------

                      event_with_padding=d_filter(event_start_index-pad_left:event_exit_index+pad_right);
                      if BP_type==1 %Leading pulse is the main pulse
                            data_indexes=[1;pad_left+scan_back_pts+dt_pts;length(event_with_padding)];%[start point, transition point, end point]
                      else %Trailing pulse is the main pulse
                            data_indexes=[1;pad_left+scan_back_pts;length(event_with_padding)];%[start point, transition point, end point]
                      end

                      [biphasic_logic,st_pt_FP,end_pt_FP,end_pt_SP,first_change_pt,final_change_pt,smooth_data_BFL,skip_event]=Biphasic_Pulse_Extraction(event_with_padding,data_indexes,window_mean,back_step,step_size,GSF,major_PDC,minor_PDC,first_pulse_nature,second_pulse_nature,BP_type,EA);
                      
                      if skip_event==0 %keep the event
                          if biphasic_logic==1
                              %true event start and end indexes
                              true_event_start_index=(event_start_index-pad_left)+first_change_pt(1);%-pad_left becuase we are rewinding the event from this many points behind the actual event due to event padding
                              true_event_exit_index=(event_start_index-pad_left)+final_change_pt(end);%-pad_left becuase we are rewinding the event from this many points behind the actual event due to event padding
        
                              %event metrics
                              event_start_time_absolute=(((i-1)*one_loop_time_sec)+(true_event_start_index/fre))+starting_time;
                              event_end_time_absolute=(((i-1)*one_loop_time_sec)+(true_event_exit_index/fre))+starting_time;
                              
                              %leading pulse
                              pulse_width_L=((end_pt_FP-first_change_pt(1))/fre)*1000;%in ms
                              if first_pulse_nature==1 %resistive
                                  pulse_depth_L=min(event_with_padding(first_change_pt(1):end_pt_FP))-window_mean;%in nA
                              else %conductive
                                  pulse_depth_L=max(event_with_padding(first_change_pt(1):end_pt_FP))-window_mean;%in nA
                              end
                              
                              %trailing pulse
                              pulse_width_T=((final_change_pt(end)-end_pt_FP)/fre)*1000;%in ms
                              if second_pulse_nature==1 %resistive
                                  pulse_depth_T=min(event_with_padding(end_pt_FP:final_change_pt(end)))-window_mean;%in nA
                              else %conductive
                                  pulse_depth_T=max(event_with_padding(end_pt_FP:final_change_pt(end)))-window_mean;%in nA
                              end
    
                          else %not a biphasic event
    
                              event_to_save=d_filter(event_start_index_WS:event_exit_index_WS);
    
                              %event metrics
                              event_start_time_absolute=(((i-1)*one_loop_time_sec)+(event_start_index_WS/fre))+starting_time;
                              event_end_time_absolute=(((i-1)*one_loop_time_sec)+(event_exit_index_WS/fre))+starting_time;
    
                              if BP_type==1 %Leading pulse is the prominent pulse
                                  pulse_width_L=(event_end_time_absolute-event_start_time_absolute)*1000;%in ms
                                  pulse_depth_L=min(event_to_save-window_mean);%in nA

                                  pulse_width_T=0;
                                  pulse_depth_T=0;
                              else
                                  pulse_width_T=(event_end_time_absolute-event_start_time_absolute)*1000;%in ms
                                  pulse_depth_T=min(event_to_save-window_mean);%in nA

                                  pulse_width_L=0;
                                  pulse_depth_L=0;
                              end

                              pad_right=min([PAD_R win_data_length-event_exit_index_WS]);
                              pad_left=min([PAD_L event_start_index_WS-1]);
                          end
                            
                      else %Biphasic_Pulse_Extraction has failed

                          %treating as a non-biphasic event due to falure in the biphasic event detection function
                          event_exit_index=(event_exit_index-scan_ahead_pts);
                          event_to_save=d_filter(event_start_index+scan_back_pts:event_exit_index);
    
                          %event metrics
                          event_start_time_absolute=(((i-1)*one_loop_time_sec)+(event_start_index/fre))+starting_time;
                          event_end_time_absolute=(((i-1)*one_loop_time_sec)+(event_exit_index/fre))+starting_time;

                          if BP_type==1 %Leading pulse is the prominent pulse
                               pulse_width_L=(event_end_time_absolute-event_start_time_absolute)*1000;%in ms
                               pulse_depth_L=min(event_to_save-window_mean);%in nA

                               pulse_width_T=0;
                               pulse_depth_T=0;
                          else
                               pulse_width_T=(event_end_time_absolute-event_start_time_absolute)*1000;%in ms
                               pulse_depth_T=min(event_to_save-window_mean);%in nA

                               pulse_width_L=0;
                               pulse_depth_L=0;
                          end
    
                          pad_right=min([PAD_R win_data_length-event_exit_index]);
                          pad_left=min([PAD_L event_start_index_WS-1]);
                      end

                   %------------------------------------------------------------------------------------------------
                   %Saving Event Metrics:  added on 10/15/2025
                   %------------------------------------------------------------------------------------------------
                   data_to_save=[event_start_time_absolute event_end_time_absolute pad_left pad_right biphasic_logic pulse_width_L abs(pulse_depth_L) pulse_width_T abs(pulse_depth_T) window_std window_mean_to_save];
                   event_data_bounds(event_count_in,:)=data_to_save;
                      
                   %simple event metrics
                   dt_s_L=(pulse_width_L/1000);%pulse time of the leading pulse in seconds
                   dt_s_T=(pulse_width_T/1000);%pulse time of the trailing pulse in seconds
                   simple_metrics_array(event_count_in,:)=[event_start_time_absolute abs(pulse_depth_L) dt_s_L abs(pulse_depth_T) dt_s_T];
                          
                   %moving to the next event index and determining the future of the while loop
                   event_indexes=event_indexes(event_indexes>event_exit_index);
                   j=j+1;
            end
end

end