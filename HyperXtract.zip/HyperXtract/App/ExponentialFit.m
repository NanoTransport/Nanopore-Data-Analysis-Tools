function [myfit,A1,t0]=ExponentialFit(dt,bin_count,Mag,time_coeff)

[y_vals,bin_edges]=histcounts(dt,bin_count);

x_len=length(bin_edges);
x_vals=zeros(x_len-1,1);

for i=1:x_len-1
    x_vals(i)=bin_edges(i)+(bin_edges(i+1)-bin_edges(i))/2;
end
[~,I]=max(y_vals);
x_vals=x_vals(I:end);
y_vals=y_vals(I:end);

myfittype=fittype('A1*exp(-t/t0)','dependent',{'y'},'independent',{'t'},'coefficients',{'A1','t0'});
myfit = fit(x_vals,y_vals',myfittype,'StartPoint',[Mag,time_coeff]);

col_array=[0.5 0.3 0.9330];

figure,
d=histogram(dt,bin_count)
set(d,'FaceColor',col_array,'EdgeColor',col_array);
hold on,
f=plot(myfit,x_vals,y_vals,'.black')
%xlim([x_vals(1) x_vals(end)])
set(f,'LineWidth',2.5)
hold off
grid on

coefficientValues = coeffvalues(myfit);
A1=coefficientValues(1);
t0=coefficientValues(2);
str1 = sprintf('\n A1= %0.3f\n',A1);
str2 = sprintf(' t0= %0.3f',t0);
annotation('textbox',[.6 .5 .2 .2],'String',['Fit Parameters: ', str1, str2]);

end