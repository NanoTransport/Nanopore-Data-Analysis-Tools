function [myfit,A1,mu,sigma]=Gaussian(dI,bin_count,Mag,mu,sigma)

[y_vals,bin_edges]=histcounts(dI,bin_count);

x_len=length(bin_edges);
x_vals=zeros(x_len-1,1);

for i=1:x_len-1
    x_vals(i)=bin_edges(i)+(bin_edges(i+1)-bin_edges(i))/2;
end

myfittype=fittype('A.*exp(-(((x-mu).^2)/(2*sigma^2)))','dependent',{'y'},'independent',{'x'},'coefficients',{'A','mu','sigma'});
myfit = fit(x_vals,y_vals',myfittype,'StartPoint',[Mag,mu,sigma]);

col_array=[0.5 0.3 0.9330];

figure,
d=histogram(dI,bin_count)
set(d,'FaceColor',col_array,'EdgeColor',col_array);
hold on,
f=plot(myfit,'black')
set(f,'LineWidth',2.5)
hold off
grid on

coefficientValues = coeffvalues(myfit);
A1=coefficientValues(1);
mu=coefficientValues(2);
sigma=coefficientValues(3);

str1 = sprintf('\n A= %0.3f\n',A1);
str2 = sprintf(' μ= %0.3f\n',mu);
str3 = sprintf(' σ= %0.3f\n',sigma);
annotation('textbox',[.6 .5 .2 .2],'String',['Fit Parameters: ', str1, str2, str3]);
end