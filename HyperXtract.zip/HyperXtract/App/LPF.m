function [numd,dend] = LPF(lpf_type,N,f_cutoff,fre,Rpr,Rsa)

% N= filter order
%f_cutoff = cutoff frequency in Hz
f_cutoff_rad=2*pi*f_cutoff;%cutoff frequency in rad/s
%fre = sampling frequency in Hz
%Rpr = passband ripple in dB
%Rsa = stopband attenuation in dB 

%%https://au.mathworks.com/help/signal/ref/cheby1.html 

    if lpf_type==1
        [z,p,k] = besself(N,f_cutoff_rad,'low');
    elseif lpf_type==2
        [z,p,k] = butter(N,f_cutoff_rad,"s"); %To design an analog filter, perhaps for simulation, use a trailing 's' and specify cutoff frequencies in rad/s:
    elseif lpf_type==3
        [z,p,k] = cheby1(N,Rpr,f_cutoff_rad,"s");
    elseif lpf_type==4
        [z,p,k] = cheby2(N,Rsa,f_cutoff_rad,"s");
    else
        [z,p,k] = ellip(N,Rpr,Rsa,f_cutoff_rad,"s");
    end

%Transfer Function Form
[b,a] = zp2tf(z,p,k); %b,a = Transfer function numerator coefficients, Transfer function denominator coefficients
%Analog to Digital Conversion
[numd,dend] = bilinear(b,a,fre);% numd=Numerator coefficients of the digital transfer function, dend=Denominator coefficients of the digital transfer function

end