function [ipt]=event_level_refining(y,ipt,level_I_t,delta_I_sigma,level_comparison_method)

number_of_levels=length(ipt)-1;
level_mean_I=level_I_t(:,3);
level_retaining_list=[];

level_changes=1;%just to get the while loop below going
max_refining_iterations=10;
refining_iteration=0;

base_std=min([std(y(1:ipt(1)));std(y(ipt(end):end))]);

while number_of_levels>=2 && level_changes~=0 && refining_iteration<=max_refining_iterations
    
    refining_iteration=refining_iteration+1;
    level_before_refining=number_of_levels;
    
    for i=1:number_of_levels-1
        
        %current level
        level_length=ipt(i+1)-ipt(i);
        CL_twenty_percent_pts=ceil(level_length*0.2);
        cropped_event_length=(ipt(i+1)-CL_twenty_percent_pts)-(ipt(i)+CL_twenty_percent_pts);
        
        %next level
        next_level_length=ipt(i+2)-ipt(i+1);
        NL_twenty_percent_pts=ceil(next_level_length*0.2);
        next_cropped_event_length=(ipt(i+2)-NL_twenty_percent_pts)-(ipt(i+1)+NL_twenty_percent_pts);
        
        if cropped_event_length>2 && next_cropped_event_length>2 %without 3 points, what does even std mean?
            %this argument helps to keep spike like events
        
            current_level=y(ipt(i)+CL_twenty_percent_pts:ipt(i+1)-CL_twenty_percent_pts);
            current_mean=level_mean_I(i);
            current_std=std(current_level);
    
            next_mean=level_mean_I(i+1);
            
            if level_comparison_method==1 %std based
                dI=delta_I_sigma*current_std;
            else %current based
                dI=delta_I_sigma;
            end
            
            if (next_mean>(current_mean-dI) && next_mean<(current_mean+dI))
                std_retaining=0; %rejects the level
            else
                std_retaining=1; %keeps the level
            end
        else
            %For very short, spike-like sub-structures
            next_mean=level_mean_I(i+1);
            current_mean=level_mean_I(i);
            if level_comparison_method==1 %std based
                dI=delta_I_sigma*base_std;
            else %current based
                dI=delta_I_sigma;
            end
            
            if (next_mean>(current_mean-dI) && next_mean<(current_mean+dI))
                std_retaining=0; %rejects the level
            else
                std_retaining=1; %keeps the level
            end
        end
        level_retaining_list(i)=std_retaining;
    end
      
   deleting_indexes=find(level_retaining_list==0);
   if sum(deleting_indexes)>0
       ipt(deleting_indexes+1)=[];
   end
   
   number_of_levels=length(ipt)-1;
   level_changes=level_before_refining-number_of_levels;
   
   number_of_levels=length(ipt)-1;
   level_retaining_list=[];
end

    %Final level refining if the final level count is 2
    if number_of_levels==2
        
        current_level_length=ipt(1+1)-ipt(1);
        next_level_length=ipt(1+2)-ipt(1+1);
        if current_level_length>next_level_length
            CL_twenty_percent_pts=ceil(current_level_length*0.2);
            cropped_event_length=(ipt(1+1)-CL_twenty_percent_pts)-(ipt(1)+CL_twenty_percent_pts);
            current_level=y(ipt(1)+CL_twenty_percent_pts:ipt(1+1)-CL_twenty_percent_pts);
            
            current_mean=level_mean_I(1);
            other_level_mean=level_mean_I(2);
            potential_reject_level=2;%next level
        else
            NL_twenty_percent_pts=ceil(next_level_length*0.2);
            cropped_event_length=(ipt(1+2)-NL_twenty_percent_pts)-(ipt(1+1)+NL_twenty_percent_pts);
            current_level=y(ipt(1+2)+NL_twenty_percent_pts:ipt(1+1)-NL_twenty_percent_pts);
            
            current_mean=level_mean_I(2);
            other_level_mean=level_mean_I(1);
            potential_reject_level=1;%previous level
        end
        
        if cropped_event_length>2
            current_std=std(current_level);
            
            if level_comparison_method==1 %std based
                dI=delta_I_sigma*current_std;
            else %current based
                dI=delta_I_sigma;
            end
            
            if (other_level_mean>(current_mean-dI) && other_level_mean<(current_mean+dI))
                ipt(potential_reject_level)=[];
            end
        end
    end
end