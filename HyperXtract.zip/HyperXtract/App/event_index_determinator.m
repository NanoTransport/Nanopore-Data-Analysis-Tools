function [event_count_in,event_data_array,simple_metrics_array,event_data_bounds]=event_index_determinator(d_filter,fre,win_data_length,one_loop_time_sec,starting_time,PAD_L,PAD_R,event_count_in,event_indexes,back_step,window_mean,max_events_per_win,speed_mode,SMRP,main_loop_i,window_std,overall_data_scaling,event_data_array,DataSavingDropDown,file_path,data_boundary_file_name,simple_metrics_array,event_data_bounds)

i=main_loop_i;
if isempty(event_indexes)==0
    
            j=1;
            baseline_threshold=back_step*window_mean;
            %BEEI=index_temp(d_filter>=back_step*window_mean);%Baseline Entrance and Exit Indexes: REMOVED 09/05/2024 (NB)
            while isempty(event_indexes)==0 && j<max_events_per_win
                  event_count_in=event_count_in+1;
                  
                  %Event Start and End Point Deduction:  vectorized approach modified on 09/05/2024 (NB)
                  entrace_index=event_indexes(1);
                  [event_start_index,event_exit_index,pad_left,pad_right]=event_limits_evaluator_mex(d_filter,win_data_length,entrace_index,baseline_threshold,PAD_L,PAD_R);
                  %End of Start and End Point deduction added on 09/05/2024

                  %Saving event bounderies and other metrics
                  if speed_mode==1 %speed mode on (warning--event distortion can happen)
                      esi_new=((event_start_index-1)*SMRP)+1;
                      if esi_new<PAD_L
                            pad_left=0;
                      else
                            pad_left=PAD_L;
                      end
                      
                      eei_new=((event_exit_index)*SMRP);
                      if eei_new>length(d_filter)-PAD_R
                            pad_right=length(d_filter)-eei_new;
                      else
                            pad_right=PAD_R;
                      end
                      
                      %Storing event data 
                      event_to_save=d_filter(event_start_index:event_exit_index);%somewhat distorted (we only need an approximate at this point until fitting is done)
                      
                      %event metrics
                      event_start_time_absolute=(((i-1)*one_loop_time_sec)+(esi_new/fre))+starting_time;
                      event_end_time_absolute=(((i-1)*one_loop_time_sec)+(eei_new/fre))+starting_time;

                      pulse_width=(event_end_time_absolute-event_start_time_absolute)*1000;%in ms
                      pulse_depth=min(event_to_save-window_mean)*overall_data_scaling;%in nA
                      data_to_save=[event_start_time_absolute event_end_time_absolute pad_left pad_right pulse_width abs(pulse_depth) window_std*overall_data_scaling];
                      event_data_bounds(event_count_in,:)=data_to_save;
                      
                  else %No speed mode
                      
                      %Storing event data 
                      event_to_save=d_filter(event_start_index:event_exit_index);
                      
                      %event metrics
                      event_start_time_absolute=(((i-1)*one_loop_time_sec)+(event_start_index/fre))+starting_time;
                      event_end_time_absolute=(((i-1)*one_loop_time_sec)+(event_exit_index/fre))+starting_time;
                      
                      pulse_width=(event_end_time_absolute-event_start_time_absolute)*1000;%in ms
                      pulse_depth=min(event_to_save-window_mean)*overall_data_scaling;%in nA
                      data_to_save=[event_start_time_absolute event_end_time_absolute pad_left pad_right pulse_width abs(pulse_depth) window_std*overall_data_scaling];
                      event_data_bounds(event_count_in,:)=data_to_save;
                  end
                  
                  %storing event points to an array
                  length_of_event=length(event_to_save);
                  event_data_array(end:end+length_of_event-1)=event_to_save;
                      
                  %saving data after each loop
                  if strcmp(DataSavingDropDown,'Continuous')==1
                      writematrix(data_to_save,char(strcat(file_path,data_boundary_file_name)),'WriteMode','append');
                  end
                  
                  %simple event metrics
                  dt_s=(pulse_width/1000);
                  simple_metrics_array(event_count_in,:)=[event_start_time_absolute pulse_depth dt_s];
                            
                  %moving to the next event index and determining the future of the while loop
                  event_indexes=event_indexes(event_indexes>event_exit_index);
                  j=j+1;
            end
end

end