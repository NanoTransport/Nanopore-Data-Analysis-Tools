function [x_fetched,y_fetched,xlin,ylin,cont_density,polygons,total_contours_calculated,contour_matrix,Xgrid,Ygrid]=find_vals_in_contour_closed_contours(pad_fraction,x_values,y_values,KDE_Pts,total_contours,fetch_contour)

%-----------------------------------------------------------------------------------%
% KDE Grid
%-----------------------------------------------------------------------------------%

%KDE_Pts:  grid resolution
%pad_fraction:  pads the grid to prevent open-ended contours; extends grid by the fraction defined by this variable. 0.1=10%
x_range = range(x_values);
y_range = range(y_values);

xlin = linspace(min(x_values)-pad_fraction*x_range, max(x_values)+pad_fraction*x_range, KDE_Pts);
ylin = linspace(min(y_values)-pad_fraction*y_range, max(y_values)+pad_fraction*y_range, KDE_Pts);
[Xgrid, Ygrid] = meshgrid(xlin, ylin);

% Bandwidth for KDE (Scott's rule)
bandwidth = [std(x_values), std(y_values)] * length(x_values)^(-1/6);
xy = [x_values(:), y_values(:)];
[cont_density, ~] = ksdensity(xy, [Xgrid(:), Ygrid(:)], 'Bandwidth', bandwidth);
cont_density = reshape(cont_density, size(Xgrid));

%-----------------------------------------------------------------------------------%
% Extract contours
%-----------------------------------------------------------------------------------%
contour_matrix = contourc(xlin, ylin, cont_density, total_contours);


%-----------------------------------------------------------------------------------%
% Parse contour matrix C
%-----------------------------------------------------------------------------------%
idx = 1;
polygons = {}; % store contours
while idx < size(contour_matrix,2)
    level = contour_matrix(1,idx);
    KDE_Pts = contour_matrix(2,idx);
    polygon = contour_matrix(:, idx+1 : idx+KDE_Pts); % [x; y] coords
    polygons{end+1} = struct('level',level,'x',polygon(1,:), 'y',polygon(2,:));
    idx = idx + KDE_Pts + 1;
end

%-----------------------------------------------------------------------------------%
%Fetch the kth contour
%-----------------------------------------------------------------------------------%
total_contours_calculated=numel(polygons);
if fetch_contour>total_contours_calculated
    fetch_contour=total_contours_calculated;
elseif fetch_contour<=0
    fetch_contour=1;
end

insideMask = false(size(x_values));
poly = polygons{fetch_contour};
in = inpolygon(x_values, y_values, poly.x, poly.y);
insideMask = insideMask | in;
x_fetched = x_values(insideMask);
y_fetched = y_values(insideMask);

end