function [plateau_stability,plateau_kurtosis,plateau_edge_ratio,center_of_mass,lopsidedness,time_reversal_asymmetry,lag1_acf,correlation_time,wavelet_hf_energy,wavelet_lf_energy,spec_centroid,peak_fre_mean,spectral_flatness,hf_lf_ratio,spec_entropy,shannon_entropy,Hjorthmobility,skew_deriv,rmssd,MAD] = AuxFeatures2(event_signal,fre)

%------------------------------------------------------------------
% PLATEAU CHARACTERISTICS
%------------------------------------------------------------------
try
    % Identify plateau region (middle 50% by time)
    n = length(event_signal);
    plateau_start = round(0.25 * n);
    plateau_end = round(0.75 * n);
    plateau_region = event_signal(plateau_start:plateau_end);
        
    % Plateau stability (lower = more stable)
    plateau_stability = std(plateau_region) / (abs(mean(plateau_region)) + eps);
        
    % Plateau flatness (kurtosis; high = spiky, low = flat)
    plateau_kurtosis = kurtosis(plateau_region);
        
    % Compare plateau to edges
    edge_region = [event_signal(1:plateau_start); event_signal(plateau_end:end)];
    plateau_edge_ratio = mean(abs(plateau_region)) / (mean(abs(edge_region)) + eps);
catch
    plateau_stability = 0;
    plateau_kurtosis = 0;
    plateau_edge_ratio = 0;
end

%------------------------------------------------------------------
% TEMPORAL ASYMMETRY (Comprehensive)
%------------------------------------------------------------------
try
    % Center of mass (temporal barycenter)
    n = length(event_signal);
    weights = abs(event_signal - median(event_signal));  % Distance from baseline
    if sum(weights) > eps  % Use eps numerical stability
        center_of_mass = sum((1:n)' .* weights) / sum(weights) / n;
    else
        center_of_mass = 0;  % Default to center for flat signals
    end
   
    % Skewness of the envelope
    min_pts = 5;
    if n > min_pts  % Need enough points for envelope
        window = min(min_pts, floor(n/10));
        [upper_env, lower_env] = envelope(event_signal, window, 'peak');
        envelope_amplitude = (upper_env - lower_env) / 2;
        
        if std(envelope_amplitude) > 0  % Avoid skewness of constant signal
            lopsidedness = skewness(envelope_amplitude);
        else
            lopsidedness = 0;
        end
    else
        lopsidedness = 0;
    end
       
    % Time-reversed correlation (perfect symmetry = 1)
    reversed_signal = event_signal(end:-1:1);
    time_reversal_asymmetry = 1 - corr(event_signal, reversed_signal);%Interpretation: * Value near 0: The event is symmetric (like a perfect U-shape or V-shape). Value near 1: The event is highly asymmetric (e.g., a sharp drop at the start and a very slow, jagged recovery at the end)

    if isnan(time_reversal_asymmetry)
        time_reversal_asymmetry = 0; 
    end

catch
    center_of_mass = 0;
    lopsidedness = 0;
    time_reversal_asymmetry = 0;
end
%----------------------------------------------------------------------------------
% Auto Correlation Lag
%----------------------------------------------------------------------------------
try
    % 1. Normalize the signal (subtract mean)
    signal_centered = event_signal - mean(event_signal);
    
    % 2. Compute the raw autocorrelation
    % 'biased' normalization makes it easier to use as a correlation coefficient
    [raw_acf, lags] = xcorr(signal_centered, 'biased');
    
    % 3. Extract only positive lags (right side of the symmetric result)
    % Only need up to half the signal length to avoid edge effects
    pos_idx = lags >= 0;
    acf_positive = raw_acf(pos_idx);
    
    % 4. Normalize so that acf(0) = 1
    normalized_acf = acf_positive / acf_positive(1);
    
    % 5. Derive Features
    % Feature A: Lag-1 Autocorrelation
    if length(normalized_acf) > 1
        lag1_acf = normalized_acf(2);
    else
        lag1_acf = 0;
    end
    
    % Feature B: Correlation Time (lag where ACF drops to 1/e ≈ 0.368)
    e_val = 1/exp(1);
    % Find the first lag where ACF is below 1/e
    crossing_idx = find(normalized_acf < e_val, 1);
    
    if isempty(crossing_idx)
        correlation_time = (length(normalized_acf)/fre)*1000; % Never dropped
    else
        correlation_time = (crossing_idx/fre)*1000;
    end
    
    % Package features
    %lag1_acf; %If this value is close to 1, the signal is very smooth and slowly varying (typical for long, stable translocations). If it is close to 0, the signal is dominated by white noise
    %correlation_time; %This tells you the "width" of the autocorrelation peak. In nanopore sensing, a longer correlation time often suggests that the molecule is interacting more with the pore walls or has significant internal dynamics
    %normalized_acf; % Optional: if you need the whole curve
catch
    lag1_acf = 0;
    correlation_time = 0;
end

%----------------------------------------------------------------------------------
% Wavelet Features
%----------------------------------------------------------------------------------
try
    [C, L] = wavedec(event_signal, 4, 'db4');
    cD1 = detcoef(C, L, 1);
    cD4 = detcoef(C, L, 4);
    
    total_energy = sum(event_signal.^2);
    wavelet_hf_energy= sum(cD1.^2) / total_energy;
    wavelet_lf_energy = sum(cD4.^2) / total_energy;
catch
    wavelet_hf_energy = 0;
    wavelet_lf_energy = 0;
end

%----------------------------------------------------------------------------------
% Frequency
%----------------------------------------------------------------------------------
try
    [pxx, f] = periodogram(event_signal, [], [], fre);
    spec_centroid = sum(f .* pxx) / sum(pxx);%Spectral Centroid:  Mean frequency of the event signal.

    %[~, idx] = max(pxx); %Dominant Frequency (Peak Frequency)
    %peak_fre = f(idx);

    % =====================================================================
    % Subtract the mean to remove the massive 0 Hz / DC current baseline
    % =====================================================================
    event_signal_detrended = event_signal - mean(event_signal, 'omitnan');
    signal_length = length(event_signal_detrended);
    ns = 4; % total sections to be divided
    ov = 0.5; % overlap fraction
    
    % =====================================================================
    % Prevent window starvation. Ensure window length is at least 4 
    % =====================================================================
    calculated_lsc = floor(signal_length / (ns - (ns-1)*ov));
    lsc = max(ns, min(floor(signal_length/4), calculated_lsc));
    
    % Verify if the event is long enough to slice into a valid spectrogram grid
    if lsc > ns && signal_length >= lsc
        % Compute the spectrogram on the DETRENDED signal matrix
        [s, f_vec, ~] = spectrogram(event_signal_detrended, lsc, floor(ov*lsc), [], fre);
        pxx_time = abs(s).^2; % Power spectrum at each time slice
        
        % Track how the peak frequency changes step-by-step through the event
        [~, max_id_per_step] = max(pxx_time, [], 1); 
        peak_fre_vector = f_vec(max_id_per_step); 
        
        % Extract the dynamic descriptive metrics
        peak_fre_mean = mean(peak_fre_vector); 
        %peak_fre_std  = std(peak_fre_vector);
    else
        % Fallback for ultra-short events that cannot support window slicing
        [pxx, f] = periodogram(event_signal_detrended, [], [], fre);
        [~, idx] = max(pxx);
        peak_fre_mean = f(idx); % Use global peak frequency as fallback
        %peak_fre_std  = 0;       % No temporal variance possible
    end

    if peak_fre_mean<=0
        % Fallback for ultra-short events that cannot support window slicing
        [pxx, f] = periodogram(event_signal_detrended, [], [], fre);
        [~, idx] = max(pxx);
        peak_fre_mean = f(idx); % Use global peak frequency as fallback
    end
    %peak_fre_mean_dynamics = The average central tone of the molecule as it moves through the pore. It strips out temporary noise spikes and gives the true tracking baseline of the translocation

    %Spectral Faltness
    spectral_flatness = exp(mean(log(pxx + eps))) / mean(pxx);

    %Ratio of high frequency and low frequency power
    cutoff_freq = fre / 10;
    hf_lf_ratio = sum(pxx(f > cutoff_freq)) / sum(pxx(f <= cutoff_freq));

    %Spectral Entropy
    psd_norm = pxx / sum(pxx); % 1. Normalize the PSD so it behaves like a probability distribution
    spec_entropy = -sum(psd_norm .* log2(psd_norm + eps)) / log2(length(psd_norm));

catch
    spec_centroid = 0;
    peak_fre_mean = 0;
    %peak_fre_std = 0;
    spectral_flatness = 0;
    spec_entropy = 0;
    hf_lf_ratio = 0;
end

%----------------------------------------------------------------------------------
%                                  TIME DOMAIN FEATURES
%----------------------------------------------------------------------------------

%----------------------------------------------------------------------------------
% Shannon Entropy
%----------------------------------------------------------------------------------
try
    edges = linspace(min(event_signal), max(event_signal), 20);
    p = histcounts(event_signal, edges, 'Normalization', 'probability');
    p(p==0) = []; % Remove zeros to avoid log(0)
    shannon_entropy = -sum(p .* log2(p));
catch
    shannon_entropy = 0;
end

%----------------------------------------------------------------------------------
% Hjorth Mobility
%----------------------------------------------------------------------------------
try
    Hjorthmobility_raw = std(diff(event_signal)) / std(event_signal);
    Hjorthmobility = Hjorthmobility_raw * (fre / 1000);% CONVERSION: samples⁻¹ * samples/second * (1 second / 1000 ms)
catch
    Hjorthmobility = 0;
end

%----------------------------------------------------------------------------------
% Skewness of the Derivative
%----------------------------------------------------------------------------------
try
    skew_deriv = skewness(diff(event_signal));%Measures if the entry into the pore is "sharper" than the exit
catch
    skew_deriv = 0;
end

%----------------------------------------------------------------------------------
% Root Mean Square of Successive Differences (RMSSD) 
%----------------------------------------------------------------------------------
try
    rmssd = sqrt(mean(diff(event_signal).^2));
catch
    rmssd = 0;
end

%----------------------------------------------------------------------------------
% MAD (robustness to outliers)
%----------------------------------------------------------------------------------

try
    MAD = mad(event_signal, 1);
catch
    MAD = 0;
end

end