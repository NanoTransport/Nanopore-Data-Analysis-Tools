function [window_mean,window_std,d_baseline_pts,time_baseline_pts,baseline_indexes] = event_removal_new(data, fre, resampling_threshold, time_in, smooth_points, event_threshold,threhold_type)
    
try
    fre_threshold=resampling_threshold*1000;
    if fre>fre_threshold
        re_sampling_factor=ceil(fre/fre_threshold);
        data=data(1:re_sampling_factor:end);
        time_in=time_in(1:re_sampling_factor:end);
    end

    % Create histogram
    [counts, edges] = histcounts(data, 'BinMethod','fd');%'fd' (Freedman-Diaconis) for better outlier handling

    % Smooth
    counts_smooth = movmedian(counts, smooth_points);

    %findpeaks
    pks = findpeaks(counts_smooth);
    max_peak = max(pks);

    %re-qualifying the baseline
    [pks_smoothed, locs_smoothed]  = findpeaks(counts_smooth,'MinPeakProminence',0.5*max_peak);

    % Convert peak locations (bin indices) to actual current values
    peak_positions = edges(locs_smoothed);
    
    n_peaks = length(pks_smoothed);
    sigma_est_prel = 1.4826 * mad(data, 1); 

    %filtering peaks based on their nearest neighbour difference
    if n_peaks > 1
        % Calculate distances between consecutive peaks
        peak_distances = diff(peak_positions);
        
        % Initialize mask: keep all peaks initially
        keep_peaks = true(1, n_peaks);
        
        % Iterate through peaks and merge those too close
        i = 1;
        while i < n_peaks
            if keep_peaks(i) && keep_peaks(i+1)
                % Check distance between current peak and next peak
                if peak_distances(i) < sigma_est_prel
                    % Peaks are too close - keep the taller one
                    if pks_smoothed(i) >= pks_smoothed(i+1)
                        keep_peaks(i+1) = false; % Remove next peak
                    else
                        keep_peaks(i) = false; % Remove current peak
                    end
                end
            end
            i = i + 1;
        end
        
        % Filter peaks
        n_peaks = sum(keep_peaks);
    end

    if n_peaks==1

        % 2. The baseline is the highest peak in the histogram
        [~, maxIdx] = max(counts);
        mode_val = edges(maxIdx);
        
        % 3. Estimate local noise (Sigma) using Median Absolute Deviation (MAD)
        % MAD is much more robust to events than standard deviation
        sigma_est = 1.4826 * mad(data, 1); 
        
        % 4. Keep only points within 2*sigma of the Mode
        % This effectively "slices" the baseline out of the data
        baseline_indexes = (data > mode_val - 3*sigma_est) & (data < mode_val + 3*sigma_est);

    else
        % Compute derivative (rate of change)
        try
            dI_dt = [0, diff(data)] * fre; % Convert to nA/s
        catch
            dI_dt = [0, diff(data')] * fre; % Convert to nA/s
        end

        % Smooth to reduce noise
        dI_dt_smooth = movmean(dI_dt, smooth_points*10);
        
        % Threshold on derivative magnitude
        if threhold_type==1%stdev based
            deriv_threshold = event_threshold * std(dI_dt_smooth); % n-sigma threshold
        else
            deriv_threshold = event_threshold;
        end
        is_event_deriv = abs(dI_dt_smooth) > deriv_threshold;
        
        % Expand event regions (events may affect nearby points)
        expansion_samples = round(0.0001 * fre); % 0.1 ms on each side
        event_indexes = imdilate(is_event_deriv, ones(1, expansion_samples));

        % Baseline mask
        baseline_indexes = ~event_indexes;

    end

    %isolating the baseline points
    d_baseline_pts=data(baseline_indexes); %part added in V2.1
    time_baseline_pts=time_in(baseline_indexes); %part added in V2.1

    %calculating the mean and standard deviation
    total_observations=length(d_baseline_pts);
    window_mean=sum(d_baseline_pts)/total_observations;
    window_std=sqrt((sum((d_baseline_pts-window_mean).^2))/(total_observations-1));
    
catch
        %baseline correction failed
        window_mean=mean(data);
        window_std = std(data);
        baseline_indexes = 1:length(data);
        d_baseline_pts = data;
        time_baseline_pts = time_in;
end

end