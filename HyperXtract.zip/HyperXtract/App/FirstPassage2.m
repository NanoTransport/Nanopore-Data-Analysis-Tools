function [A1,mu,mode_of_the_fit,L,D,x_grid_vals,y_fit]=FirstPassage2(Y,bin_count,Mag,mu,diff_coeff,pore_len,norm_method)

% Compute bin centers
[y_vals, bin_edges] = histcounts(Y, bin_count, 'Normalization',norm_method);
x_centers = (bin_edges(1:end-1) + bin_edges(2:end)) / 2;

%Fitting
x_len=length(bin_edges);
x_vals=zeros(x_len-1,1);

for i=1:x_len-1
    x_vals(i)=bin_edges(i)+(bin_edges(i+1)-bin_edges(i))/2;
end

myfittype=fittype('A.*(L/(sqrt(4*3.14*d*x^3)))*exp(-((L-(mu-x)^2)/(4*d*x)))','dependent',{'y'},'independent',{'x'},'coefficients',{'A','L','d','mu'});
myfit = fit(x_vals,y_vals',myfittype,'StartPoint',[Mag,pore_len,diff_coeff,mu],'MaxIter', 1500,'TolFun', 1e-5);

coefficientValues = coeffvalues(myfit);
A1=coefficientValues(1);
mu=coefficientValues(4);
L=coefficientValues(2);
D=coefficientValues(3);

% Generate smooth curve from fit
x_grid_vals = linspace(min(x_centers), max(x_centers), 500);
y_fit = myfit(x_grid_vals);

%finding the mode
[~,Index]=max(y_fit);
mode_of_the_fit = x_grid_vals(Index);

end