function out = TableStrtoDouble(x) %helper function
    if isempty(x)
        out = 0;
    else
        out = str2double(x);
    end
end