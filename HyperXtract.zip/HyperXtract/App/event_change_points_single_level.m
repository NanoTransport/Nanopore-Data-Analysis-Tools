function [true_ipt] = event_change_points_single_level(event_pts,dt,resample_factor,resampling_threshold)

%re-sampling the event
if dt>resampling_threshold
    resampled_event=event_pts(1:resample_factor:end);
    resampling_status=1;
else %shorter dwell time events need no resampling
    resampled_event=event_pts;
    resampling_status=0;
end

ipt_bounds=findchangepts(resampled_event,'Statistic','mean','MaxNumChanges',2);

expected_change_points=2;
max_attempts = 25;
i=1;
if length(ipt_bounds)<expected_change_points
    i=1;
    while length(ipt_bounds)<expected_change_points  && i < max_attempts
        ipt_bounds=findchangepts(resampled_event,'Statistic','mean','MaxNumChanges',2+i);
        i=i+1;
    end  
end

if i < max_attempts

    ipt=[ipt_bounds(1);ipt_bounds(end)];
    
    if resampling_status==1
        true_ipt=(ipt*resample_factor)-resample_factor;
    else
        true_ipt=ipt;
    end

else
    true_ipt = [1; length(resampled_event)];
end

end