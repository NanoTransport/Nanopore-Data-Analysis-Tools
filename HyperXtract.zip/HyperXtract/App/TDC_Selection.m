function data_out = TDC_Selection(data_in,SC,TDC)

       if TDC>1 %updated on 01-22-2026
            data_out=data_in(SC:TDC:end);
            if std(data_out)<0.001 %we are somehow in the wrong channel (a very small std)
                 if SC==1
                     data_out=data_in(SC+1:TDC:end);
                 else
                     data_out=data_in(SC-1:TDC:end);
                 end
           end
       else
           data_out=data_in;
       end

end