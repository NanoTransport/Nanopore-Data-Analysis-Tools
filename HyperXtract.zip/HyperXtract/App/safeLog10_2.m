function [Xout,posMask] = safeLog10_2(Xin)
% safeLog10  Apply log10 only to positive values
%            Values <= 0 are assigned to zero.
%
% Usage:
%   Xout = safeLog10(Xin)

    % Preallocate output
    Xout = zeros(size(Xin));

    % Logical mask of positive entries
    posMask = Xin > 0;

    % Apply log10 only to positive values
    Xout(posMask) = log10(Xin(posMask));

end