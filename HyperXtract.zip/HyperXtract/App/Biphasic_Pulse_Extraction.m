function [biphasic_logic,st_pt_FP,end_pt_FP,end_pt_SP,first_change_pt,final_change_pt,smooth_data_BFL,skip_event]=Biphasic_Pulse_Extraction(data_in,data_indexes,win_mean,back_step,step_size,GSF,major_PDC,minor_PDC,first_pulse_nature,secondary_pulse_nature,BP_type,EA)

    time_data=(1:length(data_in))';
    popFac=0.95;
    BOP=4;

    try
    %----------------------------------------------------------------------------
    %ACTIVE TRACKING of the raw data:  a smoothline would be the result
    %----------------------------------------------------------------------------
    [~,~,~,~,~,X_Bfit]=Baseline_Tracking(time_data,data_in,step_size,popFac,BOP,GSF);
    smooth_data_BFL=X_Bfit(:,3);%smoothened data through active SIGNAL TRACKING
    
    %----------------------------------------------------------------------------
    %Thresholds for resistive and conductive parts of the event
    %----------------------------------------------------------------------------
    background_zeroed_data=(smooth_data_BFL-data_in);
    win_std=std(background_zeroed_data);

    FI=data_indexes(1);%First data index with event padding
    MI=data_indexes(2);%Middle Data index (transition index)
    EI=data_indexes(3);%end index with event padding
    
    if BP_type==1 %Leading pulse is the main pulse

            %Trailing pulse is the minor pulse
            if secondary_pulse_nature==1 %resistive
                secondary_threshold=win_mean-(minor_PDC*win_std);
                [pks_secondary_pulse,locs_secondary_pulse]=findpeaks(-data_in(MI:EI));
            else %conductive
                secondary_threshold=win_mean+(minor_PDC*win_std);
                [pks_secondary_pulse,locs_secondary_pulse]=findpeaks(data_in(MI:EI));
            end

            %Leading pulse is the main pulse
            main_threshold=win_mean-(major_PDC*win_std); %main pulse is always resistive due to conversion in the main loop
            [pks_main_pulse,locs_main_pulse]=findpeaks(-data_in(FI:MI)); %main pulse is always resistive due to conversion in the main loop

    else %Trailing pulse is the dominant pulse

            %Leading pulse is the minor pulse
            if secondary_pulse_nature==1 %resistive
                secondary_threshold=win_mean-(minor_PDC*win_std);
                [pks_secondary_pulse,locs_secondary_pulse]=findpeaks(-data_in(FI:MI));
            else %conductive
                secondary_threshold=win_mean+(minor_PDC*win_std);
                [pks_secondary_pulse,locs_secondary_pulse]=findpeaks(data_in(FI:MI));
            end

            %Trailing pulse is the main pulse
            main_threshold=win_mean-(major_PDC*win_std); %main pulse is always resistive due to conversion in the main loop
            [pks_main_pulse,locs_main_pulse]=findpeaks(-data_in(MI:EI)); %main pulse is always resistive due to conversion in the main loop
    end

    %----------------------------------------------------------------------------
    %Peaks in the Event Structure and Determination of Biphasic nanture
    %----------------------------------------------------------------------------

    if secondary_pulse_nature==1 && first_pulse_nature ~= secondary_pulse_nature % seconday pulse is resistive (primary pulse is always resistive due to operations in the main loop)
        biphasic_logic=abs(max(pks_main_pulse))<main_threshold & abs(max(pks_secondary_pulse))<secondary_threshold;
    elseif secondary_pulse_nature==2 && first_pulse_nature ~= secondary_pulse_nature % secondary pulse is conductive
        biphasic_logic=abs(max(pks_main_pulse))<main_threshold & max(pks_secondary_pulse)>secondary_threshold;
    else
        biphasic_logic=0;%cannot be a biphasic event because one pulse has to be conductive and the other resistive
    end

    %----------------------------------------------------------------------------
    %Event Boundaries
    %----------------------------------------------------------------------------

    %Second pulse end position
    if BP_type==1 %Leading pulse is the main pulse

        %Main pulse start point (Always resistive):  From the Leading pulse
        [~,Max_pk_index_MP]=max(pks_main_pulse);
        st_pt_FP=locs_main_pulse(Max_pk_index_MP);%st_pt_FP-Start Point First Pulse
        while data_in(st_pt_FP)<back_step*win_mean && st_pt_FP>1
               st_pt_FP=st_pt_FP-1;
        end
        
        %Main pulse end point (i.e., cross-over point to the second peak):  From the Leading pulse
        end_pt_FP=locs_main_pulse(Max_pk_index_MP); %end_pt_FP-End Point First Pulse
        while data_in(end_pt_FP)<back_step*win_mean && end_pt_FP<length(data_in)
              end_pt_FP=end_pt_FP+1;
        end
    
        %Secondary Pulse end point:  From the Trailing pulse
        [~,Max_pk_index_SP]=max(pks_secondary_pulse);
        end_pt_SP=locs_secondary_pulse(Max_pk_index_SP)+MI-1;%end_pt_SP-End Point Second Pulse
        if secondary_pulse_nature==1 %resistive
            while smooth_data_BFL(end_pt_SP)<back_step*win_mean && end_pt_SP<length(smooth_data_BFL)
                end_pt_SP=end_pt_SP+1;
            end
        else %conductive
            while smooth_data_BFL(end_pt_SP)>back_step*win_mean && end_pt_SP<length(smooth_data_BFL)
                end_pt_SP=end_pt_SP+1;
            end
        end

    else %Trailing pulse is the main pulse

        %Main pulse start point (Always resistive; cross-over point to the second peak):  From the Trailing pulse
        [~,Max_pk_index_MP]=max(pks_main_pulse);
        end_pt_FP=locs_main_pulse(Max_pk_index_MP)+MI-1;%end_pt_FP-End Point First Pulse
        while data_in(end_pt_FP)<back_step*win_mean && end_pt_FP>1
            end_pt_FP=end_pt_FP-1;
        end

        %Main pulse end point:  From the Trailing pulse
        end_pt_SP=locs_main_pulse(Max_pk_index_MP)+MI-1;%end_pt_SP-End Point Second Pulse
        while data_in(end_pt_SP)<back_step*win_mean && end_pt_SP<length(data_in)
            end_pt_SP=end_pt_SP+1;
        end

        %Secondary Pulse start point:  From the Leading pulse
        [~,Max_pk_index_SP]=max(pks_secondary_pulse);
        st_pt_FP=locs_secondary_pulse(Max_pk_index_SP);%st_pt_FP-Start Point First Pulse
        if secondary_pulse_nature==1 %resistive
            while smooth_data_BFL(st_pt_FP)<back_step*win_mean && st_pt_FP>1
                st_pt_FP=st_pt_FP-1;
            end
        else %conductive
            while smooth_data_BFL(st_pt_FP)>back_step*win_mean && st_pt_FP>1
                st_pt_FP=st_pt_FP-1;
            end
        end

    end

    %----------------------------------------------------------------------------
    %Change points to find the event exit
    %----------------------------------------------------------------------------
    if EA==1 %End Point Adjustment only for the exit pulse

            %Trailing Pulse is the Exit pulse
            if BP_type==1 %Leading pulse is the main pulse
                Max_Exit_Peak_Pos=locs_secondary_pulse(Max_pk_index_SP)+MI-1;
                exit_data=data_in(Max_Exit_Peak_Pos:end);
            else %trailing pulse is the main pulse
                Max_Exit_Peak_Pos=locs_main_pulse(Max_pk_index_MP)+MI-1;
                exit_data=data_in(Max_Exit_Peak_Pos:end);
            end
            change_pt=findchangepts(exit_data,'Statistic','mean',MaxNumChanges=2);
            if isempty(change_pt)==0
                final_change_pt=findchangepts(exit_data(change_pt(end):end),'Statistic','linear',MaxNumChanges=2)+change_pt(end)+Max_Exit_Peak_Pos-1;
                
                if isempty(final_change_pt)==1
                    final_change_pt=change_pt(end)+Max_Exit_Peak_Pos-1;
                end
            else
                final_change_pt=end_pt_SP;
            end

            first_change_pt=end_pt_FP;

    elseif EA==2 %end point adjustment is for the begining of the first pulse

            %Leading Pulse is the First pulse
            if BP_type==1 %Leading pulse is the main pulse
                Max_Entrance_Peak_Pos=locs_main_pulse(Max_pk_index_MP);
                entrance_data=data_in(FI:Max_Entrance_Peak_Pos);
            else %trailing pulse is the main pulse
                Max_Entrance_Peak_Pos=locs_secondary_pulse(Max_pk_index_SP);
                entrance_data=data_in(FI:Max_Entrance_Peak_Pos);
            end
            change_pt=findchangepts(entrance_data,'Statistic','mean',MaxNumChanges=2);
            if isempty(change_pt)==0
                first_change_pt=findchangepts(entrance_data(FI:change_pt(end)),'Statistic','linear',MaxNumChanges=2)+FI-1;
                
                if isempty(first_change_pt)==1
                    first_change_pt=change_pt(1)+FI-1;
                end
            else
                first_change_pt=st_pt_FP;
            end

            final_change_pt=end_pt_FP;

    elseif EA==3 %Both starting and exit pulse edges are adjusted

            %Trailing Pulse is the Exit pulse
            if BP_type==1 %Leading pulse is the main pulse
                Max_Exit_Peak_Pos=locs_secondary_pulse(Max_pk_index_SP)+MI-1;
                exit_data=data_in(Max_Exit_Peak_Pos:end);
            else %trailing pulse is the main pulse
                Max_Exit_Peak_Pos=locs_main_pulse(Max_pk_index_MP)+MI-1;
                exit_data=data_in(Max_Exit_Peak_Pos:end);
            end
            change_pt=findchangepts(exit_data,'Statistic','mean',MaxNumChanges=2);
            if isempty(change_pt)==0
                final_change_pt=findchangepts(exit_data(change_pt(end):end),'Statistic','linear',MaxNumChanges=2)+change_pt(end)+Max_Exit_Peak_Pos-1;
                
                if isempty(final_change_pt)==1
                    final_change_pt=change_pt(end)+Max_Exit_Peak_Pos-1;
                end
            else
                final_change_pt=end_pt_SP;
            end

            %Leading Pulse is the First pulse
            if BP_type==1 %Leading pulse is the main pulse
                Max_Entrance_Peak_Pos=locs_main_pulse(Max_pk_index_MP);
                entrance_data=data_in(FI:Max_Entrance_Peak_Pos);
            else %trailing pulse is the main pulse
                Max_Entrance_Peak_Pos=locs_secondary_pulse(Max_pk_index_SP);
                entrance_data=data_in(FI:Max_Entrance_Peak_Pos);
            end
            change_pt=findchangepts(entrance_data,'Statistic','mean',MaxNumChanges=2);
            if isempty(change_pt)==0
                first_change_pt=findchangepts(entrance_data(FI:change_pt(end)),'Statistic','linear',MaxNumChanges=2)+FI-1;
                
                if isempty(first_change_pt)==1
                    first_change_pt=change_pt(1)+FI-1;
                end
            else
                first_change_pt=st_pt_FP;
            end
    else
            first_change_pt=st_pt_FP;
            final_change_pt=end_pt_SP;

    end
        skip_event=0;
    catch
        biphasic_logic=0;
        st_pt_FP=0;
        end_pt_FP=0;
        end_pt_SP=0;
        first_change_pt=0;
        final_change_pt=0;
        smooth_data_BFL=0;
        skip_event=1;
    end
end