function [myfit,A1_fit,lambda_fit,mu_fit,sigma_fit]=Gaussian_Exponential_Tail(dI,bin_count,Mag,lambda,mu,sigma)

[y_vals,bin_edges]=histcounts(dI,bin_count);

x_len=length(bin_edges);
x_vals=zeros(x_len-1,1);

for i=1:x_len-1
    x_vals(i)=bin_edges(i)+(bin_edges(i+1)-bin_edges(i))/2;
end

myfittype=fittype('(A).*(exp(L/2.*((2*a)+(L*(b^2))-(2.*x)))).*(erfc((a+(L*(b^2))-x)./(1.414*b)))','dependent',{'y'},'independent',{'x'},'coefficients',{'A','L','a','b'});
myfit = fit(x_vals,y_vals',myfittype,'StartPoint',[Mag,lambda,mu,sigma]);

col_array=[0.5 0.3 0.9330];

figure,
d=histogram(dI,bin_count)
set(d,'FaceColor',col_array,'EdgeColor',col_array);
hold on,
f=plot(myfit,'black')
set(f,'LineWidth',2.5)
hold off
grid on

coefficientValues = coeffvalues(myfit);
A1_fit=coefficientValues(1);
lambda_fit=coefficientValues(2);
mu_fit=coefficientValues(3);
sigma_fit=coefficientValues(4);

str1 = sprintf('\n A= %0.3f\n',A1_fit);
str2 = sprintf(' λ= %0.3f\n',lambda_fit);
str3 = sprintf(' μ= %0.3f\n',mu_fit);
str4 = sprintf(' σ= %0.3f\n',sigma_fit);
annotation('textbox',[.6 .5 .2 .25],'String',['Fit Parameters: ', str1, str2, str3, str4]);
end