function [Res_Error]=Residual_Error(y,ipt_final,level_I_t)


total_levels=length(ipt_final)-1;
Res_Error=zeros(total_levels,1);
    for i=1:total_levels
        twenty_percent_length=ceil((ipt_final(i+1)-ipt_final(i))*0.2);
        if ipt_final(i)+(2*twenty_percent_length)<ipt_final(i+1)
            level_Y=y(ipt_final(i)+twenty_percent_length:ipt_final(i+1)-twenty_percent_length);
        else
            level_Y=y(ipt_final(i):ipt_final(i+1));
        end
        level_fit=level_I_t(i,3);
        SS_res=sum((level_Y-level_fit).^2);
        Res_Error(i)=SS_res;
    end

end