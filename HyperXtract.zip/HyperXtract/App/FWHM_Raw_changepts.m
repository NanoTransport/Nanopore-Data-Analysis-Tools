function fwhm = FWHM_Raw_changepts(signal_baseline_Corrected_absolute)
    
    try
        ipt = findchangepts(signal_baseline_Corrected_absolute,MaxNumChanges=2);
    
        if length(ipt)==2
            fall_index = ipt(1);
            rise_index = ipt(2);
        else
            fall_index = 0;
            rise_index = 0;
        end
    catch
        fall_index = 0;
        rise_index = 0;
    end

    % --- 2. Package Metrics ---
    
    if fall_index<=0 || rise_index<=0
        fwhm    = 0; %failed analysis
    else
        fwhm    = abs(fall_index - rise_index);
    end

end