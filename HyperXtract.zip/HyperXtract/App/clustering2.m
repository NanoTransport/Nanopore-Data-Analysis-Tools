function [clusterIdx,actual_clusters,C]=clustering2(cluster_method,x_values, y_values,target_clusters,number_of_neighbours)

X = [x_values, y_values];

    if cluster_method==1 %GMM ---------------------------------------------------
    
        GMModel = fitgmdist(X, target_clusters, ...
            'CovarianceType','full', ...
            'RegularizationValue',1e-5, ...
            'Start','plus', ...
            'Replicates',10, ...
            'Options', statset('MaxIter',2000,'TolFun',1e-8));
    
        P = posterior(GMModel, X);
    
        % reorder based on centroid x-position
        [~, order] = sort(GMModel.mu(:,1));
        P = P(:, order);
    
        [~, clusterIdx] = max(P, [], 2);
        actual_clusters = max(clusterIdx);
    
        % === Add centroids (GMM means already given) ===
        C = GMModel.mu(order,:);
    
    
    elseif cluster_method==2 %KMeans -------------------------------------------
    
        rng(1);
        [~, C] = kmeans(X, target_clusters, ...
                        'Replicates',10, ...
                        'MaxIter',2000, ...
                        'Display','off', ...
                        'Start','plus');
    
        [~, order] = sort(C(:,1));
        C = C(order,:);
        
        D = pdist2(X, C);
        [~, clusterIdx] = min(D, [], 2);
    
        actual_clusters=max(clusterIdx);
    
    
    elseif cluster_method==3 %DBSCAN -------------------------------------------
    
        eps_val = std(y_values);
        minpts_val = min([floor(length(y_values)*0.01); number_of_neighbours]);
    
        clusterIdx = dbscan(X, eps_val, minpts_val);
    
        % DBSCAN sometimes uses cluster 0 for noise → shift to 1…K
        clusterIdx(clusterIdx <= 0) = 0;
    
        % Compute number of real clusters
        uniqueClusters = unique(clusterIdx);
        uniqueClusters(uniqueClusters==0) = []; % remove noise
        actual_clusters = numel(uniqueClusters);
    
        % === Add centroids ===
        C = zeros(actual_clusters, size(X,2));
        for k = 1:actual_clusters
            pts = (clusterIdx == uniqueClusters(k));
            C(k,:) = mean(X(pts,:),1);
        end
    
    
    elseif cluster_method==4 %FCM -----------------------------------------------
    
        options = fcmOptions("Exponent",2.0,...
                             "NumClusters",target_clusters,...
                             "MaxNumIteration",200,...
                             "MinImprovement",0.001,...
                             "Verbose",false);
    
        [center, U] = fcm(X, options);
        U = U'; 
    
        [~, order] = sort(center(:,1));
        U = U(:, order);
        center = center(order,:);
    
        [~, clusterIdx] = max(U, [], 2);
        actual_clusters = max(clusterIdx);
    
        % === Add centroids ===
        C = center;
    
    
    elseif cluster_method==5 %HIERARCHICAL CLUSTERING ---------------------------
    
        Z = linkage(X, 'ward');
        clusterIdx = cluster(Z, 'maxclust', target_clusters);
    
        C = zeros(target_clusters, size(X,2));
        for k = 1:target_clusters
            C(k,:) = mean(X(clusterIdx == k, :), 1);
        end
    
        [~, order] = sort(C(:,1));
        newIdx = zeros(size(clusterIdx));
        for k = 1:target_clusters
            newIdx(clusterIdx == order(k)) = k;
        end
    
        clusterIdx = newIdx;
        actual_clusters = max(clusterIdx);
    
        % recompute ordered centroids
        C = C(order,:);
    
    
    elseif cluster_method==6 %Spectral Clustering -------------------------------
    
        numNeighbors = min([floor(length(y_values)*0.01); number_of_neighbours]);
        clusterIdx = spectralcluster(X, target_clusters, ...
                                     'Distance','euclidean', ...
                                     'NumNeighbors',numNeighbors);
    
        % initial centroids
        C = zeros(target_clusters, size(X,2));
        for k = 1:target_clusters
            C(k,:) = mean(X(clusterIdx==k,:), 1);
        end
    
        % merge tiny clusters
        minClusterSize = numNeighbors;
        for k = 1:target_clusters
            pts = find(clusterIdx == k);
            if numel(pts) < minClusterSize
                d = pdist2(X(pts,:), C);
                [~, nearestCluster] = min(mean(d,1));
                clusterIdx(pts) = nearestCluster;
            end
        end
    
        % recompute centroids
        C = zeros(target_clusters, size(X,2));
        for k = 1:target_clusters
            C(k,:) = mean(X(clusterIdx == k, :), 1);
        end
    
        % reorder by x-position
        [~, order] = sort(C(:,1));
        newIdx = zeros(size(clusterIdx));
        for k = 1:target_clusters
            newIdx(clusterIdx == order(k)) = k;
        end
        clusterIdx = newIdx;
    
        actual_clusters = max(clusterIdx);
    
        % final centroids
        C = C(order,:);
    
    
    else  % NO CLUSTERING ------------------------------------------------------
    
        actual_clusters = 1;
        clusterIdx = ones(length(x_values),1);
        C = mean(X,1);   % centroid of entire dataset
    
    end

end