function [true_ipt]=event_change_points_light(event_pts,threshold,dt,resample_factor,resampling_threshold,FEEB)

%re-sampling the event
if dt>resampling_threshold
    resampled_event=event_pts(1:resample_factor:end);
    resampling_status=1;
else %shorter dwell time events need no resampling
    resampled_event=event_pts;
    resampling_status=0;
end

ipt=findchangepts(resampled_event,'Statistic','mean','MinThreshold',threshold);

%we need a minimum of two change points
max_attempts = 25;
expected_change_points=2;
i=1;
if length(ipt)<expected_change_points
    i=2;
    while length(ipt)<expected_change_points && i < max_attempts
        ipt=findchangepts(resampled_event,'MaxNumChanges',i,'Statistic','mean');
        i=i+1;
    end
end

if i < max_attempts

    if FEEB==1 %Fix Event Edge Bounderies
        ipt_bounds=findchangepts(resampled_event,'Statistic','mean','MaxNumChanges',2);
        %we need a minimum of two change points
        if length(ipt_bounds)<2
            i=2;
            while length(ipt_bounds)<2 && i < max_attempts
                ipt_i=findchangepts(resampled_event,'MaxNumChanges',i,'Statistic','mean');
                i=i+1;
            end
            ipt_bounds=[ipt_i(1);ipt_i(end)];
        end
        ipt=ipt(ipt>ipt_bounds(1));
        ipt=ipt(ipt<ipt_bounds(end));
        ipt=[ipt_bounds(1);ipt;ipt_bounds(end)];
    end
    
    if resampling_status==1
        true_ipt=(ipt*resample_factor)-resample_factor;
        %ipt_reconstruct=[1;true_ipt;length(event_pts)];
    else
        true_ipt=ipt;
        %ipt_reconstruct=[1;true_ipt;length(event_pts)];
    end
else
    true_ipt = [1; length(resampled_event)];
end

end