function [Q1,Med,Q3,IQR,WhiskerLow,WhiskerHigh,WhiskerRange] = IQR_Metrics(event_data_baseline_corrected_abs)

Q1 = prctile(event_data_baseline_corrected_abs, 25);     % First quartile (25th percentile)
Med = median(event_data_baseline_corrected_abs);          % Median (50th percentile)
Q3 = prctile(event_data_baseline_corrected_abs, 75);      % Third quartile (75th percentile)
                                
IQR = Q3 - Q1;                 % Interquartile Range
                                
% Box plot whiskers (standard definition)
% Lower whisker: Q1 - 1.5*IQR (but not below minimum data point)
% Upper whisker: Q3 + 1.5*IQR (but not above maximum data point)
WhiskerLow = max(Q1 - 1.5*IQR, min(event_data_baseline_corrected_abs));
WhiskerHigh = min(Q3 + 1.5*IQR, max(event_data_baseline_corrected_abs));

WhiskerRange = WhiskerHigh-WhiskerLow;

end