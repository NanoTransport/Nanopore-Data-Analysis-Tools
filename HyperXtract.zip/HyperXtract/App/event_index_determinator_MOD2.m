function [event_count_in,simple_metrics_array,event_data_bounds]=event_index_determinator_MOD2(d_filter,fre,win_data_length,one_loop_time_sec,starting_time,PAD_L,PAD_R,event_count_in,event_indexes,back_step,window_mean,max_events_per_win,speed_mode,SMRP,main_loop_i,window_std,simple_metrics_array,event_data_bounds,dI_adjustment)

i=main_loop_i;
if isempty(event_indexes)==0
    
            j=1;
            baseline_threshold=back_step*window_mean;
            %BEEI=index_temp(d_filter>=back_step*window_mean);%Baseline Entrance and Exit Indexes: REMOVED 09/05/2024 (NB)

            if dI_adjustment~=0 %added on 10/25/2025 to get a true value of the baseline mean for conductive pulses
                window_mean_to_save=abs(mean(d_filter-dI_adjustment));
            else
                window_mean_to_save=window_mean;
            end

            while isempty(event_indexes)==0 && j<max_events_per_win
                  event_count_in=event_count_in+1;
                  
                  %Event Start and End Point Deduction:  vectorized approach modified on 09/05/2024 (NB)
                  entrace_index=event_indexes(1);
                  ii=0;
                  while d_filter(entrace_index-ii)<=baseline_threshold && entrace_index-ii>1
                           ii=ii+1;
                  end
                  event_start_index=entrace_index-ii;
                  pad_left=min([PAD_L event_start_index-1]);
                
                  ii=0;
                  while d_filter(entrace_index+ii)<=baseline_threshold && entrace_index+ii<win_data_length
                          ii=ii+1;
                  end
                  event_exit_index=entrace_index+ii;
                  pad_right=min([PAD_R win_data_length-event_exit_index]);
                  %End of Start and End Point deduction added on 09/05/2024

                  %Saving event bounderies and other metrics
                  if speed_mode==1 %speed mode on (warning--event distortion can happen)
                      
                      esi_new=((event_start_index-1)*SMRP)+1;%Event Start Index
                      eei_new=((event_exit_index)*SMRP);%Event End Index
                      
                      %Storing event data 
                      event_to_save=d_filter(event_start_index:event_exit_index);%somewhat distorted (we only need an approximate at this point until fitting is done)
                      
                      %event metrics
                      event_start_time_absolute=(((i-1)*one_loop_time_sec)+(esi_new/fre))+starting_time;
                      event_end_time_absolute=(((i-1)*one_loop_time_sec)+(eei_new/fre))+starting_time;

                      pulse_width=(event_end_time_absolute-event_start_time_absolute)*1000;%in ms
                      pulse_depth=min(event_to_save-window_mean);%in nA
                      data_to_save=[event_start_time_absolute event_end_time_absolute pad_left pad_right pulse_width abs(pulse_depth) window_std window_mean_to_save];
                      event_data_bounds(event_count_in,:)=data_to_save;
                      
                  else %No speed mode
                      
                      %Storing event data 
                      event_to_save=d_filter(event_start_index:event_exit_index);
                      
                      %event metrics
                      event_start_time_absolute=(((i-1)*one_loop_time_sec)+(event_start_index/fre))+starting_time;
                      event_end_time_absolute=(((i-1)*one_loop_time_sec)+(event_exit_index/fre))+starting_time;
                      
                      pulse_width=(event_end_time_absolute-event_start_time_absolute)*1000;%in ms
                      pulse_depth=min(event_to_save-window_mean);%in nA
                      data_to_save=[event_start_time_absolute event_end_time_absolute pad_left pad_right pulse_width abs(pulse_depth) window_std window_mean_to_save];
                      event_data_bounds(event_count_in,:)=data_to_save;
                  end
                  
                  %simple event metrics
                  dt_s=(pulse_width/1000);
                  simple_metrics_array(event_count_in,:)=[event_start_time_absolute pulse_depth dt_s];
                            
                  %moving to the next event index and determining the future of the while loop
                  event_indexes=event_indexes(event_indexes>event_exit_index);
                  j=j+1;
            end
end

end