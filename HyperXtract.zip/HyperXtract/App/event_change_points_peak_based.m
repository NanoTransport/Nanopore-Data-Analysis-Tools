function [true_ipt] = event_change_points_peak_based(event_pts,threshold,dt,resample_factor,resampling_threshold,FEEB)

%re-sampling the event
if dt>resampling_threshold
    resampled_event=event_pts(1:resample_factor:end);
    resampling_status=1;
else %shorter dwell time events need no resampling
    resampled_event=event_pts;
    resampling_status=0;
end


%******************finding change points based on peaks and valleys*********************%

%1. find the event boudaries
ipt=findchangepts(resampled_event,'Statistic','mean','MaxNumChanges',2);

%we need a minimum of two change points
max_attempts = 25;
expected_change_points=2;
i=1;
if length(ipt)<expected_change_points
    i=2;
    while length(ipt)<expected_change_points && i < max_attempts
        ipt=findchangepts(resampled_event,'MaxNumChanges',i,'Statistic','mean');
        i=i+1;
    end    
end

if i < max_attempts

    ipt_bounds=ipt;%will only be used if FEEB is activated by the user
    
    % 2. find peaks and valleys
    event_data_only=resampled_event(ipt(1):ipt(end));
    baseline=[resampled_event(1:ipt(1));resampled_event(ipt(end):end)];
    mean_baseline=mean(baseline);
    base_std=std(baseline)*threshold;%threshold=3 is better
    BCED=(mean_baseline-event_data_only);
    if length(BCED)>=3
        [~, pks_locs] = findpeaks(BCED);
        [~, val_locs]= findpeaks(-BCED);
        
        % 3. finding change points based on peaks and valleys that are larger than the std-based threshold
        all_pks_vallocs=sort([pks_locs;val_locs]);
        all_pks_vals=BCED(all_pks_vallocs);
        diff_pts=diff(all_pks_vals);
    else
        diff_pts=[];
    end
    
    if isempty(diff_pts)==0
        if length(diff_pts)>=3 %to detect a peak or a valley, there must be a minimu of 3 data points
            pks_new=find(findpeaks(diff_pts)>base_std);
            vals_new=find(findpeaks(-diff_pts)>base_std);
            total_internal_change_pts=length(pks_new)+length(vals_new)+1;
        else
            total_internal_change_pts=2;
        end
    else
        total_internal_change_pts=0;
    end
    
    expected_change_points=2+total_internal_change_pts;
    ipt=findchangepts(resampled_event,'Statistic','mean','MaxNumChanges',2+total_internal_change_pts);
    if length(ipt)<expected_change_points
        i=1;
        while length(ipt)<expected_change_points && i < max_attempts
            ipt=findchangepts(resampled_event,'Statistic','mean','MaxNumChanges',2+total_internal_change_pts+i);
            i=i+1;
        end  
    end
    
    %*********************************************************************************%
    
    if FEEB==1
        ipt=ipt(ipt>ipt_bounds(1));
        ipt=ipt(ipt<ipt_bounds(end));
        ipt=[ipt_bounds(1);ipt;ipt_bounds(end)];
    end
    
    if resampling_status==1
        true_ipt=(ipt*resample_factor)-resample_factor;
        %ipt_reconstruct=[1;true_ipt;length(event_pts)];
    else
        true_ipt=ipt;
    end
else
    true_ipt = [1; length(resampled_event)];
end

end