function fwhm = FWHM_Raw(signal_baseline_Corrected_absolute, peak_amp)

    % --- 1. Calculate Peak Amplitude & 50% Half-Max Level ---
    half_max_level = 0.5 * peak_amp; % 50% threshold level
    N = length(signal_baseline_Corrected_absolute);
    
    % --- 2. Compute Sub-Sample Interpolated FWHM (Delta t) ---
    try
        % Falling Edge 50% Crossing
        flipped_signal = flip(signal_baseline_Corrected_absolute);
        fall_idx = find(flipped_signal >= half_max_level, 1, 'first');
        fall_index = (N - fall_idx)+1;
    catch
        fall_index = 0;
    end

    % Rising Edge 50% Crossing
    try
        rise_index = find(signal_baseline_Corrected_absolute >= half_max_level, 1, 'first');
    catch
        rise_index = 0;
    end

    % --- 3. Package Metrics ---
    
    if fall_index<=0 || rise_index<=0
        fwhm    = 0; %failed analysis
    else
        try
            if rise_index > 1
                y1 = signal_baseline_Corrected_absolute(rise_index - 1);
                y2 = signal_baseline_Corrected_absolute(rise_index);
                % Fractional sample position where signal hits half_max_level
                t_rise = (rise_index - 1) + (half_max_level - y1) / (y2 - y1);
            else
                t_rise = rise_index;
            end

            % --- 3. Sub-Sample Linear Interpolation on Trailing Edge ---
            if fall_index < N
                y1 = signal_baseline_Corrected_absolute(fall_index);
                y2 = signal_baseline_Corrected_absolute(fall_index + 1);
                % Fractional sample position where signal drops back below half_max_level
                t_fall = fall_index + (half_max_level - y1) / (y2 - y1);
            else
                t_fall = fall_index;
            end
            fwhm    = t_fall - t_rise;
        catch
            fwhm    = fall_index - rise_index; %interpolation failed
        end
    end

end