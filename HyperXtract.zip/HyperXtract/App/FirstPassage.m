function [myfit,A1,mu,L,D]=FirstPassage(dt,bin_count,Mag,mu,diff_coeff,pore_len)

[y_vals,bin_edges]=histcounts(dt,bin_count);

x_len=length(bin_edges);
x_vals=zeros(x_len-1,1);

for i=1:x_len-1
    x_vals(i)=bin_edges(i)+(bin_edges(i+1)-bin_edges(i))/2;
end

myfittype=fittype('A.*(L/(sqrt(4*3.14*d*x^3)))*exp(-((L-(mu-x)^2)/(4*d*x)))','dependent',{'y'},'independent',{'x'},'coefficients',{'A','L','d','mu'});
myfit = fit(x_vals,y_vals',myfittype,'StartPoint',[Mag,pore_len,diff_coeff,mu]);

col_array=[0.5 0.3 0.9330];

figure,
d=histogram(dt,bin_count)
set(d,'FaceColor',col_array,'EdgeColor',col_array);
hold on,
f=plot(myfit,'black')
set(f,'LineWidth',2.5)
hold off
grid on

coefficientValues = coeffvalues(myfit);
A1=coefficientValues(1);
mu=coefficientValues(4);
L=coefficientValues(2);
D=coefficientValues(3);

str1 = sprintf('\n A= %0.3f\n',A1);
str2 = sprintf(' μ= %0.3f\n',mu);
str3 = sprintf(' L= %0.3f\n',L);
str4 = sprintf(' D= %0.3f\n',D);
annotation('textbox',[.6 .5 .2 .2],'String',['Fit Parameters: ', str1, str2, str3, str4]);
end