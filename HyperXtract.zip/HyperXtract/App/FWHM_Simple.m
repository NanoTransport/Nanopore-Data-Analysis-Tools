function [dt_pts,FWHM_dt_pts] = FWHM_Simple (event_pts,true_ipt,level_I_t,BSL,BSR)

%pulse widht calculations
dt_pts=true_ipt(end)-true_ipt(1);
level_currents=level_I_t(:,3);

%FWHM calculation
if length(true_ipt)>2 %multi-level event
    
    %FALLING EDGE
    BSL_pt=true_ipt(1);
    first_level_start_pt=true_ipt(2);
    falling_edge=event_pts(BSL_pt:first_level_start_pt);
    I_BSL=BSL;
    I_level_one=level_currents(1);
    
    time_data=(true_ipt(1):true_ipt(2))';
    X=[ones(length(time_data),1) time_data];
    coeffs=X\falling_edge;%y=c+mx
    slope=coeffs(2);
    intercept=coeffs(1);
    left_I_bound=I_BSL-(0.5*abs(I_BSL-I_level_one));
    left_t_pt=max([BSL_pt;(left_I_bound-intercept)/slope]);
        if left_t_pt>1.01*BSL_pt || left_t_pt<0.99*BSL_pt
            left_t_pt=BSL_pt;
        end
        
    %RISING EDGE    
    BSR_pt=true_ipt(end);
    last_level_start_pt=true_ipt(end-1);
    rising_edge=event_pts(last_level_start_pt:BSR_pt);
    I_BSR=BSR;
    I_level_last=level_currents(end);
    
    time_data=(true_ipt(end-1):true_ipt(end))';
    X=[ones(length(time_data),1) time_data];
    coeffs=X\rising_edge;%y=c+mx
    slope=coeffs(2);
    intercept=coeffs(1);
    right_I_bound=I_BSR-(0.5*abs(I_BSR-I_level_last));
    right_t_pt=max([last_level_start_pt;(right_I_bound-intercept)/slope]);
        if right_t_pt>1.01*last_level_start_pt || right_t_pt<0.99*last_level_start_pt
            right_t_pt=last_level_start_pt;
        end
        
     FWHM_dt_pts=right_t_pt-left_t_pt;
     
else %single level event
    BSL_pt=true_ipt(1);
    I_BSL=BSL;
    I_level_one=level_currents(1);
    half_I=I_BSL-0.5*(I_BSL-I_level_one);
    i=0;
    while event_pts(BSL_pt+i)>half_I && BSL_pt+i<length(event_pts)
        i=i+1;
    end
    
    if BSL_pt+i > true_ipt(end) %the program has gone terribly wrong
        left_t_pt=BSL_pt;
    else
        left_t_pt=BSL_pt+i;
    end
    
    BSR_pt=true_ipt(end);
    I_BSR=BSR;
    half_I=I_BSR-0.5*(I_BSR-I_level_one);
    i=0;
    while event_pts(BSR_pt-i)>half_I && BSR_pt-i>1
        i=i+1;
    end
    
    if BSR_pt-i > BSL_pt %the program has gone terribly wrong
        right_t_pt=BSR_pt;
    else
        right_t_pt=BSR_pt-i;
    end
    
    FWHM_dt_pts=right_t_pt-left_t_pt;
end

end