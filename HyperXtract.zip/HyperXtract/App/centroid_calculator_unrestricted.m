function[total_centroid_events,Cx_mean,Cy_mean,WCSS,avgDist,radius,diameter,Area,density]=centroid_calculator_unrestricted(x_values,y_values)

try
     if isempty (x_values)==1

            total_centroid_events=0;
            Cx_mean = 0;
            Cy_mean = 0;
            WCSS=0;
            avgDist=0;
            radius=0;
            diameter=0;
            Area=0;
            density=0;

     else
    
     %--------------------------------------------------------
     %    2. Fetch All Points
     %--------------------------------------------------------
     x_fetched = x_values;
     y_fetched = y_values;
     total_centroid_events=length(x_fetched);
              
     %--------------------------------------------------------
     %    3. Cluster centroid (mean of data points)
     %--------------------------------------------------------

     Cx_mean = mean(x_fetched);
     Cy_mean = mean(y_fetched);
              
     %--------------------------------------------------------
     %    4. Within-Cluster Sum of Squares (WCSS)
     %--------------------------------------------------------
     %This measures compactness — the sum of squared distances from each point to the cluster centroid:
     distances_sq = (x_fetched - Cx_mean).^2 + (y_fetched - Cy_mean).^2;
     WCSS = sum(distances_sq);
              
     %--------------------------------------------------------
     %    5. Average Distance
     %--------------------------------------------------------
     %Average Distance to Centroid
                
     avgDist = sqrt(mean(distances_sq));
                
     %--------------------------------------------------------
     %    6. Radius and Diameter
     %--------------------------------------------------------
     %Radius: maximum distance from centroid to any point.
     %Diameter: maximum pairwise distance inside cluster.
                
     radius = sqrt(max(distances_sq));
                    if numel(x_fetched) > 1
                        D = pdist([x_fetched(:), y_fetched(:)]);
                        diameter = max(D);
                    else
                        diameter = 0;
                    end
                
     %--------------------------------------------------------
     %    7. Area and Density
     %-------------------------------------------------------- 
     %polygon area
     % Find convex hull (outer boundary)
     k = convhull(x_fetched, y_fetched);
     % Calculate area using shoelace formula on hull points
     X_hull = x_fetched(k);
     Y_hull = y_fetched(k);
     n = length(X_hull) - 1;
     Area = 0.5 * abs(sum(X_hull(1:n) .* Y_hull(2:n+1) - X_hull(2:n+1) .* Y_hull(1:n)));
     
     %density:  number events/area
     density = numel(x_fetched) / Area;

     end

catch
            total_centroid_events=0;
            Cx_mean = 0;
            Cy_mean = 0;
            WCSS=0;
            avgDist=0;
            radius=0;
            diameter=0;
            Area=0;
            density=0;
end

end