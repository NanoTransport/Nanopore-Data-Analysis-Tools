%================================================================================================================================================
% Custom Event Feature Extration
% IMPORTANT: Don't include custom functions: they are not supported

%Example file is for Resistive or COnductive Pulses

%Important Notes:  Please don't change codes that are within 'DO NOT CHANGE' blocks

%FOLLOWING LINES ARE TO BE CHANGED BY THE USER DEPENDING ON THEIR NEEDS
% 1. Lines 134-143:  Set the Daughter File name and the Feature Names
% 2. Line 195 onwards:  This is where you decide the mathematics behind the features
%================================================================================================================================================


%============================================== WARNING WARNING WARNING WARNING WARNING =========================================================
%========================================================= DO NOT CHANGE=========================================================================
%============================================== WAIT UNTIL YOU SEE 'END OF PROTECTED SECTION' STRING LINE =======================================

app.StatusLamp_5.Color='yellow';
drawnow;

%Profile Builder
app.profile_status=0;
app.ReportNameEditField_2.Value='';
app.ProfileNameInnerEditField.Value='';
app.ProfileNameOuterEditField.Value='';
app.ElapsedTimesEditField.Value=0;
app.TotalFeaturesEditField.Value = 0;

%zeroing 'shift fields in "Profile Building Section" (only for aesthetic purposes)
app.ShiftEditField.Value=0;
app.ShiftEditField_2.Value=0;
app.ShiftEditField_3.Value=0;
app.FeaturesTextArea.Value=('  ');
pause(0.2);%this delay allows text area to clear (just for easthetics)

try

%============================================== WARNING WARNING WARNING WARNING WARNING =========================================================
%========================================================= DO NOT CHANGE=========================================================================
%============================================== WAIT UNTIL YOU SEE 'END OF PROTECTED SECTION' STRING LINE =======================================

    %Button functions
    set(app.buttonGroup1, 'Enable', 'off');
    set(app.buttonGroup2, 'Enable', 'off');
    set(app.buttonGroup3, 'Enable', 'off');
    set(app.AdvancedAnalyticsButtonGroup, 'Enable', 'off');
    set(app.BuildProfileButton, 'Enable', 'off');
    set(app.ProfileBuilderSubButtons, 'Enable', 'off');
    drawnow

    failed_events=0;
    app.FailedEventsEditField.Value=0;
    app.EventsintheFileEditField.Value=0;
    app.QualifiedEventsEditField.Value=0;
    app.BP_Upload=0;
    app.ProgressEditField_3.Value = 0;
    app.view_daughter_file_metrics = 1;

    %Zeroing plots
    plot(app.ParameterPlot,0,0);
    plot(app.Event_View_DF,0,0);
    app.ViewEventEditField_2.Value=1;

    %Emptying plots
    app.clearAllPlots();

    %Daugher File
    try
        fileID_data_Temp=fopen(app.DaughterFileEditField.Value);%Just to see if the file is avaialble and can be opened
        fclose(fileID_data_Temp);
        file_error_1=0;
    catch
        file_error_1=1;
    end

    %loading event location file
    try
        file_locs=readmatrix(app.EventLocationFileEditField.Value);
        file_error_2=0;
    catch
        file_error_2=1;
    end

    %loading event parameter file
    try
        extraction_file=readmatrix(app.ExtractedEventParameterFileEditField.Value);
        file_error_3=0;
    catch
        file_error_3=1;
    end


    if file_error_1==0 && file_error_2==0 && file_error_3==0

        start_pts=file_locs(:,1);
        event_lengths=file_locs(:,2);%this includes event padding as well:  07-03-2025

        if app.BatchExtractedCheckBox.Value==0%no batch extraction
            experiment_elapsed_time=extraction_file(:,1);
            PDL_pts=extraction_file(:,3);
            PDR_pts=extraction_file(:,4);
            dt_ms=extraction_file(:,5);
            dI_nA=extraction_file(:,6);
            window_std_nA=extraction_file(:,7);
            window_mean_nA=abs(extraction_file(:,8));
        else
            event_start_time=extraction_file(:,2);
            PDL_pts=extraction_file(:,4);
            PDR_pts=extraction_file(:,5);
            dt_ms=extraction_file(:,6);
            dI_nA=extraction_file(:,7);
            window_std_nA=extraction_file(:,8);
            window_mean_nA=abs(extraction_file(:,9));

            %total elapsed time calculation
            loaded_files=numel(unique(extraction_file(:,1)));

            for j=1:loaded_files-1
                break_point=find(extraction_file(:,1)==j+1,1);
                last_file_time=extraction_file(break_point-1,2);

                event_start_time(break_point:end)=event_start_time(break_point:end)+last_file_time;
            end
            experiment_elapsed_time=event_start_time;

        end

        fre=app.SamplingRatekHzEditField_2.Value*1000;

%===============================================================================================================================================
%=============================================='END OF PROTECTED SECTION' STRING LINE ==========================================================
%===============================================================================================================================================

        %event sving to binary file
        daughter_time_stamp=string(datetime('now','TimeZone','local','Format','HH_mm_ss'));
        extended_parameter_file_name=strcat("Extended_Event_Parameters_",daughter_time_stamp,'.xlsx');%need to be xlsx to accomade multisheet saving ability for biphasic events

        %app.item_list defines the names of the features. Change accordingly
        app.item_list = {'Experiment Elapsed Time (s)','Window mean (nA)','Window std (nA)','Skewness (flag 0)','Skewness (flag 1)','Skewness (Left)','Skewness (Right)','Kurtosis (flag 0)','Kurtosis (flag 1)','Kurtosis (Left)','Kurtosis (Right)','Moment','Event Area (fC)','Event Area (End Points Anchored, fc)','ΔI (nA)','ΔI (End Points Anchored, nA)',...
                'Δt (ms)','Δt (End Points Anchored, ms)','log (Δt)','Event Std (nA)','Event Mean (nA)','Event Variance (nA)',...
                'Rectangularity (ΔI*Δt)','Rectangularity (ΔI anchored*Δt)','Aspect ratio (nA/ms)','Total Peaks','Max Slope (nA/µs, Left)','Max Slope (nA/µs, Right)','Event RMS (nA)',...
                'Q1','Q3','IQR','ΔMedian','WhiskerRange','WhiskerLow','WhiskerHigh'};
        header=app.item_list;

%============================================== WARNING WARNING WARNING WARNING WARNING =========================================================
%========================================================= DO NOT CHANGE=========================================================================
%============================================== WAIT UNTIL YOU SEE 'END OF PROTECTED SECTION' STRING LINE =======================================

        writecell(header,char(strcat(app.daughter_file_path,extended_parameter_file_name)));

        app.parameter_data_Array=zeros(1,length(header));
        app.parameter_data_Array_BP_Conductive=zeros(1,length(header));
        app.parameter_data_Array_BP_Resistive=zeros(1,length(header));
        app.parameter_data_Array_BP_Both=zeros(1,length(header));
        failed_event_log = [];

        app.StatusLamp_5.Color='magenta';
        drawnow;

        id_count=0;
        id_count_resist=0;
        id_count_cond=0;
        id_count_both=0;

        for i=1:length(file_locs)

            fileID_data = fopen(app.DaughterFileEditField.Value);
            event_to_view=i;
            BTPR=4;%bytes per reading
            bin_skip_pts=start_pts(event_to_view)+PDL_pts(event_to_view)-1;%-1 is important otherswise the event is short by 1 point
            fseek(fileID_data,bin_skip_pts*BTPR,'bof');
            event_data_pts=event_lengths(event_to_view)-(PDL_pts(event_to_view)+PDR_pts(event_to_view)-1);%-1 is important otherwise the event is longer by 1 point

            try
                if event_data_pts>4

                    event_data=fread(fileID_data,event_data_pts,'float32');%data is saved in nA
                    fclose(fileID_data);

                    if strcmp(app.EventTypeDropDown.Value,'Resistive')==1 || strcmp(app.EventTypeDropDown.Value,'Conductive')==1

                        %Biphasic controls
                        app.BP_Upload=0;
                        app.EventsareBiphasicCheckBox.Value=0;
                        set(app.BiphasicPulseSelectionDropDown, 'Enable', 'off');
                        set(app.BiphasicPulseSelectionDropDown_2, 'Enable', 'off');
                        set(app.BiphasicPulseSelectionDropDown_3, 'Enable', 'off');
                        set(app.BiphasicPulseSelectionDropDown_4, 'Enable', 'off');
                        set(app.BiphasicPulseSelectionDropDown_5, 'Enable', 'off');

%===============================================================================================================================================
%=============================================='END OF PROTECTED SECTION' STRING LINE ==========================================================
%===============================================================================================================================================

                        %-----------------------------------------------------------------------------------------------------------------------------------------
                        %Pure Resistive or Conductive Pulses
                        %-----------------------------------------------------------------------------------------------------------------------------------------

                        % i is the current event. The location of the event is extracted from the excel file loaded on the 'Event Location File Filed'
                        if mean(sign(event_data))>0 %positive bias
                            actual_window_mean=1*window_mean_nA(i);
                            event_data_baseline_corrected_abs=abs(event_data-actual_window_mean);
                        else
                            actual_window_mean=-1*window_mean_nA(i);
                            event_data_baseline_corrected_abs=abs(event_data-actual_window_mean);
                        end

                        total_event_points=length(event_data);
                        time_pts=((1:total_event_points)/fre)';%in seconds

                        %Peak Calculation
                        [pks,~]=findpeaks(abs(event_data_baseline_corrected_abs));

                        %---------------------------------------------------------
                        %Area calculation
                        %---------------------------------------------------------
                        %finding the maximum I points on either side of the event
                        [~,max_point]=max(event_data_baseline_corrected_abs);

                        left_side_of_event=event_data_baseline_corrected_abs(1:max_point);
                        right_side_of_event=event_data_baseline_corrected_abs(max_point:end);

                        [~,LHS_min_idx]=min(left_side_of_event);
                        [~,RHS_min_idx]=min(right_side_of_event);

                        LHS_min_index=LHS_min_idx;
                        RHS_min_index=RHS_min_idx+max_point-1;

                        %Shifting the data so that the minimum current is at 0nA:  data anchoring
                        zero_anchored_data=abs(event_data_baseline_corrected_abs-min(event_data_baseline_corrected_abs));%moves the data so that the maximum current value is 0 nA

                        %Calculating the slope
                        data_begining=zero_anchored_data(LHS_min_index);
                        data_end=zero_anchored_data(RHS_min_index);
                        total_data_length=length(zero_anchored_data);%total_data_points
                        slope_calc=(data_end-data_begining)/total_data_length;

                        %correcting the data based on the slope so that the whole pulse is below 0nA with starting and end points anchored to 0nA
                        Y_correction=slope_calc*((1:total_data_length)-total_data_length);
                        Y_corrected_data=zero_anchored_data-Y_correction';

                        %pulse characteristics after the anchoring
                        time_pts_anchored_event=time_pts(LHS_min_index:RHS_min_index);
                        Y_corrected_anchored_data=Y_corrected_data(LHS_min_index:RHS_min_index);
                        dt_anchored_ms=(length(time_pts_anchored_event)/fre)*1000;%in mili-seconds

                        %---------------------------------------------------------
                        %Slope calculation
                        %---------------------------------------------------------
                        % Compute slopes (first derivative)
                        dx = diff(time_pts(1:max_point))*10^6;%in micro seconds; since dx is the same, it doesn't matter where you get the time array from
                        dy_LHS = diff(event_data_baseline_corrected_abs(1:max_point));%in nA
                        slope_LHS = max(abs(dy_LHS ./ dx));%nA/µs

                        dx = diff(time_pts(max_point:end))*10^6;%in micro seconds; since dx is the same, it doesn't matter where you get the time array from
                        dy_RHS = diff(event_data_baseline_corrected_abs(max_point:end));%in nA
                        slope_RHS = max(abs(dy_RHS ./ dx));%nA/µs


                        %---------------------------------------------------------
                        %Boxplot calculation
                        %---------------------------------------------------------

                        [Q1,Med,Q3,IQR,WhiskerLow,WhiskerHigh,WhiskerRange] = IQR_Metrics(event_data_baseline_corrected_abs);

                        %---------------------------------------------------------
                        %Storing Data
                        %---------------------------------------------------------

                        Skewness_flag0=skewness(event_data_baseline_corrected_abs,0);
                        Skewness_flag1=skewness(event_data_baseline_corrected_abs);%Default option (Flag 1)
                        Skewness_Left=skewness(event_data_baseline_corrected_abs(1:max_point));%Flag 1
                        Skewness_Right=skewness(event_data_baseline_corrected_abs(max_point:end));%Flag 1
                        Kurtosis_flag0=kurtosis(event_data_baseline_corrected_abs,0);
                        Kurtosis_flag1=kurtosis(event_data_baseline_corrected_abs);%Default option (Flag 1)
                        Kurtosis_Left=kurtosis(event_data_baseline_corrected_abs(1:max_point));%Flag 1
                        Kurtosis_Right=kurtosis(event_data_baseline_corrected_abs(max_point:end));%Flag 1
                        Moment=moment(event_data_baseline_corrected_abs,app.CentralMomentOrderEditField.Value);
                        total_area_fC=(trapz(time_pts,abs(event_data_baseline_corrected_abs)))*10^6;%changed on 10/21/2025
                        total_area_end_points_anchored_fC=(trapz(time_pts_anchored_event,abs(Y_corrected_anchored_data)))*10^6;
                        dI=dI_nA(i);
                        dI_end_points_anchored=max(Y_corrected_anchored_data);
                        dt=dt_ms(i);
                        dt_end_points_anchored=dt_anchored_ms;
                        logdt=safeLog10(dt/1000);
                        std_event=std(Y_corrected_data);%changed on 10/21/2025
                        mean_event=mean(Y_corrected_data);%changed on 10/21/2025
                        variance_event=var(Y_corrected_data);%changed on 10/21/2025
                        win_mean_nA=window_mean_nA(i);
                        win_std_nA=window_std_nA(i);
                        event_rectagularity_M1=total_area_fC/(dI*dt*1000);%using dI and dt
                        event_rectagularity_M2=total_area_end_points_anchored_fC/(dI_end_points_anchored*dt_end_points_anchored*1000);%using dI anchored and dt
                        aspect_ratio=dI/dt;
                        total_peaks=length(pks);
                        event_rms=rms(Y_corrected_data);%changed on 10/21/2025
                        current_exp_time=experiment_elapsed_time(i);

                        id_count=id_count+1;
                        app.parameter_data_Array(id_count,:)=[current_exp_time win_mean_nA win_std_nA Skewness_flag0 Skewness_flag1 Skewness_Left Skewness_Right Kurtosis_flag0 Kurtosis_flag1 Kurtosis_Left Kurtosis_Right Moment total_area_fC total_area_end_points_anchored_fC dI dI_end_points_anchored dt dt_end_points_anchored logdt std_event mean_event variance_event...
                            event_rectagularity_M1 event_rectagularity_M2 aspect_ratio total_peaks slope_LHS slope_RHS event_rms...
                            Q1 Q3 IQR Med WhiskerRange WhiskerLow WhiskerHigh];
                    end

%============================================== WARNING WARNING WARNING WARNING WARNING =========================================================
%========================================================= NOT RECOMMENDED TO CHANGE=============================================================
%============================================== WAIT UNTIL YOU SEE 'END OF PROTECTED SECTION' STRING LINE =======================================

                else
                    fclose(fileID_data);
                    failed_events=failed_events+1;
                    failed_event_log = [failed_event_log;i];
                end

            catch
                fopen(app.DaughterFileEditField.Value);
                fclose(fileID_data);
                failed_events=failed_events+1;
                failed_event_log = [failed_event_log;i];
            end

            if app.ViewProgressCheckBox.Value==1
                app.ProgressEditField_3.Value = (i/length(file_locs))*100;
            end

            if mod(i, 1000) == 0 % Only refresh every 1000th file
                drawnow limitrate
            end

        end

        app.ProgressEditField_3.Value = 99;
        drawnow

        try
            %clearing failed event rows
            if ~isempty(failed_event_log)
                app.parameter_data_Array(failed_event_log,:)=[];
                app.parameter_data_Array_BP_Conductive(failed_event_log,:)=[];
                app.parameter_data_Array_BP_Resistive(failed_event_log,:)=[];
                app.parameter_data_Array_BP_Both(failed_event_log,:)=[];
            end
        catch
            %do nothing
        end

        writematrix(app.parameter_data_Array,char(strcat(app.daughter_file_path,extended_parameter_file_name)),'WriteMode','append');

        app.ExtendedParameterFileEditField.Value=strcat(app.daughter_file_path,extended_parameter_file_name);

        app.FailedEventsEditField.Value=double(failed_events);
        app.EventsintheFileEditField.Value=double(length(file_locs));
        app.QualifiedEventsEditField.Value=double(length(file_locs)-failed_events);

        app.view_daughter_file_metrics=1;
        app.ProgressEditField_3.Value = 100;
        drawnow

    else
        msgbox(["One or more of the following fields are empty";"Daughter File";"Extracted Event Parameter File";"Event Location File"],"Error","error");
    end

    %Enabling buttons
    set(app.buttonGroup1, 'Enable', 'on');
    set(app.buttonGroup2, 'Enable', 'on');
    set(app.buttonGroup3, 'Enable', 'on');
    set(app.AdvancedAnalyticsButtonGroup, 'Enable', 'on');
    set(app.BuildProfileButton, 'Enable', 'on');
    set(app.ProfileBuilderSubButtons, 'Enable', 'off');
    drawnow

    app.StatusLamp_5.Color='green';
    drawnow;

catch %Extended Parameter Extraction Failed

    app.view_daughter_file_metrics=0;

    %enabling buttons
    set(app.buttonGroup1, 'Enable', 'on');
    set(app.buttonGroup2, 'Enable', 'on');
    set(app.buttonGroup3, 'Enable', 'on');
    set(app.AdvancedAnalyticsButtonGroup, 'Enable', 'off');
    set(app.BuildProfileButton, 'Enable', 'off');
    set(app.ProfileBuilderSubButtons, 'Enable', 'off');
    drawnow

    app.StatusLamp_5.Color='green';
    drawnow;

    msgbox(["One or more of the following fields are empty";"Daughter File";"Extracted Event Parameter File";"Event Location File"],"Error","error");

end

app.StatusLamp_5.Color='green';
drawnow;