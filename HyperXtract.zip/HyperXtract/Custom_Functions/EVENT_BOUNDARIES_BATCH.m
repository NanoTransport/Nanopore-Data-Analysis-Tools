function [event_count_in,simple_metrics_array,event_data_bounds]=EVENT_BOUNDARIES_BATCH(file_index,d_filter,fre,win_data_length,one_loop_time_sec,starting_time,PAD_L,PAD_R,event_count_in,event_indexes,back_step,window_mean,max_events_per_win,speed_mode,SMRP,main_loop_i,window_std,simple_metrics_array,event_data_bounds,dI_adjustment)

%================================================================================================================================================
% The program expects the outputs of this function
% It is not recommended to change the input variable names 
% This script governs the event bounderies
% This script ONLY work for batch analysis
% This script does not work for biphasic events

%INPUT/OUTPUT Definitions
    %0. file_index:  Index of the file (an internal counter:  don't change)
    %1. d_filter: Raw data of the window (they are either lowpass filterd or not)
    %2. fre:  Sampling rate in Hz (Govered by the Sampling Rate Field)
    %3. win_data_length: analysis windown length (in points). A.K.A Window Size (Govered by the Window Size (s) Field in points)
    %4. one_loop_time_sec: length of a analysis window. A.K.A Window Size in seconds (Govered by the Window Size (s) Field)
    %5. starting_time: Analysis Start Time (in seconds) (Govered by the Start Time (s) Field)
    %6. PAD_L: Extra points added to the left of the event (i.e., pad points to the left) (Govered by the Event Padding Field)
    %7. PAD_R: Extra points added to the right of the event (i.e., pad points to the right) (Govered by the Event Padding Field)
    %8. event_count_in: Event Count (Don't change this. This is an counter maintained by the program)
    %9. event_indexes: Indexes of events in the analysis window
    %10.back_step:  Back step points (Govered by the Back Step Field)
    %11.window_mean: Mean current of the analysis window
    %12.max_events_per_win: Maximum events allowed per window (Govered by the Maximum Events Per Window Field)
    %13.speed_mode: Whether speed mode is ON or OFF (Govered by the Speed Mode Field)
    %14.SMRP: Speed Mode Resampling Points (The ratio of fre/speed mode rate)
    %15.main_loop_i: Current main loop index
    %16.window_std: Standard deviation of the analysis window
    %17.simple_metrics_array: A storage array
    %18.event_data_bounds: A storage array 
    %19.dI_adjustment: Internal adjutment made to convert conductive pulses into resistive pulses (don't change)

%================================================================================================================================================

i=main_loop_i;
q=file_index;
if isempty(event_indexes)==0
    
            j=1;
            baseline_threshold=back_step*window_mean;

            if dI_adjustment~=0 %added to get a true value of the baseline mean for conductive pulses
                window_mean_to_save=abs(mean(d_filter-dI_adjustment));
            else
                window_mean_to_save=window_mean;
            end

            while isempty(event_indexes)==0 && j<max_events_per_win
                  event_count_in=event_count_in+1;
                  
                  %Event Start and End Point Deduction:  vectorized approach modified
                  entrace_index=event_indexes(1);
                  ii=0;
                  while d_filter(entrace_index-ii)<=baseline_threshold && entrace_index-ii>1
                           ii=ii+1;
                  end
                  event_start_index=entrace_index-ii;
                  pad_left=min([PAD_L event_start_index-1]);
                
                  ii=0;
                  while d_filter(entrace_index+ii)<=baseline_threshold && entrace_index+ii<win_data_length
                          ii=ii+1;
                  end
                  event_exit_index=entrace_index+ii;
                  pad_right=min([PAD_R win_data_length-event_exit_index]);

                  %Saving event bounderies and other metrics
                  if speed_mode==1 %speed mode on (warning--event distortion can happen)
                      
                      esi_new=((event_start_index-1)*SMRP)+1;%Event Start Index
                      eei_new=((event_exit_index)*SMRP);%Event End Index
                      
                      %Storing event data 
                      event_to_save=d_filter(event_start_index:event_exit_index);%somewhat distorted (we only need an approximate at this point until fitting is done)
                      
                      %event metrics
                      event_start_time_absolute=(((i-1)*one_loop_time_sec)+(esi_new/fre))+starting_time;
                      event_end_time_absolute=(((i-1)*one_loop_time_sec)+(eei_new/fre))+starting_time;

                      pulse_width=(event_end_time_absolute-event_start_time_absolute)*1000;%in ms
                      pulse_depth=min(event_to_save-window_mean);%in nA
                      data_to_save=[q event_start_time_absolute event_end_time_absolute pad_left pad_right pulse_width abs(pulse_depth) window_std window_mean_to_save];
                      event_data_bounds(event_count_in,:)=data_to_save;
                      
                  else %No speed mode
                      
                      %Storing event data 
                      event_to_save=d_filter(event_start_index:event_exit_index);
                      
                      %event metrics
                      event_start_time_absolute=(((i-1)*one_loop_time_sec)+(event_start_index/fre))+starting_time;
                      event_end_time_absolute=(((i-1)*one_loop_time_sec)+(event_exit_index/fre))+starting_time;
                      
                      pulse_width=(event_end_time_absolute-event_start_time_absolute)*1000;%in ms
                      pulse_depth=min(event_to_save-window_mean);%in nA
                      data_to_save=[q event_start_time_absolute event_end_time_absolute pad_left pad_right pulse_width abs(pulse_depth) window_std window_mean_to_save];
                      event_data_bounds(event_count_in,:)=data_to_save;
                  end
                  
                  %simple event metrics
                  dt_s=(pulse_width/1000);
                  simple_metrics_array(event_count_in,:)=[event_start_time_absolute pulse_depth dt_s];
                            
                  %moving to the next event index and determining the future of the while loop
                  event_indexes=event_indexes(event_indexes>event_exit_index);
                  j=j+1;
            end
end

end