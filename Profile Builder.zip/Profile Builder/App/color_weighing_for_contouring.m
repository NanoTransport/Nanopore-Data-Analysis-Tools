function [x_values,y_values,fractions_per_point,absolute_valid_event_indexes]=color_weighing_for_contouring(X,Y,minX,minY,maxX,maxY)

                initial_filtering_indexes=X> minX & Y>minY & X<maxX & Y<maxY;
                x_values = X(initial_filtering_indexes);
                y_values = Y(initial_filtering_indexes);
                absolute_valid_event_indexes=find(initial_filtering_indexes);
                total_data_pts = length(y_values);
                
                % Automatically choose bin counts (sqrt rule or you can use log rules)
                num_bins_x = round(sqrt(length(x_values)));
                num_bins_y = round(sqrt(length(y_values)));
                
                % Define bin edges using hist3
                [~, centers] = hist3([x_values, y_values], [num_bins_x num_bins_y]);
                x_edges = centers{1};
                y_edges = centers{2};
                
                % Assign each point to a bin
                try
                    [~,~, x_bin] = histcounts(x_values, x_edges);
                    [~,~, y_bin] = histcounts(y_values, y_edges);
                    
                    % Remove out-of-range points (those not falling in any bin)
                    valid_idx = x_bin > 0 & y_bin > 0 & x_bin < length(x_edges) & y_bin < length(y_edges);
                    x_bin = x_bin(valid_idx);
                    y_bin = y_bin(valid_idx);
                    x_values = x_values(valid_idx);
                    y_values = y_values(valid_idx);
                    absolute_valid_event_indexes=absolute_valid_event_indexes(valid_idx);
                    
                    % Create linear bin indices for 2D bin combinations
                    linear_idx = sub2ind([length(x_edges), length(y_edges)], x_bin, y_bin);
                    
                    % Count points in each bin
                    bin_counts = accumarray(linear_idx, 1);
                    
                    % Compute fraction of points per bin
                    bin_fractions = bin_counts / total_data_pts;
                    
                    % Map fractions back to each point
                    fractions_per_point = bin_fractions(linear_idx);
                catch
                    fractions_per_point = 1;
                end
end