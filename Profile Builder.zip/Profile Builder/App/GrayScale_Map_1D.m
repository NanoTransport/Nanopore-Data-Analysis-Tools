function plot_status = GrayScale_Map_1D(barcode_display,FontSizeEditField_2,PlotTitleONCheckBox,PlotTitlesTextArea)

figure(3)
ax = gca;
imagesc(ax,real(barcode_display));%to avoid errors from imaginary numbers
colormap(ax,gray);
axis(ax, 'off');

            ax.FontSize = FontSizeEditField_2; % Adjust font size as needed
            if PlotTitleONCheckBox==1
                title(ax, PlotTitlesTextArea{3});
            else
                title(ax, '');
            end
            plot_status=1;%this does nothing

%setting the figure position
screenSize = get(0, 'ScreenSize');
screenWidth = screenSize(3);
screenHeight = screenSize(4);
figWidth = screenWidth / 3;
figHeight = screenHeight / 3;
set(figure(3), 'Position', [0, 0, figWidth, figHeight]);

end