function plot_status = Binary_Map_2D(barcode_binary,num_features,MarkDiagonalCheckBox,AxisLabelONCheckBox,FontSizeEditField_2,PlotTitleONCheckBox,PlotTitlesTextArea,tick_spacing,tick_angle)

figure(4)
ax = gca;
imagesc(ax,barcode_binary);
colormap(ax,gray);

            if MarkDiagonalCheckBox==1
                hold(ax,'on')
                num_features = size(barcode_binary, 1);
                % --- Make diagonal squares red ---
                for k = 1:num_features
                    % Draw a red patch (square) over each diagonal cell
                    rectangle(ax,'Position', [k-0.5, k-0.5, 1, 1], ...
                              'FaceColor', 'red', ...
                              'EdgeColor', 'none');
                end
                hold(ax,'off')
            end

            if AxisLabelONCheckBox==1
                ax.XLabel.String='Feature j';
                ax.YLabel.String='Feature i';
            else
                ax.XLabel.String='';
                ax.YLabel.String='';
            end

            ax.XTick = 1:tick_spacing:num_features; % X ticks from 1 to 12
            ax.XTickLabel = arrayfun(@(x) sprintf('F%d', x), 1:num_features, 'UniformOutput', false); % Label them 1–1
            ax.YTick = 1:tick_spacing:num_features; % y ticks from 1 to 12
            ax.YTickLabel = arrayfun(@(x) sprintf('F%d', x), 1:num_features, 'UniformOutput', false); % Label them 1–1
            axis(ax, 'tight');
            axis(ax, 'equal');
            dx=0.5;
            ax.XLim = [dx num_features+dx];
            ax.YLim = [dx num_features+dx];
            xtickangle(tick_angle); 

            box(ax, 'on')
            ax.LineWidth = 3;  % Adjust the number for desired thickness

            ax.FontSize = FontSizeEditField_2; % Adjust font size as needed
            if PlotTitleONCheckBox==1
                title(ax, PlotTitlesTextArea{4});
            else
                title(ax, '');
            end
            plot_status=1;%this does nothing

%setting the figure position
screenSize = get(0, 'ScreenSize');
screenWidth = screenSize(3);
screenHeight = screenSize(4);
figWidth = screenWidth / 3;
figHeight = screenHeight / 3;
set(figure(4), 'Position', [screenWidth/2, 0, figWidth, figHeight]);

end