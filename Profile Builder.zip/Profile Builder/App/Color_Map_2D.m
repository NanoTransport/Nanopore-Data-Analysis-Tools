function plot_status = Color_Map_2D(matrix_log,DisplayCellValuesCheckBox,CellTextColorEditField,CellFontSizeEditField,num_features,MarkDiagonalCheckBox,AxisLabelONCheckBox,FontSizeEditField_2,PlotTitleONCheckBox,PlotTitlesTextArea,tick_spacing,tick_angle)

figure(1)
ax = gca;
imagesc(ax, real(matrix_log));%to avoid errors from imaginary numbers
colormap(ax, parula);
colorbar(ax);

%cell text colors scheme
user_col_plot_matrix = CellTextColorEditField;
text_col=str2num(user_col_plot_matrix);

if DisplayCellValuesCheckBox==1
    % Add text labels to each cell
    [rows, cols] = size(matrix_log);
    for i = 1:rows
        for j = 1:cols
            text(ax, j, i, sprintf('%.2f', real(matrix_log(i,j))), ...
                'HorizontalAlignment', 'center', ...
                'VerticalAlignment', 'middle', ...
                'Color', text_col, ...
                'FontSize', CellFontSizeEditField);
        end
    end
end

            if MarkDiagonalCheckBox==1
                hold(ax,'on')
                num_features = size(real(matrix_log), 1);
                % --- Make diagonal squares red ---
                for k = 1:num_features
                    % Draw a red patch (square) over each diagonal cell
                    rectangle(ax,'Position', [k-0.5, k-0.5, 1, 1], ...
                              'FaceColor', 'red', ...
                              'EdgeColor', 'none');
                end
                hold(ax,'off')
            end

            if AxisLabelONCheckBox==1
                ax.XLabel.String='Feature j';
                ax.YLabel.String='Feature i';
            else
                ax.XLabel.String='';
                ax.YLabel.String='';
            end

ax.XTick = 1:tick_spacing:num_features; % X ticks from 1 to N
ax.XTickLabel = arrayfun(@(x) sprintf('F%d', x), 1:num_features, 'UniformOutput', false); % Label them 1–1
ax.YTick = 1:tick_spacing:num_features; % y ticks from 1 to N
ax.YTickLabel = arrayfun(@(x) sprintf('F%d', x), 1:num_features, 'UniformOutput', false); % Label them 1–1
axis(ax, 'tight');
axis(ax, 'equal');
dx=0.5;
ax.XLim = [dx num_features+dx];
ax.YLim = [dx num_features+dx];
xtickangle(tick_angle); 

ax.FontSize = FontSizeEditField_2; % Adjust font size as needed
       if PlotTitleONCheckBox==1
                title(ax, PlotTitlesTextArea{1});
       else
                title(ax, '');
       end
       plot_status=1;%this does nothing

%setting the figure position
screenSize = get(0, 'ScreenSize');
screenWidth = screenSize(3);
screenHeight = screenSize(4);
figWidth = screenWidth / 3;
figHeight = screenHeight / 3;
set(figure(1), 'Position', [0, screenHeight/2, figWidth, figHeight]);

end